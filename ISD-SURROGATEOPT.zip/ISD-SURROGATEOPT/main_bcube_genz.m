function [Upper_bound, Lower_bound, extraOut] = main_bcube_genz(d,extraArg)
%
% This function performs B^3 method (Lee and Song, 2011) for system
% reliability analysis of truss structures against fatigue-induced
% sequential failure.
%

bcubetime=tic;

% unpack additional input arguments
dispOpt              = extraArg.disOp;
tolerance            = extraArg.tol;
FEAnalysis           = extraArg.feanalysis;  
forceapplied         = extraArg.forceapplied;
n_elem_to_fail       = extraArg.n_elem_to_fail;
threshold            = 10^(-15);
seed                 = extraArg.seed;
update               = extraArg.update;
probdata             = extraArg.probdata;
lsfparams            = extraArg.lsfparams;
lsfparams.N          = extraArg.time*lsfparams.v0;

if update == true, inspections = extraArg.inspections; end
rng(seed,"threefry");

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% define area of elements
m2_to_mm2            = 1000^2;
SRBDO_A              = d*m2_to_mm2; % area, [mm^2]
no_elements          = n_elem_to_fail;

% initialize values
Upper_bound          = 1;
Lower_bound          = 0;
bounds_hist          = [Lower_bound, Upper_bound];
Mixed_node.probability = zeros(no_elements,1);
Mixed_node.vector      = (1:1:no_elements).';
Red_node.vector      = [];
Red_node.probability = [];
Red_node.index       = [];
nrv                  = 2*no_elements+2; % no. of random variables
extraOut             = struct;
failure_paths        = struct;
T_r                  = zeros(1,no_elements);
lsfparams.nrv        = nrv;
lsfparams.no_elements = no_elements;
v0                    = lsfparams.v0;

% calculate stress when no prior member failed/intact structure
FEAparams.n_elem_to_fail   = n_elem_to_fail;
FEAparams.failed_members   = [];
FEAparams.failure_seq_bank = extraArg.failure_seq_bank;
FEAparams.femmodel         = extraArg.femmodel;
FEAparams.forceapplied     = forceapplied; 
lsfparams.stress = FEAnalysis(SRBDO_A,FEAparams);

% define inspection events for updating of reliability
if update == true
    [inspect_event,T_r] = define_inspect_event(no_elements,v0,inspections);
end
lsfparams.T_r = T_r;

if dispOpt == 1, disp('Starting B-CUBE...'); end

% calculation of initial system reliability for ground structure/no prior
% member failed
for i = 1:no_elements

    Failure_probability = [];
    Alpha_vector        = [];
    limit_state_params  = struct;
    for l = 1:no_elements

        if i~=l

            % perform reliability analysis  using FORM/SORM 
            % for each component event
            % TYPE 1 limit state function 
            % (Ti^0 < Tl^0)  
            lsf_type      = 1; % Eq.(7) in Ref. [1]
            failure_seq   = i; % member i, failed member of Eq. (7)
            surviving_mem = l; % member l, survivng member of Eq. (7)           

            % perform component reliability analysis
            [Pf, alpha] = run_ferum_form_improved( ...
                            lsf_type, ...
                            failure_seq,...
                            surviving_mem,...
                            probdata, ...
                            lsfparams );

            Failure_probability = [Failure_probability; Pf];
            Alpha_vector        = [Alpha_vector alpha];

            %%%%%
            % define params of LSF of each failure sequence event
            limit_state_params(l).failure_seq   = i;
            limit_state_params(l).surviving_mem = l;
            limit_state_params(l).lsf_type      = 1;

        end

        if i == l
            limit_state_params(l).failure_seq   = i;
            limit_state_params(l).lsf_type      = 2;
        end

    end  
        
    % perform reliability analysis using FORM/SORM for each component event
    % TYPE 2 of limit state function  
    % (Ti^0 < Ts)
    lsf_type      = 2; % Eq. (7) in Ref. [1]               
    failure_seq   = i; % member i, target failed member of Eq. (7)
    surviving_mem = [];

    % perform component reliability analysis
    [Pf, alpha] = run_ferum_form_improved( ...
                    lsf_type, ...
                    failure_seq,...
                    surviving_mem,...
                    probdata, ...
                    lsfparams );         

    Failure_probability = [Failure_probability; Pf];
    Alpha_vector        = [Alpha_vector alpha];
    
    % save failure probability, alpha, R
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    file_name = num2str(Mixed_node.vector(i) );
    if ~isempty(fieldnames(failure_paths))
        new_entry = length(failure_paths) + 1; 
    else, new_entry = 1; 
    end
    failure_paths(new_entry).fs_name = file_name;
    failure_paths(new_entry).Component_failure_probability_results = ... 
                                                      Failure_probability;
    failure_paths(new_entry).Component_alpha_vector = Alpha_vector;
    failure_paths(new_entry).FEA_results = lsfparams.stress;
    failure_paths(new_entry).Component_limit_state_params=limit_state_params;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % calculate system failure probability using Hohenbichler (1982) 
    % first-order concepts in system reliability + Genz (1992) integration
    Correlation_matrix  = Alpha_vector'*Alpha_vector;
    if any( Failure_probability < threshold ) 
        Mixed_node.probability(i) = 0; % truncate comp. event with low Pf
    else
        % Multivariate normal probability using Genz integration
        [p_qsimvnv, ~] = qsimvnv( ...
                            20000, ...
                            Correlation_matrix, ...                  
                            -inf(1, numel(Failure_probability)), ... % lb
                            norminv(Failure_probability(:))');       % ub
        
        Mixed_node.probability(i) = p_qsimvnv;
    end
    
end
extraOut.first_branch_nodes = Mixed_node.probability;  

% update the upper bound and lower bound
Upper_bound = sum(Mixed_node.probability) + sum(Red_node.probability);
Lower_bound = sum(Red_node.probability);
bounds_hist = [bounds_hist; Lower_bound, Upper_bound];


% start branching at most likely node and bounding failure probabilities
iiiii = 0;
while (abs(Lower_bound/Upper_bound)<tolerance)
    
    iiiii = iiiii + 1;
    if dispOpt == 1 % display intermediate results
        disp(['Running B-CUBE... ', num2str(iiiii,'%02d'), ...
              '-no. of branches made. UPPERBOUND: ', ...
              num2str(Upper_bound, '%06.6f'), '  LOWERBOUND: ', ...
              num2str(Lower_bound, '%06.6f'), '.']);
    end
    
    % find index of the most likely node
    [~,max_I] = max(Mixed_node.probability);

    % check if most likely node is a system failure event (i.e. collapse)
    % and expand index vectors and probability vectors.
    % red node contains the vectors and probability of system failure
    % events
    [Mixed_node, Red_node, FEA_results_add] = find_red_node(SRBDO_A,...
        Mixed_node, Red_node, max_I, FEAparams, FEAnalysis);
        
    % if the most likely node is NOT a system failure event 
    % then branch out from that most likely node
    if Red_node.isCollapse == false
        
        ind_size_old = size(Mixed_node.vector,1);
        
        % perform branching process and save index sequence to index_vector
        Mixed_node   = expand_index_vector(no_elements, Mixed_node);
        
        ind_size_new = size(Mixed_node.vector,1);
        
        % calculate system failure probability of new branches
        add_ind = max_I + (ind_size_new - ind_size_old);
        for i_index = max_I:add_ind
            
            % get the index of members in the failure sequence
            failure_seq = cut_index_vector( Mixed_node.vector(i_index,:) );
            
            % reload previous results of the same sequence
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            file_name = num2str( failure_seq(1) );
            if ((length(failure_seq)-1) >= 2 )
                for save_i = 2:( length(failure_seq)-1 )
                    file_name = strcat(file_name,'_', ...
                                   num2str( failure_seq(save_i)) );
                end
            end
            fs_ind = find(strcmp({failure_paths.fs_name}, file_name));
            Failure_probability = ...
                failure_paths(fs_ind).Component_failure_probability_results(1:end-1,:);
            Alpha_vector        = failure_paths(fs_ind).Component_alpha_vector(:,1:end-1);
            lsfparams.stress    = [failure_paths(fs_ind).FEA_results FEA_results_add];
            limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;
            limit_state_params([limit_state_params.lsf_type]==2)=[];
            limit_state_params([limit_state_params.lsf_type]==4)=[];
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % define the number of component events/limit state function
            % in a failure sequence
            n_LS = length(limit_state_params);
            i_LS = 1;

            % perform system reliability on new branch
            for mem_j = 1:no_elements
                if any( Failure_probability < threshold )
                    % when system event has one component with small
                    % failure probability, other components are no longer
                    % computed
                    break;
                end
                surviving_mem = mem_j;
                
                % check if member j is included in the current fail seq.
                member_included = check_included(failure_seq, surviving_mem);

                % when member is not included in the failure sequence
                while member_included == 0
                    if abs(lsfparams.stress(failure_seq(end), end)) < 10^(-2)
                        % Stress level is almost zeros. Therefore, zero is 
                        % inputed as system probability manually in order 
                        % to avoid numerical problems
                        Pf    = 0;
                        alpha = zeros(nrv,1)/no_elements;
                    else
                        % perform Reliability Analysis using FORM/SORM 
                        % for each component event
                        % TYPE 3 limit state function, 
                        % Ti^(1,...,i-1) < Tl^(1,...,i-1)
                        lsf_type = 3; 
                                              
                        % perform component reliability analysis
                        [Pf, alpha] = run_ferum_form_improved( ...
                                        lsf_type, ...
                                        failure_seq,...
                                        surviving_mem,...
                                        probdata, ...
                                        lsfparams );    

                    end
                    Failure_probability = [Failure_probability; Pf];
                    Alpha_vector        = [Alpha_vector alpha];
                    member_included     = 1;

                    %%%%%
                    % define params of LSF of each failure sequence event                
                    limit_state_params(n_LS+i_LS).lsf_type    = 3;
                    limit_state_params(n_LS+i_LS).failure_seq = failure_seq;
                    limit_state_params(n_LS+i_LS).surviving_mem = mem_j;
                    i_LS = i_LS +1;

                end
            end
            
            if all( Failure_probability > threshold )

                % perform Reliability Analysis using FORM/SORM 
                % for each component event
                % TYPE 4 limit state function, Eq. 10
                % T01+T2^1+ ...+Ti^(1,...,i-1) < Ts 
                lsf_type = 4; 
                                      
                % perform component reliability analysis
                [Pf, alpha] = run_ferum_form_improved( ...
                                lsf_type, ...
                                failure_seq,...
                                surviving_mem,...
                                probdata, ...
                                lsfparams );   

                Failure_probability = [Failure_probability; Pf];
                Alpha_vector        = [Alpha_vector alpha];

                %%%%%
                % define params of LSF of each failure sequence event 
                limit_state_params(n_LS+i_LS).lsf_type      = 4;
                limit_state_params(n_LS+i_LS).failure_seq   = failure_seq;
                limit_state_params(n_LS+i_LS).surviving_mem = [];
                i_LS = i_LS +1;
            end
			
            % save results from component reliability analysis and FEA            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            file_name = num2str(failure_seq(1) );
            for save_i = 2:length(failure_seq)
                file_name = strcat(file_name,'_', ...
                    num2str(failure_seq(:,save_i)) );
            end
            if ~isempty(fieldnames(failure_paths)), new_entry = length(failure_paths) + 1; 
            else, new_entry = 1; end
            failure_paths(new_entry).fs_name = file_name;
            failure_paths(new_entry).Component_failure_probability_results = Failure_probability;
            failure_paths(new_entry).Component_alpha_vector = Alpha_vector;
            failure_paths(new_entry).FEA_results = lsfparams.stress;
            failure_paths(new_entry).Component_limit_state_params = limit_state_params;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % calculate system failure probability using Hohenbichler (1982) 
            % first-order concepts in system reliability 
            %                                    + Genz (1992) integration
            Correlation_matrix  = Alpha_vector'*Alpha_vector;
            if any( Failure_probability < threshold ) 
                Mixed_node.probability(i_index) = 0;
            else
                % Multivariate normal probability using Genz integration
                [p_qsimvnv, ~] = qsimvnv( ...
                                    20000, ...
                                    Correlation_matrix, ...
                                    -inf*ones(1,length(Failure_probability)), ...
                                    norminv(Failure_probability)' );
                Mixed_node.probability(i_index) = p_qsimvnv;
            end

        end
    end % end of if statement when no system failure is observed

    % update upperbound and lower bound
    Upper_bound = sum(Mixed_node.probability) + sum(Red_node.probability);
    Lower_bound = sum(Red_node.probability);
    bounds_hist = [bounds_hist; Lower_bound, Upper_bound]; 
end

% UPDATE system reliability based on inspection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
updated_P_Esys_upper_bound = Upper_bound;
updated_P_Esys_low_bound   = Lower_bound;
if update == true && ~isempty(inspect_event)
    
    if dispOpt == 1, fprintf('\nUpdating reliability bounds...\n'); end

    % update the reliability bounds (upper and lower) AFTER inspection
    % based on the inspection outcomes up to time Ts
    [updated_P_Esys_upper_bound,updated_P_Esys_low_bound,updateextra] = ...
        update_reliability_bounds5(Red_node, ...
                                   Mixed_node,...
                                   failure_paths,...
                                   inspect_event, ...
                                   lsfparams,...
                                   probdata );
    
end
% End of updating of system reliability bounds
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

extraOut.red_node         = Red_node;
extraOut.mixed_node       = Mixed_node;
extraOut.no_branches      = iiiii; 
extraOut.bounds_hist      = bounds_hist;
extraOut.T_r              = T_r;

if update == true && ~isempty(inspect_event)
    extraOut.p_Esys_given_insp = updated_P_Esys_upper_bound;
    extraOut.inspect_event     = inspect_event;
    extraOut.inspections       = inspections;
    extraOut.updateextra       = updateextra;
else
    updated_P_Esys_upper_bound = [];
    updated_P_Esys_low_bound   = [];
    extraOut.p_Esys_given_insp = extraOut.bounds_hist(end,2);
    extraOut.inspections       = [];
    extraOut.inspect_event     = [];
    extraOut.updateextra       = [];
end

if isempty(Red_node.probability) ~= true
    dom_failure = Red_node.vector(1,:);
    astr = '';
    for i = 1:size(dom_failure,2)
        if i==size(dom_failure,2)
            astr = strcat (astr, num2str(dom_failure(i)));
        else
            astr = strcat (astr,num2str(dom_failure(i)),'->');
        end
    end
else
    astr = 'No dominant failure found.';
    Red_node.probability(1) = 0;
end

extraOut.elapsed_time = toc(bcubetime);
extraOut.seed         = seed;

if dispOpt == 1
    disp(' ')
    disp('================= Summary of Results =================');
    disp(['   Upperbound Values: ', num2str(Upper_bound)]);
    disp(['   Lowerbound Values: ', num2str(Lower_bound)]);
    disp(['   Number of branches made: ', num2str(iiiii)]);  
    disp( '   Updated values[After Inspection]: ');
    disp(['      Updated Upperbound: ', num2str(updated_P_Esys_upper_bound) ]);
    disp(['      Updated Lowerbound: ', num2str(updated_P_Esys_low_bound) ]); 
    disp(['   Repaired time: ',num2str(T_r) ]);
    disp(['   No. of dominant failure seq found: ',num2str(size(Red_node.vector,1))]);
    disp(['   Dominant failure sequence: ',astr]);
    disp(['   Dominant failure sequence probability: ',num2str(Red_node.probability(1)) ]);
	disp(['   Ts (year): ',num2str( extraArg.time ) ]);
	disp(['   Elapsed Time: ',num2str(extraOut.elapsed_time) ]);
    disp('======================================================');
    disp(' ')
end

%
% Updated by Nophi (2025), YJ Lee
%
% Reference: 
%
% [1] Lee, Y.-J., & Song, J. (2011). Risk Analysis of Fatigue-Induced Sequential 
%     Failures by Branch-and-Bound Method Employing System Reliability Bounds. 
%     Journal of Engineering Mechanics, 137(12), 807–821. 
%     https://doi.org/10.1061/(ASCE)EM.1943-7889.0000286
%
% [2] Lee, Y.-J., & Song, J. (2013). System Reliability Updating of 
%     Fatigue-Induced Sequential Failures. Journal of Structural Engineering, 
%     140(3). https://doi.org/10.1061/(ASCE)ST.1943-541X.0000836
%
% [3] Genz, A. (1992). Numerical Computation of Multivariate Normal 
%     Probabilities. Journal of Computational and Graphical Statistics, 
%     1(2), 141–149. https://doi.org/10.1080/10618600.1992.10477010
%