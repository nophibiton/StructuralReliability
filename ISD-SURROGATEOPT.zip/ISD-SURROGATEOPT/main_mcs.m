function [Failure_probability,updated_Failure_probability,extraOut] = ...
                                                main_mcs(d,extraArg)
%
% Performs monte carlo simulation of fatigue-induced sequential failure.
%

mcstime=tic;

% unpack additional input arguments
FEAnalysis           = extraArg.feanalysis;  
forceapplied         = extraArg.forceapplied;
n_elem_to_fail       = extraArg.n_elem_to_fail;
seed                 = extraArg.seed;
update               = extraArg.update;
Nsamples             = extraArg.n_samples;
N_sim                = extraArg.n_sim;
mcs_archive_name     = extraArg.mcs_archive_name;
probdata             = extraArg.probdata;
lsfparams            = extraArg.lsfparams;
lsfparams.N          = extraArg.time*lsfparams.v0;

inspections = [];
if update == true, inspections = extraArg.inspections; end
rng(seed,"threefry");

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% define area of elements
m2_to_mm2            = 1000^2;
SRBDO_A              = d*m2_to_mm2;
no_elements          = n_elem_to_fail;

% initialize simulation/sampling
No_FE_simulations = 0;

for sim_i = 1:N_sim

    % initialize variables
    x_Failure          = [];
    component_sequence = zeros(Nsamples,5); % assume failure sequence upto 5
    x_Time             = zeros(Nsamples,1);
    x_Time_detection   = [];
    x_Index            = zeros(Nsamples,1);
    x_Index_inspection = zeros(Nsamples,1);
    Failure_probability         = [];
    updated_Failure_probability = [];
    P_IE_sys                    = [];
    P_IE_i                      = [];
    inspect_event               = [];
    T_r                         = zeros(1,no_elements);
    v0                          = lsfparams.v0;
    
    if update == true
        [inspect_event,T_r] = define_inspect_event(no_elements,v0,inspections);
        x_Time_detection    = zeros(Nsamples,numel(inspect_event));
    end
    lsfparams.T_r = T_r;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%% First branching %%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % generate random variables
    x   = bcube_rv_generator(probdata, no_elements, Nsamples);

    % deterministic variables
    m    = lsfparams.mean_m;
    ac   = lsfparams.ac;
    Y_a  = lsfparams.Y_a;

    % calculate stress
    FEAparams.n_elem_to_fail   = n_elem_to_fail;
    FEAparams.failed_members   = [];
    FEAparams.failure_seq_bank = extraArg.failure_seq_bank;
    FEAparams.femmodel         = extraArg.femmodel;
    FEAparams.forceapplied     = forceapplied; 
    S_0 = FEAnalysis(SRBDO_A,FEAparams);

    fprintf('Starting MCS...\n');

    for k = 1:Nsamples

        % display every 100,000 iterations
        if mod(k, 100000) == 0
            fprintf('Iteration: %d samples.\n', k);
        end
        C  = x(k, 1                      :1*no_elements );
        ai = x(k, 1*no_elements+1:2*no_elements );
        ad = x(k, 2*no_elements+1 );        
        S  = x(k,end) * S_0';

        % calculate Ti0
        Ti0 = ((ac).^(1-m./2)-ai.^(1-m./2))./(C.*(S*3*sqrt(pi)).^m.*(1-m./2));

        % account for repair time
        Ti0 = Ti0 + T_r;

        % determine component with minimum Ti0 and 
        % index of the member that will most likely first to fail
        [min_Ti0,min_I]         = min(abs(Ti0));
        x_Time(k)               = min_Ti0;
        component_sequence(k,1) = min_I; 

        % replace the ai of the components with the equivalent acr of the
        % component with min Ti0
        aicr = (min_Ti0*C.*((3*S*sqrt(pi)).^m).*(1-m/2) + ai.^(1-m/2)).^(1./(1-m/2));
        x(k,(1*no_elements+1):(2*no_elements) ) = aicr;

     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     % Reliability updating considering inspection outcomes % 
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if update == true && ~isempty(inspect_event)

            % case for detection : 0 (no crack)
            idx         = [inspect_event.lsf_type]==5;
            insp_mems_j = [inspect_event(idx).inspected_mem];
            temp_IE     = fatigue_integral( ai(insp_mems_j), ...
                                            ad, ...
                                            C(insp_mems_j),  ...
                                            m, ...
                                            S(insp_mems_j), ...
                                            Y_a );
            x_Time_detection(k,:) = temp_IE;

        end
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    end

    % check for failed and survived samples
    % indexing: 0 = undetermined, 1 = collapse, 2: survive
    for k = 1:Nsamples
        if x_Time(k) > lsfparams.N
            x_Index(k) = 2; % survive
        else
            % remove member with least time to attain acr
            FEAparams.failed_members = cut_index_vector(component_sequence(k,:));
            demand = FEAnalysis(SRBDO_A, FEAparams); 
            if all(demand == -1) 
                x_Index(k) = 1;  % system collapse
            end
        end
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%% Further branching %%%%%%%%%%%%%%%%%%%%%%%%%

    for j=2:5

        % neither collapse or survive of the first branching
        mixed_node = find(x_Index==0); 

        for i=1:size(mixed_node,1)

            % get failure sequence vector
            failure_seq = cut_index_vector(component_sequence(mixed_node(i),:) );

            % variables
            C  = x(mixed_node(i),1:no_elements);  
            ai = x(mixed_node(i),(no_elements+1:2*no_elements) );
            % calculate stress considering failed members of mixed node i is removed
            FEAparams.failed_members = failure_seq;
            S_0 = FEAnalysis(SRBDO_A, FEAparams);
            S   = x(mixed_node(i), end) * S_0';
            
            m   = lsfparams.mean_m;
            ac  = lsfparams.ac;

            % calculate Tji
            Tji = ((ac).^(1-m./2)-ai.^(1-m./2))./(C.*(S*Y_a*sqrt(pi)).^m.*(1-m./2));

            % account for repair
            Tji = Tji + T_r;

            % determine component with minimum Tji
            Tji(failure_seq)      = inf; % so that failed members will not be chosen
            [min_Tji,min_I]       = min(abs(Tji) );
            x_Time(mixed_node(i)) = x_Time(mixed_node(i) ) + min_Tji; % Ti0 + Tji
            component_sequence(mixed_node(i),j) = min_I;

            % replace the ai of the components with the equivalent acr of the
            % component with min Tji
            aicr = (min_Tji*C.*((S*Y_a*sqrt(pi)).^m).*(1-m/2) + ai.^(1-m/2)).^(1./(1-m/2));
            x(mixed_node(i),(1*no_elements+1):(2*no_elements) ) = aicr;
        end

        % check for failed and survived samples
        % indexing: 0 = undetermined, 1 = collapse, 2: survive
        for i=1:size(mixed_node,1)
            if (x_Time(mixed_node(i)) > lsfparams.N)
                x_Index(mixed_node(i)) = 2;
            else
                FEAparams.failed_members = cut_index_vector(component_sequence(mixed_node(i),:));
                demand = FEAnalysis(SRBDO_A, FEAparams);
                if all(demand == -1) 
                    x_Index(mixed_node(i)) = 1; % system collapse 
                end
            end
        end

    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Reliability updating considering inspection outcomes % 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if update == true  && ~isempty(inspect_event)

        % get inspections time to compare with T(ad)
        idx              = [inspect_event.lsf_type]==5;
        inspections_time = [inspect_event(idx).N_insp];

		% determine samples (time) T_insp < T_ad 
        % or (load cycles) N_insp < N_ad
        x_inspection = find( all(inspections_time<=x_Time_detection,2) );

        x_Index_inspection(x_inspection) = 1; 

        % probability P_IE_1 = P(IE1), P_IE_1 = P(IE2) ... 
		P_IE_i = sum(inspections_time <= x_Time_detection,1)/Nsamples;

		% probability P_IE_sys = P(IE1 ∧ IE2 ∧ ....)
        P_IE_sys = length(x_inspection)/Nsamples;

        % updated failure probability P(Esys∧IE_sys) / P_IE_sys 
        updated_Failure_probability = ...
        length( ...
          find( x_Index==1 & all(inspections_time<=x_Time_detection,2) )...
               ) ...
          / length( x_inspection );

    end

    % samples with observed collapse or failure
    x_Failure = [x_Failure; component_sequence(x_Index==1,:)];

    % calculate failure probability
    Failure_probability = size(x_Failure,1)/Nsamples;
    
    % calculate finite element simulations
    No_FE_simulations = No_FE_simulations + ...
                      length(find(component_sequence)) + size(x_Failure,1);

    % save intermediate results
    file_name = strcat(pwd,mcs_archive_name,'_mcs_data_',num2str(sim_i));
    save(file_name,'x_Failure','x_Time_detection','Failure_probability', ...
         'updated_Failure_probability', 'No_FE_simulations', ...
         'P_IE_sys','P_IE_i', 'inspect_event','inspections','Nsamples');

end

all_paths = x_Failure;
if ~isempty(all_paths)
    [Failure_path,~,idx] = unique(all_paths,'rows');
    
    counts = accumarray(idx,1);
    Failure_path_probability = counts / Nsamples / N_sim;

    % arrange rows by failure-path probability (highest first)
    [Failure_path_probability, sort_idx] = sort(Failure_path_probability, 'descend');
    Failure_path = Failure_path(sort_idx, :);

else
    Failure_path = [];
    Failure_path_probability = [];
end

updated_all_paths = component_sequence(x_Index==1 & x_Index_inspection==1,:);
if update == true  && ~isempty(inspect_event) && ~isempty(updated_all_paths)

    [updated_Failure_path,~,idx] = unique(updated_all_paths,'rows');

    counts = accumarray(idx,1);
    updated_Failure_path_probability = counts / Nsamples / N_sim;

    % arrange rows by failure-path probability (highest first)
    [updated_Failure_path_probability, sort_idx] = ...
        sort(updated_Failure_path_probability, 'descend');
    updated_Failure_path = updated_Failure_path(sort_idx, :);

else
    updated_Failure_path = [];
    updated_Failure_path_probability = [];
end

extraOut = struct;
extraOut.Failure_path_probability = Failure_path_probability;
extraOut.Failure_path = Failure_path;
extraOut.updated_Failure_path_probability = updated_Failure_path_probability;
extraOut.updated_Failure_path = updated_Failure_path;
extraOut.P_IE_sys     = P_IE_sys;
extraOut.Pf           = Failure_probability;
extraOut.Pf_updated   = updated_Failure_probability;
extraOut.elapsed_time = toc(mcstime);

if update == false
    extraOut.inspections       = [];
    extraOut.inspect_event     = [];
    extraOut.P_IE_i            = [];
    extraOut.P_IE_sys          = [];
else
    extraOut.inspect_event     = inspect_event;
    extraOut.inspections       = inspections;
    extraOut.P_IE_i            = P_IE_i;
    extraOut.P_IE_sys          = P_IE_sys;

end

disp(' ')
disp('================= Summary of MCS =================');
disp(['   Pf: ', num2str(extraOut.Pf)]);
disp(['   Updated Pf: ', num2str(extraOut.Pf_updated)]);
disp(['   Ts (year): ',num2str( extraArg.time ) ]);
disp(['   Elapsed Time: ',num2str(extraOut.elapsed_time) ]);
disp('==================================================');
disp(' ')