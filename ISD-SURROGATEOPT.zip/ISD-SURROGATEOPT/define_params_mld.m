function [objparams] = define_params_mld( case_struct )

    % problem description
    nrun                  = 1;
    description           = 'latent-failure-included';
    npools                = 6;
    seed                  = 110919912;
    n_samples             = 200;
    forceapplied          = 1*1.2*1000*1e3;
    allowed_insp_interval = [-1,2,5,10];

    d_min                 = [0.005, 0.005];
    d_max                 = [0.050, 0.050];

    case_run              = 'test_mld';    

    switch lower(case_struct)

        case 'case_a'
            save_fname            = strcat(case_run,'_case_a_run_');
            d_size                = 2;
            no_elements           = 3;
            femmodel              = @case_a_mld;
            under_water_index     = [2,3];
            above_water_index     = 1;

        case 'case_b'
            save_fname            = strcat(case_run,'_case_b_run_');
            d_size                = 2;
            no_elements           = 3;
            femmodel              = @case_b_mld;
            under_water_index     = 3;
            above_water_index     = [1,2];

        case 'case_c'
            save_fname            = strcat(case_run,'_case_c_run_');
            d_size                = 2;
            no_elements           = 2;
            femmodel              = @case_c_mld;
            under_water_index     = 2;
            above_water_index     = 1;

        case 'ground'
            save_fname            = strcat(case_run,'_ground_run_');
            d_size                = 2;
            no_elements           = 4;
            femmodel              = @mld;
            under_water_index     = [3,4];
            above_water_index     = [1,2];   

    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    objparams                       = struct;
    
    objparams.case_struct           = case_struct;

    objparams.nrun                  = nrun;
    objparams.description           = description;
    objparams.save_fname            = save_fname;
    objparams.npools                = npools;
    objparams.seed                  = seed;

    objparams.calc_const_cost       = @calc_const_cost_mld;
    objparams.dv2darea              = @dv2darea_mld;

    objparams.initDOE               = 5*d_size;
    objparams.percent_surr          = 0.8;

    objparams.case_struct           = case_struct;    
    objparams.d_size                = d_size;
    objparams.no_elements           = no_elements;
    objparams.d_min                 = d_min;
    objparams.d_max                 = d_max;
    
    objparams.feanalysis            = @FEAnalysis_mld;
    objparams.femmodel              = femmodel;
    objparams.forceapplied          = forceapplied;
    objparams.n_elem_to_fail        = no_elements;
    
    objparams.under_water_index     = under_water_index;
    objparams.above_water_index     = above_water_index;
    objparams.e1                    = 10^-16;
    
    % define inspection data
    objparams.allowed_insp_interval = allowed_insp_interval;
    [P1, P2] = ndgrid(allowed_insp_interval, allowed_insp_interval);
    %P1 = allowed_insp_interval; P2 = allowed_insp_interval;
    objparams.insp_permutations = [P1(:), P2(:)];
    objparams.d_insp_size = 2;         % two types of inspection
    objparams.t_sl        = 20;        % service life time, [year]
    objparams.t0_insp     = 10;        % first year of inspection, [year]
    objparams.mean_ad     = 5.0;       % mean detectable crack size, [mm]
    objparams.n_samples   = n_samples; % number of inspection outcomes
    
    % define cost factors
    objparams.r    = 0.02;             % discount rate
    objparams.cC0  = 1;                % fixed cost of construction
    objparams.cCi  = 0.006;            % const.cost per member, 0.006USD/kg
    objparams.cF   = 0.1*10000;        % cost of failure
    objparams.cI   = ones(1,d_size);   % cost of inspection per member
    objparams.cI(under_water_index) = 0.100;
    objparams.cI(above_water_index) = 0.010;
    objparams.cC   = 0.1;              % fixed cost of inspection campaigns
    objparams.cR   = ones(1,d_size);   % cost of repair per member
    objparams.cR(under_water_index) = 0.3;
    objparams.cR(above_water_index) = 0.1;
    
    % % get areas/design, [m^2]
    % dv2darea                       = objparams.dv2darea;
    % d_area                         = dv2darea( dv, case_struct );
    % objparams.dv                   = dv;

    objparams.p_latent             = normcdf(-2);
    objparams.member_loss          = 1;
    objparams.include_latent       = @include_latent_mld;

    % B^3 parameters
    bcubeparams.disOp              = false;    % display options for B3
    bcubeparams.tol                = 0.95;    % percent diff of low and up bound 
    bcubeparams.stopping_criterion = 0.001;   % additional stopping/not used
    bcubeparams.time               = objparams.t_sl;   % reference time, [yr]
    bcubeparams.mean_ad            = objparams.mean_ad;% detectable size, [mm]
    bcubeparams.femmodel           = femmodel;
    bcubeparams.failure_seq_bank   = [];
    bcubeparams.feanalysis         = objparams.feanalysis;
    bcubeparams.forceapplied       = forceapplied;      % force, [N]
    bcubeparams.n_elem_to_fail     = objparams.n_elem_to_fail;
    bcubeparams.seed               = seed;
    bcubeparams.inspections        = []; 
    bcubeparams.update             = false;
    bcubeparams.n_samples          = 1*10^5; % for MCS
    bcubeparams.n_sim              = 1;      % for MCS
    bcubeparams.mcs_archive_name   = 'data'; % for MCS

    objparams.bcubeparams          = bcubeparams;
    
end