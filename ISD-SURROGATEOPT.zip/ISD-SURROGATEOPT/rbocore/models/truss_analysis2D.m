function [varargout] = truss_analysis2D(Area,loads,femmodel)

warning off;

% define nodes, elment connectivity and boundary conditions
[nodes, elems, E, bc, Area] = newtopo(Area,femmodel);
Nnodes = size(nodes,1);    % number of nodes
Nel    = size(elems,1);    % number of elements
    
% define K , u , and f
K = zeros(2*Nnodes,2*Nnodes);
u = zeros(2*Nnodes,1);
f = zeros(2*Nnodes,1);
    
% define specified and free dofs
alldofs = 1:2*Nnodes;
dofspec = [] ;
for i = 1:size(bc,1)    
    thisdof = 2*(bc(i,1)-1) + bc(i,2);
    dofspec = [dofspec thisdof];        
end
doffree = alldofs ;
doffree(dofspec) = [] ;

% define nodal forces
for i = 1:size(loads,1)     
    a = loads(i,1);
    b = loads(i,2);
    f( 2*(a-1) + b) = loads(i,3);       
end
    
% assemble global stiffness matrix
for i=1:Nel      
    elnodes = elems(i,:);
    node1 = nodes(elnodes(1),:);
    node2 = nodes(elnodes(2),:);
        
    % determine length of member
    dx = node2(1)-node1(1); dy = node2(2)-node1(2);
    L = sqrt(dx^2 + dy^2);

    % determine direction cosines
    l = dx/L;  m = dy/L;

    % define transofmration matrix
    T = [l m 0 0 ; -m l 0 0 ; 0 0 l m ; 0 0 -m l] ;
        
    % determine local stiffness matrix
    k     = (Area(i)*E(i))/L ;                            
    k_loc = [ k 0 -k 0; 
              0 0  0 0; 
             -k 0  k 0; 
              0 0  0 0 ];

    % determine element stiffness matrix
    Kel    = T'*k_loc*T ;
    
    % map element dofs to global dofs
    eldofs = [2*elnodes(1)-1 2*elnodes(1) ...
              2*elnodes(2)-1 2*elnodes(2)];
    
    % assemble global stiffness matrix
    K(eldofs,eldofs) = K(eldofs,eldofs) + Kel;       
end 
    
% solve displacements of free dofs
% u(doffree) = K(doffree,doffree)^-1 * (f(doffree) - K(doffree,dofspec)*u(dofspec));
u(doffree) = K(doffree,doffree) \ ( f(doffree) - K(doffree,dofspec)*u(dofspec) );

% solve forces/reactions of specified dofs
% f(dofspec) = K(dofspec,doffree)*u(doffree) + K(dofspec,dofspec)*u(dofspec);
f(dofspec) = K(dofspec,:) * u; 

% calculate member Forces
Force = zeros(Nel,1);
for i = 1:Nel        
    elnodes = elems(i,:);
    node1 = nodes(elnodes(1),:);
    node2 = nodes(elnodes(2),:);
    
    % determine length of member
    dx = node2(1)-node1(1); dy = node2(2)-node1(2);
    L  = sqrt(dx^2 + dy^2);

    % determine direction cosines
    l = dx/L;  m = dy/L;

    k    = (Area(i)*E(i))/L;

    % axial direction vector
    la   = [ l m -l -m ];
    
    % map element dofs to global dofs
    eldofs = [2*elnodes(1)-1 2*elnodes(1) ...
              2*elnodes(2)-1 2*elnodes(2)];

    Force(i)= la*u(eldofs)*k;  
end  

% calculate stresses
stress = Force ./ Area;

varargout{1} = stress;
varargout{2} = u;
varargout{3} = K(doffree,doffree);

end       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [nodes, elems, E, bc, Area] = newtopo(Positions,femmodel)
%
% This function determines the new topology of the structure by
% removing the nodes without members attached and elements with 
% zero area.
%
    [nodes, elems, E, bc] = femmodel();
    not_included = [];
    
    for i=1:size(nodes,1)
       a = find (elems(:,1) == i); 
       b = find (elems(:,2) == i); 
       a1 = [a; b];
       itr = 0;
       for j=1:size(a1,1)
           if Positions(a1(j)) == 0
               itr=itr+1;
           end
       end
       
       % remove nodes that are not included 
       if itr == size(a1,1), not_included = [not_included i]; end    
    end
    
    nodes(not_included,:) = [];
    zeromem = find(Positions == 0);
    elems(zeromem,:) = [];
    
    Area = Positions;
    Area(zeromem) = [];

end