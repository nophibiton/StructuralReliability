function [probdata] = ferum_truss_inputs(params)
%
% This function defines the probability data of the random variables needed
% for the FERUM.
%

% unpack
no_elements = params.n_elem_to_fail;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% RANDOM VARIABLES
% 
% Details of random variable distribution
% 
% RV     | Mean          | COV     | Dist. type    |     
% --------------------------------------------------
% C      | exp(-29.75)   | 0.533   | Lognormal     |
% a0i,mm | 0.11          | 1.0     | Exponential   |
% ad,mm  | 5.0           | 1.0     | Exponential   |
% S      | 1.0           | 0.1     | Lognormal     |     
%
mean_C   = 1.8e-13; % Paris equation parameter [mm/cycle/(MPa mm)^(paris parameter m)]
mean_ai  = 0.15;        % initial crack growth [mm]
mean_S   = 1.0;         % load scale factor I [-]
mean_ad  = params.mean_ad;  % detectable size of no detection, inequality: case g(X) < 0, [mm]

% Define random variable distribution
for k = 1:no_elements
    probdata.marg(k,:)               = [ 2  mean_C    0.544*mean_C mean_C   0 0 0 0 0]; % paris parameter C
    probdata.marg(k+1*no_elements,:) = [ 2  mean_ai   0.66*mean_ai mean_ai  0 0 0 0 0]; % initial crack length
end
    probdata.marg(2*no_elements+1,:) = [ 4  mean_ad   1.0*mean_ad  mean_ad  0 0 0 0 0];    
    probdata.marg(2*no_elements+2,:) = [ 2  mean_S    0.1*mean_S   mean_S   0 0 0 0 0]; % external force

% Correlation matrix
probdata.correlation   = eye(2*no_elements+2);

for ik=1:no_elements
    for jk=(ik+1):no_elements
        probdata.correlation(ik,jk)=0.0;                         % correlation paris parameter C between two members
        probdata.correlation(ik+no_elements,jk+no_elements)=0.0; % correlation a0 between two members
    end
end
probdata.correlation = max(probdata.correlation,probdata.correlation');
probdata.transf_type = 3;   % Nataf transformation
probdata.Ro_method   = 1;
probdata.flag_sens   = 0;
