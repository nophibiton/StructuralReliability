function [demand,stress] = case_a_mld(d_area,forceapplied,n_elem_to_fail,failed_members)

    % determine if structure has collapse
    MLlevel = 2;
    isLevelCollapse = zeros(MLlevel,1);
    mem_per_level = {1,[2,3]};
    for i=1:MLlevel
        isLevelCollapse(i) = all(ismember(mem_per_level{i},failed_members)); 
    end

    % calculate stress/demand
    if sum(isLevelCollapse)>0 
        demand = -1*ones(n_elem_to_fail,1); % structure has collapsed
        stress = demand;
    else
        temp_A = d_area';             % area, [mm^2]
        temp_A(failed_members) = 0;
        P        = forceapplied;      % force, [N] 
        
        demand(  1,1) = P./sum(temp_A(1)  );
        demand(2:3,1) = P./sum(temp_A(2:3));
        demand(failed_members,1) = 0;

        stress = demand;
    end

end