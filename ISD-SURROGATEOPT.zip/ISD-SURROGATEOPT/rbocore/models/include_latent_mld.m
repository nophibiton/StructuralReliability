function [p_total_Esys,bcube_results] = include_latent_mld( extraArg,params )
%
% This function calculates the total system failure probability that
% accounts the Latent failure probability of member loss.
%

dv2darea = params.dv2darea;
p_L      = params.p_latent;
dv       = params.dv;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% intact
extraArg.femmodel       = @mld;
extraArg.n_elem_to_fail = 4;
d_area_ii               = dv2darea( dv, 'ground' ); 
[~,~,extraOut_0]        = main_bcube_genz(d_area_ii,extraArg);
p_Esys_0                = max(0, min(extraOut_0.p_Esys_given_insp, 1));


if extraArg.update == false

% 1-member lost
d_area_ii               = dv2darea( dv, 'case_a' );
n_elem_to_fail          = 3;
extraArg.femmodel       = @case_a_mld;
extraArg.n_elem_to_fail = n_elem_to_fail;
extraArg.lsfparams.ac   = d_area_ii(1:n_elem_to_fail)*1000^2/1000;
ferumparams.mean_ad     = extraArg.mean_ad;
ferumparams.n_elem_to_fail = n_elem_to_fail;
extraArg.probdata       = ferum_mld_inputs(ferumparams);
[~,~,extraOut_1a]       = main_bcube_genz(d_area_ii,extraArg);
p_Esys_1a               = max(0, min(extraOut_1a.p_Esys_given_insp, 1));

d_area_ii               = dv2darea( dv, 'case_b' );
n_elem_to_fail          = 3;
extraArg.femmodel       = @case_b_mld;
extraArg.n_elem_to_fail = n_elem_to_fail;
extraArg.lsfparams.ac   = d_area_ii(1:n_elem_to_fail)*1000^2/1000;
ferumparams.mean_ad     = extraArg.mean_ad;
ferumparams.n_elem_to_fail = n_elem_to_fail;
extraArg.probdata       = ferum_mld_inputs(ferumparams);
[~,~,extraOut_1b]       = main_bcube_genz(d_area_ii,extraArg);
p_Esys_1b               = max(0, min(extraOut_1b.p_Esys_given_insp, 1));

% p_Esys_0 : no member loss, ground structure (4 members)
% p_Esys_1a:  1 member loss, case a structure (3 members)
% p_Esys_1b:  1 member loss, case b structure (3 members)

% binomial + total prob theorem
p_total_Esys = ...
      ((1-p_L)^4)*p_Esys_0 ...
    + (2*p_L*(1-p_L)^3)*p_Esys_1a + (2*p_L*(1-p_L)^3)*p_Esys_1b;

bcube_results = {extraOut_0,extraOut_1a,extraOut_1a,...
                            extraOut_1b,extraOut_1b};

% % 2-member lost
% extraArg.femmodel       = @case_c_mld;
% extraArg.n_elem_to_fail = 2;
% params.case_struct      = 'case_c';
% d_area_ii               = dv2darea(params.d, params); 
% [~,~,extraOut_2]        = main_bcube_genz(d_area_ii,extraArg);
% p_Esys_2                = max(0, min(extraOut_2.p_Esys_given_insp, 1));
% 
% % 3-member lost
% extraOut_3 = {};
% p_Esys_3   = 1.0;
% 
% % binomial + total prob theorem
% p_total_Esys = ...
%   ((1-p_latent)^4)*p_Esys_0 ...
% + (2*p_latent*(1-p_latent)^3)*p_Esys_1a + (2*p_latent*(1-p_latent)^3)*p_Esys_1b ...
% + (4*(p_latent^2)*(1-p_latent)^2)*p_Esys_2 + (2*(p_latent^2)*(1-p_latent)^2)...
% + (4*(p_latent^3)*(1-p_latent)^1)*p_Esys_3 ...
% + (p_latent^4);
% 
% bcube_results = {extraOut_0,extraOut_1a,extraOut_1b,extraOut_2,extraOut_3};

else

% 1-member lost
extraArg.inspections    = modify_inspections(1, extraArg.inspections); 
d_area_ii               = dv2darea( dv, 'case_a' );
n_elem_to_fail          = 3;
extraArg.femmodel       = @case_a_mld;
extraArg.n_elem_to_fail = n_elem_to_fail;
extraArg.lsfparams.ac   = d_area_ii(1:n_elem_to_fail)*1000^2/1000;
ferumparams.mean_ad     = extraArg.mean_ad;
ferumparams.n_elem_to_fail = n_elem_to_fail;
extraArg.probdata       = ferum_mld_inputs(ferumparams);
[~,~,extraOut_1a_i]     = main_bcube_genz(d_area_ii,extraArg);
p_Esys_1a_i             = max(0, min(extraOut_1a_i.p_Esys_given_insp, 1));

extraArg.inspections    = modify_inspections(2, extraArg.inspections);
[~,~,extraOut_1a_ii]    = main_bcube_genz(d_area_ii,extraArg);
p_Esys_1a_ii            = max(0, min(extraOut_1a_ii.p_Esys_given_insp, 1));


extraArg.inspections    = modify_inspections(3, extraArg.inspections); 
d_area_ii               = dv2darea( dv, 'case_b' );
n_elem_to_fail          = 3;
extraArg.femmodel       = @case_b_mld;
extraArg.n_elem_to_fail = n_elem_to_fail;
extraArg.lsfparams.ac   = d_area_ii(1:n_elem_to_fail)*1000^2/1000;
ferumparams.mean_ad     = extraArg.mean_ad;
ferumparams.n_elem_to_fail = n_elem_to_fail;
extraArg.probdata       = ferum_mld_inputs(ferumparams);
[~,~,extraOut_1b_i]     = main_bcube_genz(d_area_ii,extraArg);
p_Esys_1b_i             = max(0, min(extraOut_1b_i.p_Esys_given_insp, 1));

extraArg.inspections    = modify_inspections(4, extraArg.inspections);
[~,~,extraOut_1b_ii]    = main_bcube_genz(d_area_ii,extraArg);
p_Esys_1b_ii            = max(0, min(extraOut_1b_ii.p_Esys_given_insp, 1));


p_total_Esys = ...
      ((1-p_L)^4)*p_Esys_0 ...
    + (p_L*(1-p_L)^3)*p_Esys_1a_i + (p_L*(1-p_L)^3)*p_Esys_1a_ii ...
    + (p_L*(1-p_L)^3)*p_Esys_1b_i + (p_L*(1-p_L)^3)*p_Esys_1b_ii;

bcube_results = {extraOut_0,extraOut_1a_i,extraOut_1a_ii, ...
                            extraOut_1b_i,extraOut_1b_ii };

end