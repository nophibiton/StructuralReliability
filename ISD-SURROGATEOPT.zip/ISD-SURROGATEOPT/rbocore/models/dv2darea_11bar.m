function [d_area] = dv2darea_11bar( d, case_struct )
%
% Convert the decision/design variables to corresponding areas of each
% element. This is helpful when there are groupings of elements with the
% same area. That is not all the elements are assigned with unique decision
% variable.
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    switch lower(case_struct)

        case 'case_a'
            % d1 = m7,m9; d2 = m8,m10; d3 = m1; d4 = m2,m3; d5=m4,m5;d6=m6;
            % columns are not considered design variables
            d_area =  [d(1),d(1),d(2),d(3),d(3),d(4),0.03,0.03,0.03,0.03];

        case 'case_b'
            % d1 = m7,m9; d2 = m8,m10; d3 = m1; d4 = m2,m3; d5=m4;d6=m5,m6;
            % columns are not considered design variables
            d_area =  [d(1),d(1),d(2),d(3),d(4),d(4),0.03,0.03,0.03,0.03];

        case 'case_c'
            % d1=m6,m8; d2=m7,m9; d3=m1; d4 = m2,m3; d5=m4;d6=m5;
            % columns are not considered design variables
            d_area =  [d(1),d(1),d(2),d(3),d(4),0.03,0.03,0.03,0.03];

        case 'ground'
            % d1 = m8,m10; d2 = m9,m11; d3 = m1; d4 = m2,m3; d5=m4,m5;d6=m6,m7; 
            % columns are not considered design variables
            d_area =  [d(1),d(1),d(2),d(3),d(3),d(4),d(4),0.03,0.03,0.03,0.03];
    end


end