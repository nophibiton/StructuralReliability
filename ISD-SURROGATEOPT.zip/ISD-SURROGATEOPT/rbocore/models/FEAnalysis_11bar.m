function [varargout] = FEAnalysis_11bar(d_area, params)
%
% This function calculates the stresses on the components and redistributes
% it if there are failed members. The demaand is set to -1 if
% system failure is observed.
%
% Input: FEAnalysis(Area, Failed Members)
% Output: Stress, Demand
%

% unpack
failed_members   = params.failed_members;
forceapplied     = params.forceapplied;
femmodel         = params.femmodel;
failure_seq_bank = params.failure_seq_bank;
n_elem_to_fail   = params.n_elem_to_fail;

% FE Analysis for ELEVEN-BAR TRUSS PROBLEM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(failed_members)
    system_failure = false;
else
    % FAIL CRITERIA 1: less than two members are connected to a node
    [nodes, elems, ~, bc] = femmodel();
    Nel     = size(elems,1);    % number of elements
    Nnodes  = size(nodes,1);    % number of nodes
    Ndof    = 2*Nnodes;         % total number of DOFs
    memdofs = zeros(Nel,4);
    connected_member = zeros(Nel,Ndof);
    for i = 1:Nel      
        elnodes = elems(i,:);
        % mapping of local dofs to gloabal dof per member
        eldofs = [2*elnodes(1)-1, 2*elnodes(1), ...
                  2*elnodes(2)-1, 2*elnodes(2)];
        memdofs(i,:) = eldofs;
        connected_member(i,memdofs(i,:)) = 1;
    end
    connected_member(failed_members,:) = 0;
    % determine specified dof/support dofs
    dofspec = [] ;
    for i = 1:size(bc,1)
        thisdof = 2*(bc(i,1)-1) + bc(i,2);
        dofspec = [dofspec, thisdof];     
    end
    % count dof per member
    connected_member_count = sum(connected_member);
    connected_member_count(dofspec) = connected_member_count(dofspec)+1; 
    checks(1) = any( connected_member_count<2 );

    % FAIL CRITERIA 2: unstable (dimension*j-(m+r)>0 : unstable)
    checks(2) = length(failed_members) > 3;

    system_failure = any(checks);
    
end

% (2) calculate stress values
n_elem = length(d_area);     % number of element in the structure
stress = zeros(n_elem,1);
if system_failure == true
    demand = -1*ones(n_elem_to_fail,1);
else
    temp_A = d_area';        % area, [mm^2]
    temp_A(failed_members) = 0;

    P        = forceapplied; % force, [N] 
    loads    = [ 6 1 P ];    % applied load at node 6

    [stress_red,u,K_global] = truss_analysis2D(temp_A,loads,femmodel);
    non_failed              = setdiff(1:n_elem, failed_members);
    stress(non_failed)      = stress_red;

    % FAIL CRITERIA 3: condition number > certain threshold = 10^20
    % FAIL CRITERIA 4: unreasonable displacement
    % u
    % max(abs(u))
    % cond(K_global)
    if cond(K_global) > 10^15 || max(abs(u)) > 10^2
        demand = -1*ones(n_elem_to_fail,1);
    else
        demand = abs(stress(1:n_elem_to_fail));  % assign stress values 
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This part is for saving a dummy number if any member force is zero
% because zero stress is harmful to FORM analysis
demand(abs(demand) < 1e-10) = 1e-10;

varargout{1} = demand;
varargout{2} = stress;