function [cM]= calc_const_cost_mld(d_area, params, cCi)
%
% This function calculates the material construction cost of the multilayer
% Daniels problem.
%
dmax = max(params.d_max);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input
L           = 1.0;         % length, [m]
density     = 7850;        % steel density, [kg/m^3]
cost_per_kg = cCi;         % unit cost, [USD/kg]

% calculate volume
volume  = L*sum( d_area ); % volume, [m^3]

% % Reference design/max design considered
% max_vol = L*sum( dmax*ones(1,4) ); % volume, [m^3]
% cM0     = density * cost_per_kg;
% cM      = cM0 * ( volume / max_vol );

% Construction material cost
cM = 1.0 * 10 * 2 * volume * density * cost_per_kg;
