function [new_mem_id] = recast_mem_id_mld(mem_id, loss_mem_id)

if any(loss_mem_id == [1,2])
    if any(mem_id==[3,4])
        new_mem_id = mem_id-1;
    else
        new_mem_id = 1;
    end
else
    if any(mem_id == [3,4])
        new_mem_id = 3;
    else
        new_mem_id = mem_id;
    end
end

end