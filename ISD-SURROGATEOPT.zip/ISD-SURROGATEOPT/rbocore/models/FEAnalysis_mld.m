function [varargout] = FEAnalysis_mld(d_area, params)
%
% This function calculates the stresses on the components and redistributes
% it if there are failed members. The demaand is set to -1 if
% system failure is observed.
%
% Input: FEAnalysis(Area, Failed Members)
% Output: Stress, Demand
%

% unpack
failed_members   = params.failed_members;
forceapplied     = params.forceapplied;
femmodel         = params.femmodel;
failure_seq_bank = params.failure_seq_bank;
n_elem_to_fail   = params.n_elem_to_fail;

% FE Analysis for MULTILAYER-DANIELS SYSTEM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isempty(failed_members)
    system_failure = false;
else
    n_fs       = length(failed_members);
    system_failure = n_fs >= numel(d_area);
end

% (2) calculate stress values
n_elem         = length(d_area); % number of element in the structure
n_elem_to_fail = length(d_area); % number of elements allowed to fail
stress         = zeros(n_elem,1);
if system_failure == true
    demand = -1*ones(n_elem_to_fail,1);
else

    [demand,stress] = femmodel(d_area,forceapplied,n_elem_to_fail,failed_members);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This part is for saving a dummy number if any member force is zero
% because zero stress is harmful to FORM analysis
demand(abs(demand) < 1e-10) = 1e-10;

varargout{1} = demand(:);
varargout{2} = stress(:);

