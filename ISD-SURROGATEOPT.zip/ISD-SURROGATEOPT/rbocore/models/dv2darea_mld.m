function [d_area] = dv2darea_mld( d, case_struct )
%
% Convert the decision/design variables to corresponding areas of each
% element. This is helpful when there are groupings of elements with the
% same area. That is not all the elements are assigned with unique decision
% variable.
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch lower(case_struct)

    case 'case_a'
        % 1-abovewater element, 2-underwater element
        d_area                = [d(1),d(2),d(2)];

    case 'case_b'
        % 2-abovewater element, 1-underwater element
        d_area                = [d(1),d(1),d(2)];      

    case 'case_c'
        % 1-abovewater element, 1-underwater element
        d_area                = [d(1),d(2)];  

    case 'ground'
        % 2-abovewater element, 2-underwater element
        d_area                = [d(1),d(1),d(2),d(2)];  
end
