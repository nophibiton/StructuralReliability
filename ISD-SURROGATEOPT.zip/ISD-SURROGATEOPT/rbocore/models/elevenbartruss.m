function [nodes, elems, E, bc] = elevenbartruss()
%
% Define the nodes, elements and boundary conditions here.
% nodes (x,y)          - location of nodes in meter
% elems (node1, node2) - element connectivity
% bc (node, dof, disp) - defines the displacement (0 for absolute restraint) 
%                        d of (1-vertical, 2-horizontal) for node i 

s = 1000; % length, [mm]

% nodes definition
%          X     Y
nodes = [  0     0;   % 1
           0     s;   % 2
           0   2*s;   % 3
           s     0;   % 4
           s     s;   % 5
           s   2*s];  % 6

% element connectivity     
elems = [ 1 4; % member 1
          2 5; % member 2
          3 6; % member 3
          2 4; % member 4
          1 5; % member 5
          3 5; % member 6
          2 6; % member 7
          1 2; % member 8
          2 3; % member 9
          4 5; % member 10
          5 6];% member 11
% modulus of elasticity of aluminum
E = 200e3 * ones(1,size(elems,1)); % Youngs modulus, [MPa]

% boundary condition support condition
bc = [ 1 1 0;  
       1 2 0; 
       4 2 0 ]; %boundary conditions

end