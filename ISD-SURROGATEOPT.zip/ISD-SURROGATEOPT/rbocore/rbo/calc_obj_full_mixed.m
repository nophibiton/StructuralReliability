function [ total_LC_cost ] = calc_obj_full_mixed( x, params )
%
% Calculates the objective function which is the total life cylce cost.
%

% unpack parameters
allowed_insp_interval = params.allowed_insp_interval;
bcubeparams           = params.bcubeparams;

% change decision variables to design areas
d            = x(3:end);
dv2darea     = params.dv2darea;
d_area       = dv2darea(d, params.case_struct); % areas/design, [m^2]
params.dv    = d;

% change decision variables to inspection
dt_insp_1    = allowed_insp_interval( x(1) );
dt_insp_2    = allowed_insp_interval( x(2) );

calc_psys    = params.calc_psys;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lsfparams.ac               = d_area(1:params.n_elem_to_fail)*1000^2/1000; % critical crack length [mm]	
lsfparams.v0               = 500e3;     % loading frequence [cylce/year]
lsfparams.N                = params.t_sl*lsfparams.v0;   % no. of load cycles at time point in service life [-]
lsfparams.Y_a              = 3;         % geomtery function, Y(a) [-]
lsfparams.mean_m           = 3;         % Paris equation parameter [-]

ferumparams.mean_ad        = params.mean_ad;
ferumparams.n_elem_to_fail = params.n_elem_to_fail;

bcubeparams.lsfparams      = lsfparams;
bcubeparams.probdata       = ferum_mld_inputs(ferumparams);
params.bcubeparams         = bcubeparams;

% dt_insp_1 corresponds to inspection interval of members under water
% dt_insp_2 corresponds to inspection interval of members above water
dt_insp   = [dt_insp_1,dt_insp_2];

params.dt_insp_1 = dt_insp_1;
params.dt_insp_2 = dt_insp_2;

if (dt_insp_1 == -1) && (dt_insp_2 == -1) 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITHOUT inspection %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    % perform system failure prob.
    [p_Esys_year_bcube,time_i,extraOut] = ...
        calc_psys(d_area,[],params,params.seed );
    
    % calculate total life cycle cost
    [C_total,all_costs] = calc_lifecycle_cost_full(...
        params, false, time_i, [], p_Esys_year_bcube, d_area );

    freq_sorted   = 1;
    N_orig        = 1;

    %%%% save outputs for post-processing
    Costs_ik       = [all_costs; freq_sorted];
    bcube_results  = {extraOut,p_Esys_year_bcube};
else
    %%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITH inspection % 
    %%%%%%%%%%%%%%%%%%%%%%%%

    % Step 1: Simulate nsamples of inspection outcome (IO) history
    [inspection_hist,freq_sorted,~] = sim_insp_hist(d_area,dt_insp, params);            

    % sort total number of original IO history
    N_orig   = sum(freq_sorted);
    m_unique = length(freq_sorted);

    % Step 2: Evaluate the total life cycle cost using the exact or
    %         original system reliability analysis/B-cube
    C_total                = zeros(m_unique,1);
    Costs_ik               = zeros(6,m_unique);
    bcube_results          = cell(m_unique,1);
    params.useSurrogate    = false;
    params.surrogate_model = [];
    params.Xnew            = [];
    for ik = 1:m_unique

        % perform bcube for each IO history
        inspections = inspection_hist(ik).inspections;
        inspections_matrix = inspection_hist(ik).inspections_matrix;
        seed_st_model      = inspection_hist(ik).seed_simul;
        [p_Esys_year_bcube,time_i,extraOut] = ...
            calc_psys(d_area,inspections,params,seed_st_model);
        
        % calculate life cycle cost
        [CT,all_costs] = calc_lifecycle_cost_full( params, true, time_i,...
            inspections_matrix,p_Esys_year_bcube, d_area );
        C_total(ik)    = CT;
    
        %%%% save outputs for post-processing
        Costs_ik(:,ik)     = [all_costs; freq_sorted(ik)];
        bcube_results{ik}  = {extraOut,p_Esys_year_bcube};
    end     

end   

% calculate total life cycle cost
% total = construction + failure + inspection + repair
total_LC_cost = sum(freq_sorted .* C_total) / N_orig;

end