function [LCB_x, extraOutObj] = lcb( x, params )
%
% Calculates the lower confindence bound (lcb) of a possible candidate x 
% using the surrogate model. 
%

% unpack parameters
kappa          = params.kappa;
surrogateModel = params.surrogateModel;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% unpack parameters of the surrogate model
hyp      = surrogateModel.hyp;
meanfunc = surrogateModel.meanfunc;
covfunc  = surrogateModel.covfunc;
likfunc  = surrogateModel.likfunc;
Xtrain   = surrogateModel.X;
ytrain   = surrogateModel.y;
Xmu      = surrogateModel.Xmu;
Xsigma   = surrogateModel.Xsigma;
ymedian  = surrogateModel.ymedian;
yiqr     = surrogateModel.yiqr;

% normalize the input x to be evaluated by the gp model
xtest    = (x-Xmu)./Xsigma;

[~, ~, mu_norm, s2_norm] = gp(hyp, @infGaussLik, ...
                              meanfunc, covfunc, likfunc, ...
                              Xtrain, ytrain, xtest);

% convert to the real space
mu      = mu_norm * yiqr + ymedian;
s2_norm = max(s2_norm,0);
s       = sqrt(s2_norm) * yiqr;

% calculate the low confidence bound (LCB)
LCB_x = mu - kappa*s;

extraOutObj = [];
