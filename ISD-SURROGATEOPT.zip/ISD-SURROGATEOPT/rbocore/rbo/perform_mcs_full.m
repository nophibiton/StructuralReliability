function [p_Esys_year,time_i,mcs_results] = ...
            perform_mcs_full( d_area, inspections, params, seed )
% 
% Performs MCS analysis with respect to time reference ti and inspection
% outcome. Full means that MCS is performed yearly ti to t_sl.

% unpack parameters
extraArg      = params.bcubeparams;
t_sl          = params.t_sl;

extraArg.seed = seed;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p_Esys_year     = 0;
time_i          = 0;
mcs_results     = [];
for ti=1:t_sl
    extraArg.time = ti;
    if all(ti<[inspections.time_i])
        % % A. calculate P(Esys) using Bcube at time t
        % extraArg.update     = false;
        % extraArg.isUseUqlab = true;
        % [~,~,extraOut]    = main_bcube_genz(d_area,extraArg,disOp);
        % p_Esys_given_insp = max(0, min(extraOut.p_Esys_given_insp, 1));
        % p_Esys_year       = [p_Esys_year,p_Esys_given_insp];
        % bcube_results     = [bcube_results,extraOut];

        % B. calculate P(Esys) using MCS at time t
        extraArg.update           = false;
        extraArg.mcs_archive_name = strcat(num2str(params.case_struct),...
              '_with_insp_time',num2str(ti),'_IH1' ); % only consider IH-1
        [mcs_failure_probability,~,extraOut] = main_mcs(d_area,extraArg);
        p_Esys_year = [p_Esys_year,mcs_failure_probability];
        mcs_results = [mcs_results,extraOut];

        time_i = [time_i,ti];

    elseif any([inspections.time_i] == ti)
        
        %%%% probability before inspection
        inspections_annual   = inspections;
        inspections_annual([inspections_annual.time_i]>=ti) = [];
        extraArg.inspections = inspections_annual;

        if isempty(inspections_annual)
            extraArg.update      = false;
            extraArg.isUseUqlab  = true;

            % % A. calculate P(Esys) using Bcube at time t
            % [~,~,extraOut]    = main_bcube_genz(d_area,extraArg,disOp);
            % p_Esys_given_insp = max(0, min(extraOut.p_Esys_given_insp, 1));
            % p_Esys_year       = [p_Esys_year, p_Esys_given_insp];
            % bcube_results     = [bcube_results,extraOut];
    
            % B. calculate P(Esys) using MCS at time t
            extraArg.mcs_archive_name = strcat(num2str(params.case_struct),...
                '_with_insp_time',num2str(ti),'_0_IH1' );
            [mcs_failure_probability,~,extraOut] = main_mcs(d_area,extraArg);
            p_Esys_year = [p_Esys_year,mcs_failure_probability];
            mcs_results = [mcs_results,extraOut];

        else
            extraArg.update      = true;
            extraArg.isUseUqlab  = false;

            % % A. calculate P(Esys) using Bcube at time t
            % [~,~,extraOut]    = main_bcube_genz(d_area,extraArg,disOp);
            % p_Esys_given_insp = max(0, min(extraOut.p_Esys_given_insp, 1));
            % p_Esys_year       = [p_Esys_year, p_Esys_given_insp];
            % bcube_results     = [bcube_results,extraOut];
    
            % B. calculate P(Esys) using MCS at time t
            extraArg.mcs_archive_name = strcat(num2str(params.case_struct),...
                '_with_insp_time',num2str(ti),'_0_IH1' );
            [~,updated_mcs_failure_probability,extraOut] = ...
                                             main_mcs(d_area,extraArg);
            p_Esys_year = [p_Esys_year,updated_mcs_failure_probability];
            mcs_results = [mcs_results,extraOut];

        end
        time_i      = [time_i,ti];

        %%%% probability after inspection
        inspections_annual = inspections;
        inspections_annual([inspections_annual.time_i]>ti) = [];

        extraArg.inspections = inspections_annual;

        % % A. calculate P(Esys) using Bcube at time t
        % extraArg.update      = true;
        % extraArg.isUseUqlab  = false;
        % [~,~,extraOut]       = main_bcube_genz(d_area,extraArg,disOp);
        % p_Esys_given_insp    = max(0, min(extraOut.p_Esys_given_insp, 1));
        % p_Esys_year          = [p_Esys_year,p_Esys_given_insp];
        % bcube_results        = [bcube_results,extraOut];

        % B. calculate P(Esys) using MCS at time t
        extraArg.update           = true;
        extraArg.mcs_archive_name = strcat(num2str(params.case_struct),...
            '_with_insp_time',num2str(ti),'_IH1' );
        [~,updated_mcs_failure_probability,extraOut] = ...
                                          main_mcs (d_area,extraArg);
        p_Esys_year = [p_Esys_year,updated_mcs_failure_probability];
        mcs_results = [mcs_results,extraOut];

        time_i      = [time_i,ti];      

    else

        extraArg.inspections = inspections_annual;

        % % A. calculate P(Esys) using Bcube at time t
        % extraArg.update      = true;
        % extraArg.isUseUqlab  = false;
        % [~,~,extraOut] = main_bcube_genz(d_area,extraArg,disOp);
        % p_Esys_given_insp    = max(0, min(extraOut.p_Esys_given_insp, 1));
        % p_Esys_year          = [p_Esys_year,p_Esys_given_insp];
        % bcube_results        = [bcube_results,extraOut];

        % B. calculate P(Esys) using MCS at time t
        extraArg.update             = true;
        extraArg.mcs_archive_name   = strcat(num2str(params.case_struct),...
            '_with_insp_time',num2str(ti),'_IH1' );
        [~,updated_mcs_failure_probability,extraOut] = ...
                                          main_mcs (d_area,extraArg);
        p_Esys_year = [p_Esys_year,updated_mcs_failure_probability];
        mcs_results = [mcs_results,extraOut]; 

        time_i      = [time_i,ti];
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
