function [p_Esys_lifetime, extraOut] = ...
            perform_mcs( d_area, inspections, params, seed )
% 
% Performs bcube analysis with respect to time reference ti and inspection
% outcome.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unpack parameters
extraArg      = params.bcubeparams;
t_sl          = params.t_sl;

dt_insp_1     = params.dt_insp_1;
dt_insp_2     = params.dt_insp_2;

extraArg.seed = seed;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (dt_insp_1 == -1) && (dt_insp_2 == -1) 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITHOUT inspection %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    extraArg.update     = false;
    extraArg.mcs_archive_name = 'data';
    extraArg.time       = t_sl;
    [mcs_failure_probability,~,extraOut] = main_mcs(d_area,extraArg);
    p_Esys_lifetime          = max( 0, min(mcs_failure_probability, 1) );

else

    %%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITH inspection % 
    %%%%%%%%%%%%%%%%%%%%%%%%

    % set additional B^3 parameters
    extraArg.update      = true;          % update reliability or not    
    extraArg.inspections = inspections;   % inspection strategies    
    extraArg.mcs_archive_name = 'data';
    extraArg.time        = t_sl;
    
    % run bcube analysis
    [~,mcs_failure_probability,extraOut] = main_mcs(d_area,extraArg);
    p_Esys_lifetime   = max(0, min(mcs_failure_probability, 1));

end
