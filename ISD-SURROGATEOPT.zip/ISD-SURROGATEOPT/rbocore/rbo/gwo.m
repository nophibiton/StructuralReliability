function [xbest, fbest, hist] = gwo(n_agents, max_iter, lb, ub, func, options)

gwo_file_dir     = fileparts(mfilename('fullpath'));
gwo_folder       = strcat(gwo_file_dir,'\archive_gwo\'  );

% unpack
calc_obj_gwo   = func.fobj;
objparams  = func.params;
nrun       = options.nrun;
save_fname = options.save_fname;
saveopt    = options.saveopt;
Nrep       = options.Nrep;

% initial parameters
d_size   = length(ub); 
d_min    = lb;
d_max    = ub; 

for r = 1:1:nrun
    
    % initialize wolf positions and wolf memory
    alpha = zeros(1,d_size);   alpha_score = inf;
    beta  = zeros(1,d_size);    beta_score = inf;
    delta = zeros(1,d_size);   delta_score = inf;
    
    % initialize the positions of search agents
    d = rand(n_agents,d_size).*(d_max-d_min)+d_min;
    
    % main loop
    iter = 1;
    while true
       
        %fmt = ['GWO iteration: %5d.' ' Alpha: [%.3f' repmat(' %.3f', 1, numel(alpha)-1) '], Fitness: %.2f.\n' ];
        %fprintf(fmt,iter,alpha, alpha_score);
	    
	    % (1) determine objective and constraint function
	    fitness   = zeros(1,n_agents);
        extraVals =  cell(1,n_agents);
        for i = 1:n_agents                  
            % calculate objective function for each search agent
            [obj,extraOutObj] = calc_obj_gwo( d(i,:),objparams );
            fitness(i)        = obj;
            extraVals{i}      = extraOutObj;
        end
    
	    % for post processing
        for i = 1:n_agents
            pack.wolf(i).position(iter,:)  = d(i,:);
            pack.wolf(i).fitness(iter)     = fitness(i);
        end
	    
	    % (2) determine alpha, beta, delta wolves
        for i = 1:n_agents

            if fitness(i) < alpha_score
            
                delta_score = beta_score;
                delta       = beta;
            
                beta_score  = alpha_score;
                beta        = alpha;
            
                alpha_score = fitness(i);
                alpha       = d(i,:);
            
                alpha_misc_data = extraVals{i}; 
            
            elseif fitness(i) < beta_score
            
                delta_score = beta_score;
                delta       = beta;
            
                beta_score  = fitness(i);
                beta        = d(i,:);
            
            elseif fitness(i) < delta_score
            
                delta_score = fitness(i);
                delta       = d(i,:);
            end

        end
     
        % (3) update the Position of search agents including omegas
        a = 2-iter*((2)/max_iter); % a decreases linearly fron 2 to 0
        for i = 1:n_agents
            for j = 1:d_size   
    
                A1      = 2*a*rand-a;
                C1      = 2*rand;     
                D_alpha = abs(C1*alpha(j)-d(i,j)); 
                X1      = alpha(j)-A1*D_alpha;          
    
                A2      = 2*a*rand-a;
                C2      = 2*rand;     
                D_beta  = abs(C2*beta(j)-d(i,j));
                X2      = beta(j)-A2*D_beta;           
    
                A3      = 2*a*rand-a; 
                C3      = 2*rand;     
                D_delta = abs(C3*delta(j)-d(i,j)); 
                X3      = delta(j)-A3*D_delta;          
    
                d(i,j)  = (X1+X2+X3)/3; 
                
			    % impose limit on design variables
                d(i,j)  = min( d_max(j),max(d_min(j),d(i,j)) ); 
     
            end
        end
        
	    % save data for post-process
        pack.alpha.position(iter,:)      = alpha;
        pack.alpha.fitness_history(iter) = alpha_score;
    
        if saveopt
            file_name = strcat(save_fname,num2str(r),'_gwo_iter_',num2str(iter) );
            file_name = strcat(gwo_folder,file_name);
            save(file_name);
        end
       
        % convergence test
        if (iter >= max_iter), break; end

        if iter > Nrep    
            if abs(pack.alpha.fitness_history(iter) - pack.alpha.fitness_history(iter-Nrep)) < 1e-5
                % optimal objective function value not changing
                break;
            end
            if norm(pack.alpha.position(iter,:) - pack.alpha.position(iter-Nrep,:), 2) < 1e-5
                % optimal point not changing
                break;
            end
        end

        iter = iter+1;
    
    end

    xbest = alpha;
    fbest = alpha_score;
    hist  = pack;

end

