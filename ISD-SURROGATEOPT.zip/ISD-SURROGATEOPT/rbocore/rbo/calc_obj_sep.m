function [obj,extraOutObj ] = calc_obj_sep ( d,params )
%
% Calculate risk for stage 1 of separate risk-based optimization. 
% Stage 1: Cconst + Cfail
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unpack parameters
extraArg     = params.bcubeparams;
t_sl         = params.t_sl;

% change decision variables to design areas
dv2darea     = params.dv2darea;
d_area       = dv2darea(d, params); % areas/design, [m^2]

% unpack cost factors
r                     = params.r;         % discount rate
cC0                   = params.cC0;       % fixed cost of construction
cCi                   = params.cCi;       % construction cost per member
cF                    = params.cF;        % cost of failure

calc_const_cost       = params.calc_const_cost;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set additional B^3 parameters
extraArg.update     = false;
extraArg.isUseUqlab = false;

% run bcube analysis
[Upper_bound,~,bcube_results] = main_bcube_genz(d_area,extraArg);
p_Esys    = max(0, min(Upper_bound, 1));

% Failure cost
C_failure = cF * (1/((1+r)^t_sl)) * (p_Esys);

% Material/design cost
cM      = calc_const_cost(d_area, params, cCi);
C_const = cM + cC0;

% Total life cycle cost
C_total = C_const + C_failure;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

obj         = C_total;
extraOutObj = {[-1,-1],C_total,[-1,-1],[C_failure;C_const;cM],bcube_results};
