function [surrogateModel] = create_M1_gpr( data,params )
%
% Create the surrogate model using GP for each unique inspection interval.
%

% unpack parameters
d_size              = params.d_size;   % size of design variable

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create surrogate models
surrogateModel  = struct;

%%%%
% (A) Prepare data for training

% % remove repeated/duplicate rows
% [~, idx]        = unique(data(:,1:d_size), 'rows', 'stable');
% datasets_unique = data(idx, :);
% % define input and output vars
% X = datasets_unique(:,1:d_size);
% y = min(datasets_unique(:,d_size+1:end), [], 2);

% define input and output vars
X = data(:,1:d_size);
y = min(data(:,d_size+1:end), [], 2);

% z-score scaling of design variables
Xmu                    = mean(X, 1);
Xsigma                 = std(X, 0, 1);
Xsigma(Xsigma < 1e-12) = 1; % protect against zero std

X = (X - Xmu) ./ Xsigma;

ymedian = median(y);
yiqr    = iqr(y);

if yiqr < 1e-12, yiqr = max(std(y), 1e-8); end

yn      = (y - ymedian)/yiqr;
y       = min(max(yn, -3), 3); % clipped for stability

%%%%%
% (B) Train kriging model for regression
% define mean, likelihood, covariance function
meanfunc = @meanZero;
likfunc  = @likGauss;
covfunc  = {@covMaternard, 5};

% initiliaze hyperparameters
if isfield(params,'hyp0') && ~isempty(params.hyp0)
    hyp = params.hyp0;
else
    hyp.cov  = [log(0.5)*ones(d_size,1); log(1)];
    hyp.mean = [];
    hyp.lik  = log(0.05);
end

% train GP model using gpml toolbox
hyp = minimize(hyp, @gp, -200, @infGaussLik, meanfunc, covfunc, ...
                                                    likfunc, X, y);

%%%%
% (C) Save surrogate models for regression
surrogateModel.hyp       = hyp;
surrogateModel.meanfunc  = meanfunc;
surrogateModel.covfunc   = covfunc;
surrogateModel.likfunc   = likfunc;
surrogateModel.X         = X;
surrogateModel.y         = y;
surrogateModel.Xmu       = Xmu;
surrogateModel.Xsigma    = Xsigma;
surrogateModel.ymedian   = ymedian;
surrogateModel.yiqr      = yiqr;

surrogateModel.ell       = exp(hyp.cov(1:d_size));
surrogateModel.sf        = exp(hyp.cov(end));
surrogateModel.sn        = exp(hyp.lik);