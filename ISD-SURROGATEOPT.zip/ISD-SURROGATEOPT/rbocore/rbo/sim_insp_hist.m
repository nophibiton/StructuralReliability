function [inspection_hist_unique,freq_sorted,u_j_unique_sorted,...
         train_samples_idx,predict_samples_idx,IO_unique_sorted] = ...
            sim_insp_hist( d_area, dt_insp, params )
%
% Simulates inspection outcome history for each element i. 1-pertains crack
% is detected while 0-pertains no crack. An exponential probability of 
% detection (PoD) is applied. In the simulation when crack is detected, it 
% is assumed to be repaired completey after.

% unpack parameters
percent_surr          = params.percent_surr;

bcubeparams           = params.bcubeparams;
probdata              = bcubeparams.probdata;
lsfparams             = bcubeparams.lsfparams;

femmodel              = params.femmodel;
forceapplied          = params.forceapplied;
n_elem_to_fail        = params.n_elem_to_fail;
no_elements           = n_elem_to_fail;

FEAnalysis            = params.feanalysis; 

seed                  = params.seed;

t_sl                  = params.t_sl;     % service life time, [year]
t0_insp               = params.t0_insp;  % first year of inspection, [year]
mean_ad               = params.mean_ad;  % mean detectable crack size, [mm]
n_samples             = params.n_samples;% number of inspection outcomes

under_water_index     = params.under_water_index;
above_water_index     = params.above_water_index;

dt_insp_1             = dt_insp(1);
dt_insp_2             = dt_insp(2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initialize
t        = (1:1:t_sl)';        
insp_1   = t0_insp:dt_insp_1:t_sl;
insp_2   = t0_insp:dt_insp_2:t_sl;
inspections_time = unique([insp_1 insp_2]);

% calculate stresses (no prior member failed, intact structure)
FEAparams.n_elem_to_fail   = n_elem_to_fail;
FEAparams.failure_seq_bank = [];
FEAparams.failed_members   = [];
FEAparams.femmodel         = femmodel;
FEAparams.forceapplied     = forceapplied; 
stress                     = FEAnalysis(d_area*1000^2,FEAparams);

% generate random variables for inspection
rng(seed);
probdata.marg              = distribution_parameter(probdata.marg);
analysisopt.echo_flag      = 0;      
probdata                   = modify_correl_mat(probdata,analysisopt);
u2x                        = @(u) u_to_x(u,probdata);
u_j                        = randn(  size(probdata.marg,1), n_samples );

% deterministic variables
m        = lsfparams.mean_m;
v0       = lsfparams.v0;    
Y_a      = lsfparams.Y_a;

p        = 1 - m./2;
inv_p    = 1./p;
K_geom   = Y_a .* sqrt(pi);         

% initialize
inspection_hist = struct('inspections', [], ...
                         'inspection_matrix', [], ...
                         'seed_simul', []);

for ik = 1:n_samples

    rng(seed+ik^2);
    x  = u2x( u_j(:,ik) );  
    
    % random variables
    C  = x(1            :1*no_elements)';
    ai = x(no_elements+1:2*no_elements)';
    S  = x(end)*stress(:)';
    
    % calculate crack length (a_t) at time t derived from Paris law
    a_t = (  p.*C.*((S.*K_geom).^m).*v0.*t + ai.^p  ).^(inv_p);
    
    % truncate simulated a_t with a_c (critical cracked length)
    a_t = cut_at(a_t,lsfparams.ac,no_elements);
    
    % simulate inspection outcomes, 1-crack detected, 0-no crack
    % calculate probability of detection (PoD)
    prob               = 1-exp(-a_t./mean_ad);
    inspection_outcome = rand(size(prob)) <= prob;
    
    % for each element/member, determine the first occurence of detection 
    % in the inspection time. 
    % if crack is detected it is assumed that it is repaired to 'new' which
    % means the crack will restart from t0 and new simulation is needed 
    % after the detection of crack.
    for i_mem = 1:no_elements

        if ismember(i_mem,under_water_index)
            inspections_time_resim = insp_1;
        elseif ismember(i_mem,above_water_index)
            inspections_time_resim = insp_2;
        end
    
        if isempty(inspections_time_resim)
            continue;
        end
    
        [hasOne, firstIdx] = ...
          max(inspection_outcome(inspections_time_resim,i_mem) == 1, [], 1);
        firstIdx = inspections_time_resim(firstIdx);
    
        while firstIdx < t_sl && hasOne == true
            
            % resimulate using FERUM utility functions
            t_sub   = ( 1:t_sl-(firstIdx) )';
            u_j_sub = randn(size(probdata.marg,1), 1);
            x_sub   = u2x( u_j_sub );
        
            % random variables
            C  = x_sub(1          :1*no_elements)';
            ai = x_sub(no_elements+1:2*no_elements)';
            S  = x_sub(end)*stress(:)';
        
            % calculate crack length (a_t) at time t
            a_t = (  p.*C.*((S.*K_geom).^m).*v0.*t_sub + ai.^p  ).^(inv_p);
        
            % truncate simulated a_t with a_c 
            a_t = cut_at(a_t,lsfparams.ac,no_elements);  
        
            % simulate inspection outcomes, 1-crack detected, 0-no crack
            % calculate probability of detection (PoD)
            prob                   = 1-exp(-a_t./mean_ad);
            inspection_outcome_new = rand(size(prob)) <= prob;
           
            % simulate new inspection outcome after repair is done
            inspection_outcome(firstIdx+1:end,i_mem) = ...
                                         inspection_outcome_new(:,i_mem);
    
            % check if there is another crack detected before t_sl
            Idx_range          = find(firstIdx+1<inspections_time_resim);
            [hasOne, firstIdx] = max( inspection_outcome( ...
                     inspections_time_resim(Idx_range),i_mem) == 1, [], 1);
            firstIdx           = inspections_time_resim(Idx_range(firstIdx));
        end
    end
    
    detection_outcomes.Z = inspection_outcome;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    inspections_time(inspections_time==t_sl) = []; % remove last inspection
    
    nT          = numel(inspections_time);
    inspections = struct('time_i',num2cell(inspections_time),...
                         'mem_inspected',[], 'inspection_results',[]);
    
    isInsp1     = ismember(inspections_time, insp_1);
    isInsp2     = ismember(inspections_time, insp_2);
    
    Z_vals      = detection_outcomes.Z;
    
    for i = 1:nT
        ti = inspections_time(i);
    
        % build members list without repeated concatenation
        if isInsp1(i) && isInsp2(i)
            members_inspected = [under_water_index, above_water_index];
        elseif isInsp1(i)
            members_inspected = under_water_index;
        elseif isInsp2(i)
            members_inspected = above_water_index;
        else
            members_inspected = [];
        end
    
        inspections(i).mem_inspected = members_inspected;
    
        if isempty(members_inspected)
            inspections(i).inspection_results = [];
        else
            inspections(i).inspection_results = Z_vals(ti, members_inspected);
        end
    end
    
    % create an inspection matrix
    time_vec = repelem([inspections.time_i], ...
            cellfun(@numel, {inspections.mem_inspected}))';
    mem_vec  = vertcat([inspections.mem_inspected])';
    res_vec  = vertcat([inspections.inspection_results])';
    inspections_matrix = [time_vec, mem_vec, res_vec];

    inspection_hist(ik).inspections        = inspections;
    inspection_hist(ik).inspections_matrix = inspections_matrix;
    inspection_hist(ik).seed_simul         = seed+ik^2;
    inspection_hist(ik).u_j                = u_j(:,ik);
    %inspection_hist(ik).u_j                = u_j(ik,no_elements+1:2*no_elements+1);

    IO(ik, :) = inspections_matrix(:,3);
end

% get unique inspection outcomes
[IO_unique, ia, unique_index] = unique(IO, 'rows');
inspection_hist_unique        = inspection_hist(ia);

% count frequency of each unique row
freq = accumarray(unique_index, 1);

for ik = 1:numel(inspection_hist_unique)
    inspection_hist_unique(ik).freq = freq(ik);
end

% sort according to the frequency of inspection outcome
[~, idx] = sort([inspection_hist_unique.freq], 'descend');
inspection_hist_unique = inspection_hist_unique(idx);
IO_unique_sorted       = IO_unique(idx,:);

% get frequency of IO sorted
freq_sorted       = [inspection_hist_unique.freq]';

% get uj's of IO sorted to be used for making surrogate
u_j_unique_sorted = vertcat(inspection_hist_unique.u_j);

%%%% Determine index in unique IO to evaluate for train and for predict

% (1) fixed e.g. 80% cumulative sum of freq of IOs unique
percent_included = percent_surr;
kth_index = find(cumsum(freq_sorted)/sum(freq_sorted)>=percent_included,1);

% (2) aside from the fixed percent included, determine additional initial
% points or test points for the surrogate model. the selected points will 
% be the ones with largest hamming distance
A = IO_unique_sorted(1:kth_index,:);
B = IO_unique_sorted(kth_index+1:end,:);

% determine the hamming distance of the remaining candidate points to each 
% of the points included above
nB      = size(B,1);
maxDist = zeros(nB,1);
for i = 1:nB
    dists = sum(abs(A - B(i,:)), 2); % Hamming dist to all rows in A
    maxDist(i) = max(dists);         % max distance
end

% select the top candidate points with largest hamming 
% distance from the ones that were previously selected based 
% on the frequency
[~, order] = sort(maxDist, 'descend');
nCand      = min(10,nB);
select_candidates = order(1:nCand) + kth_index;
select_candidates = select_candidates(:)';

train_samples_idx = [1:kth_index, select_candidates];

% determine the index of the remaining samples not yet evaluated
% this samples will be predicted using the surrogate model
m_unique            = length(freq_sorted);
predict_samples_idx = setdiff(1:m_unique, train_samples_idx, 'stable');

resorted_idx        = [train_samples_idx,predict_samples_idx];

%%%% Resort based on 

inspection_hist_unique = inspection_hist_unique(resorted_idx);
freq_sorted            = freq_sorted(resorted_idx);
u_j_unique_sorted      = u_j_unique_sorted(resorted_idx,:);
IO_unique_sorted       = IO_unique_sorted(resorted_idx,:);

train_samples_idx      = 1:length(train_samples_idx);
predict_samples_idx    = setdiff(1:m_unique, train_samples_idx, 'stable');

end

function [a_t_cut] = cut_at(a_t,ac,no_elements)

% [~, nCols] = size(a_t);
% B = a_t;
% for j = 1:nCols
%     % find first row where a_t exceeds ac
%     idx = find(a_t(:,j) > femodel.ac(j), 1, 'first');
%     if ~isempty(idx)
%         % cap the first exceeding element
%         B(idx,j) = femodel.ac(j);
%         % set all subsequent rows in this column to ac
%         B(idx+1:end,j) = femodel.ac(j);
%     end
% end
% a_t = B;

exceed       = a_t > ac;                % logical matrix
first_exceed = cumsum(exceed,1) >= 1;   % true from first exceed onward

ac_mat = repmat(ac, size(a_t,1), 1);

a_t(first_exceed) = ac_mat(first_exceed);

a_t_cut = a_t;

end
