function [p_Esys_lifetime, extraOut] = ...
            perform_bcube_latent( d_area, inspections, params, seed )
% 
% Performs bcube analysis with respect to time reference ti and inspection
% outcome.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unpack parameters
extraArg      = params.bcubeparams;
t_sl          = params.t_sl;
useSurrogate  = params.useSurrogate;
Xnew          = params.Xnew;
mdl           = params.surrogate_model;
dt_insp_1     = params.dt_insp_1;
dt_insp_2     = params.dt_insp_2;

extraArg.seed = seed;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (dt_insp_1 == -1) && (dt_insp_2 == -1) 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITHOUT inspection %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    extraArg.time       = t_sl;
    extraArg.update     = false;
    extraArg.isUseUqlab = false;

    [p_Esys_lifetime,extraOut] = include_platent( extraArg, params );

else

    %%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITH inspection % 
    %%%%%%%%%%%%%%%%%%%%%%%%

    % calculate failure probability given inspection using B3
    if ~useSurrogate
        % set additional B^3 parameters
        extraArg.update      = true;          % update reliability or not    
        extraArg.inspections = inspections;   % inspection strategies    
        extraArg.isUseUqlab  = false;
        extraArg.time        = t_sl;
        
        [p_Esys_lifetime,extraOut] = include_platent(extraArg,params);
    else
        beta_predicted    = predict(mdl, Xnew);
        p_Esys_lifetime   = normcdf(-beta_predicted);
        extraOut          = repmat({p_Esys_lifetime}, 1, 3);
    end

end
