function M2 = create_M2_gpcr(X,Pf_samples,saveFile,verbose)
% CREATE_M2_GPCR
%
% Train and save final hurdle surrogate:
%
%       GPC -> ZERO / POSITIVE
%                    |
%                    +--> conditional GPR for log(Pf)
%
% INPUT
%   X          : N x d predictor matrix
%   Pf_samples : N x 1 failure probabilities
%   saveFile   : optional MAT filename
%
% OUTPUT
%   M2         : structure containing complete surrogate model
%
% Example:
%
%   M2 = create_M2_gpcr(X,Pf_samples,'M2_gpcr.mat');
%
% The returned/saved model can be used with:
%
%   Pf_hat = predict_M2_gpcr(M2,Xnew);
%
% GPML toolbox must be available.

%% ========================================================================
% 0. INPUT
% ========================================================================

if nargin < 3 || isempty(saveFile)
    saveFile = 'M2_gpcr.mat';
end

if nargin < 4 || isempty(verbose)
    verbose = false;
end

if verbose
    print = @(varargin) fprintf(varargin{:});
else
    print = @(varargin) [];
end


Pf = Pf_samples(:);

[N,d] = size(X);

if length(Pf) ~= N
    error('X and Pf_samples must have the same number of samples.');
end

if any(~isfinite(X(:)))
    error('X contains NaN or Inf.');
end

if any(~isfinite(Pf))
    error('Pf_samples contains NaN or Inf.');
end

if any(Pf < 0) || any(Pf > 1)
    error('Pf_samples must satisfy 0 <= Pf <= 1.');
end


%% ========================================================================
% 1. CLASSIFICATION LABEL
% ========================================================================

pf_threshold = normcdf(-8);

classLabel = ones(N,1);
classLabel(Pf <= pf_threshold) = -1;

nPOS  = sum(classLabel == 1);
nZERO = sum(classLabel == -1);

print('\n');
print('====================================================\n');
print('TRAINING FINAL M2 GPC + GPR SURROGATE\n');
print('====================================================\n');

print('Samples       = %d\n',N);
print('Predictors    = %d\n',d);
print('POS samples   = %d\n',nPOS);
print('ZERO samples  = %d\n',nZERO);
print('Pf threshold  = %.6e\n',pf_threshold);

% Determine robust model type.  The surrogate may be retrained while the
% RBO database is still sparse, so zero or one POS sample must not crash it.
if nPOS == 0
    modelMode = 'all_zero';
    useClassifier = false;
    useGPR = false;
elseif nZERO == 0 && nPOS == 1
    modelMode = 'constant_positive';
    useClassifier = false;
    useGPR = false;
elseif nZERO > 0 && nPOS == 1
    modelMode = 'gpc_constant_positive';
    useClassifier = true;
    useGPR = false;
elseif nZERO == 0
    modelMode = 'gpr_only';
    useClassifier = false;
    useGPR = true;
else
    modelMode = 'hurdle';
    useClassifier = true;
    useGPR = true;
end

idxPOS = classLabel == 1;
if nPOS > 0
    PfPositiveFallback = median(Pf(idxPOS));
else
    PfPositiveFallback = pf_threshold;
end

print('Model mode    = %s\n',modelMode);


%% ========================================================================
% 2. GP DEFINITIONS
% ========================================================================

% Classifier
meanfuncC = @meanZero;
covfuncC  = {@covMaternard,5};
likfuncC  = @likErf;
inffuncC  = @infLaplace;

% Regression
meanfuncR = @meanZero;
covfuncR  = {@covMaternard,5};
likfuncR  = @likGauss;
inffuncR  = @infGaussLik;


%% ========================================================================
% 3. TRAIN FINAL GPC
% ========================================================================

if useClassifier

    print('\n');
    print('----------------------------------------------------\n');
    print('Training final GP classifier\n');
    print('----------------------------------------------------\n');

    muXC = mean(X,1);
    sdXC = std(X,[],1);
    sdXC(sdXC < 1e-12) = 1;
    XtrainC = (X-muXC)./sdXC;

    hypC.mean = [];

    hypC.cov  = [ zeros(d,1); log(1)];
    hypC.lik  = [];

    tic;

    hypC = minimize(...
                    hypC,...
                    @gp,...
                    -100,...
                    inffuncC,...
                    meanfuncC,...
                    covfuncC,...
                    likfuncC,...
                    XtrainC,...
                    classLabel);

    timeGPC = toc;

    ellC = exp(hypC.cov(1:d));

    print('GPC training completed in %.2f s.\n',timeGPC);
    print('\nGPC ARD length scales:\n');

    for jj = 1:d
        print('X%d : %.6g\n',jj,ellC(jj));
    end

else

    % No classifier because all samples belong to POS class

    muXC = [];
    sdXC = [];
    XtrainC = [];
    hypC = [];
    ellC = [];
    timeGPC = 0;

end

%% ========================================================================
% 4-7. PREPARE AND TRAIN CONDITIONAL GPR (WHEN POSSIBLE)
% ========================================================================

if useGPR
    Xpos = X(idxPOS,:);
    Ppos = Pf(idxPOS);
    y = log(Ppos);

    yMean = mean(y);
    yStd = std(y);
    if yStd < 1e-12
        yStd = 1;
    end
    yz = (y-yMean)./yStd;

    print('\nPositive Pf response:\n');
    print('log(Pf) mean = %.6f\n',yMean);
    print('log(Pf) std  = %.6f\n',yStd);
    print('log(Pf) min  = %.6f\n',min(y));
    print('log(Pf) max  = %.6f\n',max(y));

    muXR = mean(Xpos,1);
    sdXR = std(Xpos,[],1);
    sdXR(sdXR < 1e-12) = 1;
    XtrainR = (Xpos-muXR)./sdXR;

    print('\n----------------------------------------------------\n');
    print('Training final conditional GP regression\n');
    print('----------------------------------------------------\n');

    hypR.mean = [];
    hypR.cov = [zeros(d,1); log(1)];
    hypR.lik = log(0.1);

    tic;
    hypR = minimize(hypR,@gp,-100,inffuncR,meanfuncR,covfuncR,likfuncR,XtrainR,yz);
    timeGPR = toc;
    ellR = exp(hypR.cov(1:d));

    print('GPR training completed in %.2f s.\n',timeGPR);
    print('\nGPR ARD length scales:\n');
    for jj = 1:d
        print('X%d : %.6g\n',jj,ellR(jj));
    end
else
    Xpos = X(idxPOS,:);
    Ppos = Pf(idxPOS);
    y = []; yz = [];
    yMean = []; yStd = [];
    muXR = []; sdXR = []; XtrainR = [];
    hypR = []; ellR = []; timeGPR = 0;
    print('\nSkipping GPR: fewer than two positive Pf samples.\n');
end

%% ========================================================================
% STRICT LOOCV FOR COMPLETE GPC + GPR HURDLE MODEL
%
% Automatically handles:
%
%   1. all ZERO training samples
%          -> predict ZERO
%
%   2. all POSITIVE training samples
%          -> GPR only
%
%   3. mixed ZERO/POSITIVE training samples
%          -> GPC classification
%          -> GPR conditional on predicted POSITIVE
%
% IMPORTANT:
% All scaling and GP hyperparameters are estimated using the
% training fold only. Therefore there is no information leakage.
% ========================================================================

print('\n');
print('====================================================\n');
print('STRICT LOOCV - COMPLETE GPC + GPR MODEL\n');
print('====================================================\n');

PfCV       = nan(N,1);
classCV    = nan(N,1);
pPosCV     = nan(N,1);

for ii = 1:N

    %% --------------------------------------------------------------------
    % Training / validation split
    % ---------------------------------------------------------------------

    idxTrain = true(N,1);
    idxTrain(ii) = false;

    Xtr = X(idxTrain,:);
    Ptr = Pf(idxTrain);

    Xte = X(ii,:);


    %% --------------------------------------------------------------------
    % Classification labels in training fold
    % ---------------------------------------------------------------------

    classTr = ones(length(Ptr),1);

    classTr(Ptr <= pf_threshold) = -1;

    nPosTr  = sum(classTr == 1);
    nZeroTr = sum(classTr == -1);


    %% ====================================================================
    % CASE 1:
    % Training fold contains only ZERO observations
    % =====================================================================

    if nPosTr == 0

        classCV(ii) = -1;

        pPosCV(ii) = 0;

        PfCV(ii) = pf_threshold;

        continue;

    end


    %% ====================================================================
    % CASE 2:
    % Training fold contains only POSITIVE observations
    %
    % No classifier can be trained.
    % Use GPR directly.
    % =====================================================================

    if nZeroTr == 0

        classCV(ii) = 1;

        pPosCV(ii) = 1;

        % --------------------------------------------------------------
        % Positive training data
        % --------------------------------------------------------------

        XtrR = Xtr;
        PtrR = Ptr;

        % A one-point all-positive training fold cannot support GPR.
        if numel(PtrR) == 1
            PfCV(ii) = min(max(PtrR(1),pf_threshold),1);
            continue;
        end

        % --------------------------------------------------------------
        % Standardize input using training fold only
        % --------------------------------------------------------------

        muXRcv = mean(XtrR,1);

        sdXRcv = std(XtrR,[],1);

        sdXRcv(sdXRcv < 1e-12) = 1;


        XtrRz = ...
            (XtrR-muXRcv)./sdXRcv;

        XteRz = ...
            (Xte-muXRcv)./sdXRcv;


        % --------------------------------------------------------------
        % Standardize log(Pf)
        % --------------------------------------------------------------

        yR = log(PtrR);

        yMeanCV = mean(yR);

        yStdCV = std(yR);

        if yStdCV < 1e-12
            yStdCV = 1;
        end

        yzR = ...
            (yR-yMeanCV)./yStdCV;


        % --------------------------------------------------------------
        % Train GPR
        % --------------------------------------------------------------

        hypRCV.mean = [];

        hypRCV.cov = [...
            zeros(d,1);...
            log(1)];

        hypRCV.lik = log(0.1);


        hypRCV = minimize(...
            hypRCV,...
            @gp,...
            -100,...
            inffuncR,...
            meanfuncR,...
            covfuncR,...
            likfuncR,...
            XtrRz,...
            yzR);


        % --------------------------------------------------------------
        % Predict validation observation
        % --------------------------------------------------------------

        [~,~,fmuRcv,~] = gp(...
            hypRCV,...
            inffuncR,...
            meanfuncR,...
            covfuncR,...
            likfuncR,...
            XtrRz,...
            yzR,...
            XteRz);


        muLogCV = ...
            yMeanCV + yStdCV*fmuRcv;


        % Use latent GP mean.
        %
        % DO NOT use:
        % exp(muLogCV + 0.5*variance)
        %
        % because this caused the previous Pf explosion.
        % --------------------------------------------------------------

        PfCV(ii) = ...
            exp(muLogCV);


        PfCV(ii) = ...
            min(max(PfCV(ii),pf_threshold),1);


        continue;

    end


    %% ====================================================================
    % CASE 3:
    % Mixed ZERO and POSITIVE observations
    %
    % Train GPC first
    % =====================================================================

    % ---------------------------------------------------------------------
    % Standardize classifier inputs using training fold only
    % ---------------------------------------------------------------------

    muXCcv = mean(Xtr,1);

    sdXCcv = std(Xtr,[],1);

    sdXCcv(sdXCcv < 1e-12) = 1;


    XtrCz = ...
        (Xtr-muXCcv)./sdXCcv;

    XteCz = ...
        (Xte-muXCcv)./sdXCcv;


    % ---------------------------------------------------------------------
    % Train GPC
    % ---------------------------------------------------------------------

    hypCCV.mean = [];

    hypCCV.cov = [...
        zeros(d,1);...
        log(1)];

    hypCCV.lik = [];


    hypCCV = minimize(...
        hypCCV,...
        @gp,...
        -100,...
        inffuncC,...
        meanfuncC,...
        covfuncC,...
        likfuncC,...
        XtrCz,...
        classTr);


    % ---------------------------------------------------------------------
    % GPC prediction
    % ---------------------------------------------------------------------

    [~,~,fmuCcv,fs2Ccv] = gp(...
        hypCCV,...
        inffuncC,...
        meanfuncC,...
        covfuncC,...
        likfuncC,...
        XtrCz,...
        classTr,...
        XteCz);


    fs2Ccv = max(fs2Ccv,0);


    % Approximate probability of POSITIVE class
    % ---------------------------------------------------------------------

    pPosCV(ii) = ...
        normcdf(...
        fmuCcv ./ sqrt(1 + fs2Ccv));


    % Hard hurdle classification
    % ---------------------------------------------------------------------

    if pPosCV(ii) < 0.5

        % Predicted ZERO
        classCV(ii) = -1;

        PfCV(ii) = pf_threshold;

        continue;

    end


    %% ====================================================================
    % GPC predicted POSITIVE
    % Train conditional GPR using TRUE positive observations
    % in the training fold.
    % =====================================================================

    classCV(ii) = 1;


    idxPosTr = ...
        classTr == 1;


    XtrR = ...
        Xtr(idxPosTr,:);

    PtrR = ...
        Ptr(idxPosTr);


    %% --------------------------------------------------------------------
    % Safety fallback:
    % only one positive training observation
    % ---------------------------------------------------------------------

    if length(PtrR) == 1

        PfCV(ii) = PtrR(1);

        PfCV(ii) = ...
            min(max(PfCV(ii),pf_threshold),1);

        continue;

    end


    %% --------------------------------------------------------------------
    % Standardize GPR input using POSITIVE training samples only
    % ---------------------------------------------------------------------

    muXRcv = ...
        mean(XtrR,1);

    sdXRcv = ...
        std(XtrR,[],1);

    sdXRcv(sdXRcv < 1e-12) = 1;


    XtrRz = ...
        (XtrR-muXRcv)./sdXRcv;

    XteRz = ...
        (Xte-muXRcv)./sdXRcv;


    %% --------------------------------------------------------------------
    % Standardize log(Pf)
    % ---------------------------------------------------------------------

    yR = ...
        log(PtrR);


    yMeanCV = ...
        mean(yR);


    yStdCV = ...
        std(yR);


    if yStdCV < 1e-12
        yStdCV = 1;
    end


    yzR = ...
        (yR-yMeanCV)./yStdCV;


    %% --------------------------------------------------------------------
    % Train conditional GPR
    % ---------------------------------------------------------------------

    hypRCV.mean = [];

    hypRCV.cov = [...
        zeros(d,1);...
        log(1)];

    hypRCV.lik = ...
        log(0.1);


    hypRCV = minimize(...
        hypRCV,...
        @gp,...
        -100,...
        inffuncR,...
        meanfuncR,...
        covfuncR,...
        likfuncR,...
        XtrRz,...
        yzR);


    %% --------------------------------------------------------------------
    % Predict log(Pf)
    % ---------------------------------------------------------------------

    [~,~,fmuRcv,~] = gp(...
        hypRCV,...
        inffuncR,...
        meanfuncR,...
        covfuncR,...
        likfuncR,...
        XtrRz,...
        yzR,...
        XteRz);


    muLogCV = ...
        yMeanCV + yStdCV*fmuRcv;


    %% --------------------------------------------------------------------
    % Back-transform
    % ---------------------------------------------------------------------

    PfCV(ii) = ...
        exp(muLogCV);


    % Physical limits
    % ---------------------------------------------------------------------

    PfCV(ii) = ...
        min(max(PfCV(ii),pf_threshold),1);

end


%% ========================================================================
% COMBINED GPC + GPR CROSS-VALIDATION PERFORMANCE
% ========================================================================

validIdx = ...
    isfinite(PfCV) & ...
    isfinite(Pf);


PfTrueCV = ...
    Pf(validIdx);


PfPredCV = ...
    PfCV(validIdx);


errCombined = ...
    PfPredCV - PfTrueCV;


%% ------------------------------------------------------------------------
% MAE
% -------------------------------------------------------------------------

MAE_combined = ...
    mean(abs(errCombined));


%% ------------------------------------------------------------------------
% RMSE
% -------------------------------------------------------------------------

RMSE_combined = ...
    sqrt(mean(errCombined.^2));


%% ------------------------------------------------------------------------
% R2
% -------------------------------------------------------------------------

SSres = ...
    sum(errCombined.^2);


SStot = ...
    sum((PfTrueCV-mean(PfTrueCV)).^2);


if SStot > 0

    R2_combined = ...
        1 - SSres/SStot;

else

    R2_combined = NaN;

end


%% ------------------------------------------------------------------------
% Relative errors
%
% Only meaningful for Pf > threshold.
% Do not calculate relative errors for ZERO/floor responses.
% -------------------------------------------------------------------------

idxRelative = ...
    PfTrueCV > pf_threshold;


if any(idxRelative)

    relativeError = ...
        abs(...
        PfPredCV(idxRelative) - ...
        PfTrueCV(idxRelative)) ./ ...
        PfTrueCV(idxRelative);


    MAPE_combined = ...
        100*mean(relativeError);


    maxRelativeError = ...
        100*max(relativeError);

else

    MAPE_combined = NaN;

    maxRelativeError = NaN;

end


%% ========================================================================
% CLASSIFICATION PERFORMANCE
% ========================================================================

trueClassCV = ...
    ones(N,1);

trueClassCV(Pf <= pf_threshold) = -1;


TP = sum(...
    trueClassCV == 1 & ...
    classCV == 1);


TN = sum(...
    trueClassCV == -1 & ...
    classCV == -1);


FP = sum(...
    trueClassCV == -1 & ...
    classCV == 1);


FN = sum(...
    trueClassCV == 1 & ...
    classCV == -1);


%% ------------------------------------------------------------------------
% Classification metrics
% -------------------------------------------------------------------------

classificationAccuracy = ...
    (TP + TN)/N;


if (TP + FN) > 0

    sensitivity = ...
        TP/(TP + FN);

else

    sensitivity = NaN;

end


if (TN + FP) > 0

    specificity = ...
        TN/(TN + FP);

else

    specificity = NaN;

end


if isfinite(sensitivity) && ...
   isfinite(specificity)

    balancedAccuracy = ...
        0.5*(sensitivity + specificity);

else

    balancedAccuracy = NaN;

end


if (TP + FP) > 0

    precision = ...
        TP/(TP + FP);

else

    precision = NaN;

end


if isfinite(precision) && ...
   isfinite(sensitivity) && ...
   (precision + sensitivity) > 0

    F1 = ...
        2*precision*sensitivity / ...
        (precision + sensitivity);

else

    F1 = NaN;

end


%% ========================================================================
% PRINT COMBINED RESULTS
% ========================================================================

print('\n');
print('====================================================\n');
print('COMBINED GPC + GPR LOOCV PERFORMANCE\n');
print('====================================================\n');

print('Validation samples = %d\n',...
    sum(validIdx));

print('\nRegression / final Pf prediction:\n');

print('Pf MAE             = %.6e\n',...
    MAE_combined);

print('Pf RMSE            = %.6e\n',...
    RMSE_combined);

print('R2                 = %.6f\n',...
    R2_combined);

print('MAPE (POS only)    = %.4f %%\n',...
    MAPE_combined);

print('Max rel err (POS)  = %.4f %%\n',...
    maxRelativeError);


print('\nClassification:\n');

print('TP = %d\n',TP);
print('TN = %d\n',TN);
print('FP = %d\n',FP);
print('FN = %d\n',FN);

print('Accuracy          = %.4f\n',...
    classificationAccuracy);

print('Sensitivity       = %.4f\n',...
    sensitivity);

print('Specificity       = %.4f\n',...
    specificity);

print('Balanced accuracy = %.4f\n',...
    balancedAccuracy);

print('Precision         = %.4f\n',...
    precision);

print('F1                = %.4f\n',...
    F1);


%% ========================================================================
% PRINT INDIVIDUAL CV PREDICTIONS
% ========================================================================

print('\n');
print(' Actual Pf       CV Predicted Pf      Error\n');
print('----------------------------------------------------\n');

for ii = 1:N

    print('%12.6e    %12.6e    %+12.6e\n',...
        Pf(ii),...
        PfCV(ii),...
        PfCV(ii)-Pf(ii));

end
%% ========================================================================
% 8. CREATE COMPLETE MODEL STRUCTURE
% ========================================================================

M2 = struct;

% General information
M2.name    = 'M2 GPC + conditional GPR hurdle surrogate';
M2.version = 'standardized-log-v1';

M2.N = N;
M2.d = d;

M2.pf_threshold  = pf_threshold;
M2.modelMode = modelMode;
M2.useClassifier = useClassifier;
M2.useGPR = useGPR;
M2.PfPositiveFallback = PfPositiveFallback;

M2.classificationThreshold = 0.5;

% ------------------------------------------------------------------------
% GPC
% ------------------------------------------------------------------------

M2.GPC.meanfunc = meanfuncC;
M2.GPC.covfunc  = covfuncC;
M2.GPC.likfunc  = likfuncC;
M2.GPC.inffunc  = inffuncC;

M2.GPC.hyp      = hypC;
M2.GPC.Xtrain   = XtrainC;
M2.GPC.ytrain   = classLabel;

M2.GPC.muX      = muXC;
M2.GPC.sdX      = sdXC;

M2.GPC.ARDLengthScale = ellC;

% ------------------------------------------------------------------------
% GPR
% ------------------------------------------------------------------------

M2.GPR.meanfunc = meanfuncR;
M2.GPR.covfunc  = covfuncR;
M2.GPR.likfunc  = likfuncR;
M2.GPR.inffunc  = inffuncR;
M2.GPR.hyp      = hypR;

M2.GPR.Xtrain   = XtrainR;
M2.GPR.ytrain   = yz;

M2.GPR.muX      = muXR;
M2.GPR.sdX      = sdXR;
M2.GPR.yMean    = yMean;
M2.GPR.yStd     = yStd;
M2.GPR.ARDLengthScale = ellR;

% ------------------------------------------------------------------------
% Useful training information
% ------------------------------------------------------------------------

M2.training.nPOS    = nPOS;
M2.training.nZERO   = nZERO;

M2.training.timeGPC = timeGPC;
M2.training.timeGPR = timeGPR;

%% ========================================================================
% STORE CROSS-VALIDATION PERFORMANCE
% ========================================================================

M2.performance = struct;


% ------------------------------------------------------------------------
% Combined final Pf prediction performance
% ------------------------------------------------------------------------

M2.performance.CV_MAE = ...
    MAE_combined;

M2.performance.CV_RMSE = ...
    RMSE_combined;

M2.performance.CV_R2 = ...
    R2_combined;

M2.performance.CV_MAPE = ...
    MAPE_combined;

M2.performance.CV_MaxRelativeError = ...
    maxRelativeError;


% ------------------------------------------------------------------------
% CV predictions
% ------------------------------------------------------------------------

M2.performance.nValidation = ...
    sum(validIdx);

M2.performance.PfTrue = ...
    PfTrueCV;

M2.performance.PfPred = ...
    PfPredCV;

M2.performance.error = ...
    errCombined;


% ------------------------------------------------------------------------
% Classification performance
% ------------------------------------------------------------------------

M2.performance.classification.TP = TP;
M2.performance.classification.TN = TN;
M2.performance.classification.FP = FP;
M2.performance.classification.FN = FN;

M2.performance.classification.Accuracy = ...
    classificationAccuracy;

M2.performance.classification.Sensitivity = ...
    sensitivity;

M2.performance.classification.Specificity = ...
    specificity;

M2.performance.classification.BalancedAccuracy = ...
    balancedAccuracy;

M2.performance.classification.Precision = ...
    precision;

M2.performance.classification.F1 = ...
    F1;


% ------------------------------------------------------------------------
% Complete CV information
% ------------------------------------------------------------------------

M2.performance.classPred = ...
    classCV;

M2.performance.pPositive = ...
    pPosCV;

%% ========================================================================
% 9. SAVE
% ========================================================================

% save(...
%     saveFile,...
%     'M2',...
%     '-v7.3');
% 
% 
% print('\n');
% print('====================================================\n');
% print('MODEL SAVED\n');
% print('====================================================\n');
% 
% print('File: %s\n',saveFile);
% 
% print('Use:\n');
% print('  S = load(''%s'');\n',saveFile);
% print('  Pf_hat = predict_M2_gpcr(S.M2,Xnew);\n');
% 
% print('====================================================\n');

end