function [p_Esys_lifetime, extraOut] = perform_bcube( ...
                                            d_area, ...
                                            inspections, ...
                                            params, ...
                                            seed)
% 
% Performs bcube analysis with respect to time reference ti and inspection
% outcome.

% unpack parameters
extraArg      = params.bcubeparams;
t_sl          = params.t_sl;
useSurrogate  = params.useSurrogate;
Xnew          = params.Xnew;
mdl           = params.surrogate_model;
dt_insp_1     = params.dt_insp_1;
dt_insp_2     = params.dt_insp_2;

extraArg.seed = seed;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (dt_insp_1 == -1) && (dt_insp_2 == -1) 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITHOUT inspection %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    extraArg.update     = false;
    extraArg.isUseUqlab = false;
    extraArg.time       = t_sl;
    [Upper_bound,~,extraOut] = main_bcube_genz( d_area, extraArg );
    p_Esys_lifetime          = max( 0, min(Upper_bound, 1) );

else

    %%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITH inspection % 
    %%%%%%%%%%%%%%%%%%%%%%%%

    % calculate failure probability given inspection using B3
    if ~useSurrogate
        % set additional B^3 parameters
        extraArg.update      = true;          % update reliability or not    
        extraArg.inspections = inspections;   % inspection strategies    
        extraArg.isUseUqlab  = false;
        extraArg.time        = t_sl;
        
        % run bcube analysis
        [~,~,extraOut]    = main_bcube_genz( d_area,extraArg );
        p_Esys_lifetime   = max(0, min(extraOut.p_Esys_given_insp, 1));
    else
        % beta_predicted    = predict(mdl, Xnew);
        % p_Esys_lifetime   = normcdf(-beta_predicted);
        % extraOut.p_Esys_given_insp = p_Esys_lifetime;

        [p_Esys_lifetime,~,~,~,~]  = predict_M2_gpcr(mdl,Xnew);
        extraOut.p_Esys_given_insp = p_Esys_lifetime;

    end

end
