function [Pf_hat,pPos,classPred,muLog,sdLog] = ...
    predict_M2_gpcr(M2,Xnew)

% PREDICT_M2_GPCR
%
% Predict failure probability using M2 hurdle surrogate.
%
% Automatically handles:
%
%   M2.useClassifier = true
%       GPC -> ZERO/POSITIVE
%       GPR -> Pf if POSITIVE
%
%   M2.useClassifier = false
%       GPR directly
%
%
% OUTPUT:
%
%   Pf_hat     : predicted failure probability
%   pPos       : probability of POSITIVE class
%   classPred  : +1 POSITIVE, -1 ZERO
%   muLog      : predicted mean log(Pf)
%   sdLog      : predicted standard deviation log(Pf)


%% ========================================================================
% 1. INPUT CHECK
% ========================================================================

d = M2.d;


% Single observation supplied as vector
if isvector(Xnew)

    if numel(Xnew) ~= d

        error(['Single Xnew observation contains %d values, ' ...
            'but M2 expects %d predictors.'],...
            numel(Xnew),d);

    end

    Xnew = reshape(Xnew,1,d);

end


[nNew,dNew] = size(Xnew);


if dNew ~= d

    error(['Xnew has size %d x %d, but M2 expects ' ...
        'an N x %d matrix.'],...
        nNew,dNew,d);

end


if any(~isfinite(Xnew(:)))

    error('Xnew contains NaN or Inf.');

end


%% ========================================================================
% 2. CONSTANT / SPARSE MODEL MODES
% ========================================================================

% Backward compatibility with models created before modelMode was stored.
if ~isfield(M2,'modelMode')
    if M2.useClassifier
        modelMode = 'hurdle';
    else
        modelMode = 'gpr_only';
    end
else
    modelMode = M2.modelMode;
end

switch modelMode
    case 'all_zero'
        Pf_hat = M2.pf_threshold*ones(nNew,1);
        pPos = zeros(nNew,1);
        classPred = -ones(nNew,1);
        muLog = nan(nNew,1);
        sdLog = nan(nNew,1);
        return;

    case 'constant_positive'
        Pf_hat = M2.PfPositiveFallback*ones(nNew,1);
        Pf_hat = min(max(Pf_hat,M2.pf_threshold),1);
        pPos = ones(nNew,1);
        classPred = ones(nNew,1);
        muLog = log(Pf_hat);
        sdLog = nan(nNew,1);
        return;
end

%% ========================================================================
% 3. CLASSIFICATION
% ========================================================================

if M2.useClassifier

    % --------------------------------------------------------------------
    % GPC exists
    % --------------------------------------------------------------------

    muXC = ...
        reshape(M2.GPC.muX,1,[]);

    sdXC = ...
        reshape(M2.GPC.sdX,1,[]);


    % Safety check
    if numel(muXC) ~= d || ...
       numel(sdXC) ~= d

        error(['GPC scaling dimensions are inconsistent with M2.d.']);

    end


    % Standardize new observations
    XnewC = ...
        (Xnew-muXC)./sdXC;


    % GPC prediction
    [~,~,fmuC,fs2C] = gp(...
        M2.GPC.hyp,...
        M2.GPC.inffunc,...
        M2.GPC.meanfunc,...
        M2.GPC.covfunc,...
        M2.GPC.likfunc,...
        M2.GPC.Xtrain,...
        M2.GPC.ytrain,...
        XnewC);


    fs2C = ...
        max(fs2C,0);


    % Probability that observation belongs to POSITIVE class
    pPos = ...
        normcdf(...
        fmuC ./ sqrt(1 + fs2C));


    % Hard classification
    classPred = ...
        ones(nNew,1);


    classPred(...
        pPos < M2.classificationThreshold) = -1;


else

    % --------------------------------------------------------------------
    % No classifier was trained.
    %
    % This occurs when all training observations were POSITIVE.
    %
    % Therefore all new observations are passed directly to GPR.
    % --------------------------------------------------------------------

    pPos = ...
        ones(nNew,1);


    classPred = ...
        ones(nNew,1);

end


%% ========================================================================
% 3. INITIALIZE OUTPUT
% ========================================================================

% Default prediction = ZERO/floor probability

Pf_hat = ...
    M2.pf_threshold*ones(nNew,1);


% log-Pf quantities only exist for observations passed through GPR

muLog = ...
    nan(nNew,1);

sdLog = ...
    nan(nNew,1);


%% ========================================================================
% 4. IDENTIFY POSITIVE PREDICTIONS
% ========================================================================

idxPOS = ...
    classPred == 1;


%% ========================================================================
% 5. CONDITIONAL GPR
% ========================================================================

if any(idxPOS)

    % If only one positive training sample exists, there is no defensible
    % GPR fit yet. Use that observed positive Pf whenever GPC predicts POS.
    if isfield(M2,'useGPR') && ~M2.useGPR
        Pf_hat(idxPOS) = M2.PfPositiveFallback;
        muLog(idxPOS) = log(M2.PfPositiveFallback);
        sdLog(idxPOS) = NaN;
    else

    % --------------------------------------------------------------------
    % Retrieve GPR scaling
    % --------------------------------------------------------------------

    muXR = ...
        reshape(M2.GPR.muX,1,[]);


    sdXR = ...
        reshape(M2.GPR.sdX,1,[]);


    % Safety check
    if numel(muXR) ~= d || ...
       numel(sdXR) ~= d

        error(['GPR scaling dimensions are inconsistent with M2.d.']);

    end


    % --------------------------------------------------------------------
    % Standardize POSITIVE observations
    % --------------------------------------------------------------------

    XnewR = ...
        (Xnew(idxPOS,:)-muXR)./sdXR;


    % --------------------------------------------------------------------
    % GPR prediction
    % --------------------------------------------------------------------

    [~,~,fmuR,fs2R] = gp(...
        M2.GPR.hyp,...
        M2.GPR.inffunc,...
        M2.GPR.meanfunc,...
        M2.GPR.covfunc,...
        M2.GPR.likfunc,...
        M2.GPR.Xtrain,...
        M2.GPR.ytrain,...
        XnewR);


    fs2R = ...
        max(fs2R,0);


    % --------------------------------------------------------------------
    % Convert standardized response back to log(Pf)
    % --------------------------------------------------------------------

    muLogPOS = ...
        M2.GPR.yMean + ...
        M2.GPR.yStd*fmuR;


    varLogPOS = ...
        (M2.GPR.yStd^2).*fs2R;


    sdLogPOS = ...
        sqrt(varLogPOS);


    % --------------------------------------------------------------------
    % Store log-space predictions
    % --------------------------------------------------------------------

    muLog(idxPOS) = ...
        muLogPOS;


    sdLog(idxPOS) = ...
        sdLogPOS;


    % --------------------------------------------------------------------
    % Back-transform to Pf
    %
    % IMPORTANT:
    % Use exp(muLog), NOT
    %
    % exp(muLog + 0.5*varLog)
    %
    % because the latter previously caused exploding Pf predictions.
    % --------------------------------------------------------------------

    PfPOS = ...
        exp(muLogPOS);


    % Physical bounds
    PfPOS = ...
        min(...
        max(PfPOS,M2.pf_threshold),...
        1);


    % Store final predictions
    Pf_hat(idxPOS) = ...
        PfPOS;

    end % useGPR / fallback
end


%% ========================================================================
% 6. FINAL SAFETY CHECK
% ========================================================================

if any(~isfinite(Pf_hat))

    error('Non-finite Pf prediction generated by M2.');

end


Pf_hat = ...
    min(...
    max(Pf_hat,M2.pf_threshold),...
    1);

end