function [C_total, all_costs] = calc_lifecycle_cost_full( ...
           params, isInsp, time_i, inspections_matrix, p_Esys_year, d_area)
%
%
%

% unpack function to calculate the construction cost
calc_const_cost       = params.calc_const_cost;

% unpack inspection data
t_sl                  = params.t_sl;     % service life time, [year]
t0_insp               = params.t0_insp;  % first year of inspection, [year]
dt_insp_1             = params.dt_insp_1;
dt_insp_2             = params.dt_insp_2;

% unpack cost factors
r                     = params.r;       % discount rate
cC0                   = params.cC0;     % fixed cost of construction
cCi                   = params.cCi;     % construction cost per member
cF                    = params.cF;      % cost of failure
cI                    = params.cI ;     % cost of inspection per member
cC                    = params.cC;      % fixed cost of inspection campaigns
cR                    = params.cR;      % cost of repair per member

insp_1   = t0_insp:dt_insp_1:t_sl;
insp_2   = t0_insp:dt_insp_2:t_sl;
inspections_time = unique([insp_1 insp_2]);
inspections_time(inspections_time==t_sl) = []; % remove last inspection

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isInsp 

    % Repair cost
    C_repair = 0;
    index    = find(inspections_matrix(:,3)==1);
    if ~isempty(index)
        for i=1:length(index)
            t        = inspections_matrix(index(i),1);
            mem_i    = inspections_matrix(index(i),2);
            C_repair = C_repair + cR(mem_i) * ( 1/((1+r)^t) );
        end
    end

    % Inspection cost
    C_insp = 0;
    % (1) cost of conducting an inspection capaign
    C_insp = C_insp + sum( cC * (1./((1+r).^inspections_time)) );
    % (2) cost of conducting an inspection per member
    for i=1:size(inspections_matrix,1)
        t      = inspections_matrix(i,1);
        mem_i  = inspections_matrix(i,2);
        C_insp = C_insp + cI(mem_i) * ( 1/((1+r)^t) );
    end

else

    % Repair cost
    C_repair = 0;

    % Inspection cost
    C_insp   = 0;
end


p_Esys_annual = [];
for i=2:length(time_i)
    if time_i(i) ~= time_i(i-1) 
        difference    = p_Esys_year(i) - p_Esys_year(i-1);
        p_Esys_annual = [p_Esys_annual, difference];
    end
end
time_ii = 1:length(p_Esys_annual);

% Failure cost
C_failure = sum(cF .* 1 ./ ((1 + r) .^ time_ii) .* (p_Esys_annual));

% Inspection, Maintenance and Failure cost
C_imf   = C_failure + C_insp + C_repair;

% Material/design cost
C_mat   = calc_const_cost(d_area, params, cCi);
C_const = C_mat + cC0;

% Total life cycle cost
C_total = C_const + C_imf;

all_costs = [C_failure; C_insp; C_repair; C_const; C_mat];

end