function [p_Esys_year,time_i,bcube_results] = ...
            perform_bcube_full_latent( d_area, inspections, params, seed )
% 
% Performs bcube analysis with respect to time reference ti and inspection
% outcome. Full means that bcube is done yearly/annually.
%

% unpack parameters
extraArg      = params.bcubeparams;
t_sl          = params.t_sl;
dt_insp_1     = params.dt_insp_1;
dt_insp_2     = params.dt_insp_2;
include_latent= params.include_latent;

extraArg.seed = seed;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p_Esys_year       = 0;
time_i            = 0;            
bcube_results     = [];

if (dt_insp_1 == -1) && (dt_insp_2 == -1) 

    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITHOUT inspection %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    for ti = 1:t_sl
        % Calculate P(Esys) using Bcube at time t
        extraArg.time                 = ti;
        extraArg.update               = false;
        [p_total_Esys,extraOutNoInsp] = ...
            include_latent( extraArg,params );

        p_Esys_given_no_insp           = max(0, min(p_total_Esys, 1));
        p_Esys_year   = [p_Esys_year, p_Esys_given_no_insp];
        time_i        = [time_i,ti];
        bcube_results = [bcube_results;extraOutNoInsp];
    end

else

    %%%%%%%%%%%%%%%%%%%%%%%%
    % Case WITH inspection % 
    %%%%%%%%%%%%%%%%%%%%%%%%

    for ti=1:t_sl
        extraArg.time = ti;
        if all(ti<[inspections.time_i])
            extraArg.update     = false;
            [p_total_Esys,extraOut] = include_latent( extraArg,params );
            p_Esys_given_insp = max(0, min(p_total_Esys, 1));
            p_Esys_year       = [p_Esys_year,p_Esys_given_insp];
            time_i            = [time_i,ti];
            bcube_results     = [bcube_results;extraOut];
    
        elseif any([inspections.time_i] == ti)
            inspections_annual   = inspections;
            inspections_annual([inspections_annual.time_i]>=ti) = [];
            extraArg.inspections = inspections_annual;
            if isempty(inspections_annual)
                extraArg.update      = false; % first year of inspection
                extraArg.isUseUqlab  = false;            
            else
                extraArg.update      = true;
                extraArg.isUseUqlab  = false;
            end
            % probability before inspection
            [p_total_Esys,extraOut] = include_latent( extraArg,params );
            p_Esys_given_insp = max(0, min(p_total_Esys, 1));
            p_Esys_year       = [p_Esys_year, p_Esys_given_insp];
            time_i            = [time_i,ti];
            bcube_results     = [bcube_results;extraOut];
    
            % probability after inspection
            inspections_annual   = inspections;
            inspections_annual([inspections_annual.time_i]>ti) = [];
            extraArg.update      = true;
            extraArg.inspections = inspections_annual;
            extraArg.isUseUqlab  = false;
            [p_total_Esys,extraOut] = include_latent( extraArg,params );
            p_Esys_given_insp    = max(0, min(p_total_Esys, 1));
            p_Esys_year          = [p_Esys_year,p_Esys_given_insp];
            time_i               = [time_i,ti];
            bcube_results        = [bcube_results;extraOut];
    
        else
            extraArg.update      = true;
            extraArg.inspections = inspections_annual;
            extraArg.isUseUqlab  = false;
            [p_total_Esys,extraOut] = include_latent( extraArg,params );
            p_Esys_given_insp    = max(0, min(p_total_Esys, 1));
            p_Esys_year          = [p_Esys_year,p_Esys_given_insp];
            time_i               = [time_i,ti];
            bcube_results        = [bcube_results;extraOut];
        end
    end

end