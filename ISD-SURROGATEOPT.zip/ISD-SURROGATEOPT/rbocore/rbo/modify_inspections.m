function [new_inspections] = modify_inspections(mem_i, inspections)
%
%
%
%


new_inspections = inspections;

for ii=1:numel(inspections)

    idx = find(new_inspections(ii).mem_inspected == mem_i);

    new_inspections(ii).inspection_results(idx) = [];
    new_inspections(ii).mem_inspected(idx)      = [];

    % change the member id due to loss of member
    for jj = 1:numel(new_inspections(ii).mem_inspected)
        mem_id = new_inspections(ii).mem_inspected(jj);
        new_inspections(ii).mem_inspected(jj) = ...
            recast_mem_id_mld(mem_id, mem_i);
    end

end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
