function [xbest, fbest] = find_min_lcb( surrogateModel, params )
%
% Find the next candidate solution by minimizing the LCB evaluated using
% the surrogate model. The acquisition function used here is the LCB.
%

permutations = params.insp_permutations;
kappa        = params.kappa;
Xvals        = params.Xvals;
dstar        = params.dstar;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% define GWO parameters
n_agents = 150;   % number of search agents/wolves
max_iter = 1000;
lb       = params.d_min;
ub       = params.d_max;

% define parameters of objective function
objparams.kappa             = kappa;
objparams.surrogateModel    = surrogateModel;
objparams.insp_permutations = permutations;
objparams.xbest             = dstar;
objparams.lb                = lb;
objparams.ub                = ub;
func.params                 = objparams;
func.fobj                   = @lcb;

% define options
options.nrun         = 1;
options.save_fname   = '';
options.saveopt      = false;
options.Nrep         = 0.15*max_iter;

% determine the next candidate solution or optimum value that has the
% low confidence bound (LCB) value using GWO 
[xbest, fbest, hist] = gwo(n_agents, max_iter, lb, ub, func, options);

% to avoid clustering of added point, when the candidate point with
% lowest LCB is near the values of the previously evaluated training
% points, the next succeeding solutions from GWO are used by sorting
% the from best to least desirable solution depending on the fitness
% values of the population
Xvals_n   = (Xvals - lb) ./ (ub - lb);
xbest_n   = (xbest - lb) ./ (ub - lb);
dist_min  = min(vecnorm(Xvals_n - xbest_n,2,2));
threshold = 0.01;

if dist_min < threshold
    wolf_mat = zeros(n_agents,size(hist.alpha.position,2)+1);
    for i=1:n_agents
        wolf_mat(i,:) = [hist.wolf(i).position(end,:),...
                                            hist.wolf(i).fitness(end)];
    end
    % sort smallest to largest fitness (ascending order)
    wolf_mat_sorted = sortrows(wolf_mat, size(wolf_mat,2));
    for i=1:n_agents
        xcandidate = wolf_mat_sorted(i,1:end-1);
        % select the next candidate that is far enough from previously
        % evaluated candidates in Xvals
        xcandidate_n = (xcandidate - lb) ./ (ub - lb);
        dist_min     = min(vecnorm(Xvals_n - xcandidate_n,2,2));
        if dist_min > threshold
            xbest = xcandidate;
            fbest = wolf_mat_sorted(i,end);
            break;
        end
    end
end
