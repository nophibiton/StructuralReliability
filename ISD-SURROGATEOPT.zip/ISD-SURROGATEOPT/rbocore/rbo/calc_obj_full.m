function [obj,extraOutObj ] = calc_obj_full ( d,params )
%
% Calculates the objective function which is the total life cylce cost (Ct).
% An ehaustive strategy of finding the least Ct among all possible
% inspection interval is used.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unpack parameters
permutations = params.insp_permutations;

% change decision variables to design areas
dv2darea     = params.dv2darea;
d_area       = dv2darea(d, params); % areas/design, [m^2]
params.d     = d;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

total_costs_i = zeros( 1,size(permutations,1) );
var_insp_data =  cell( 1,size(permutations,1) );

% calculate the total life cycle cost for all permuation of the inspection
% intervals for above and underwater elements
for insp_combo_i = 1:size(permutations,1)

    dt_insp_1 = permutations(insp_combo_i,1);
    dt_insp_2 = permutations(insp_combo_i,2);
	% dt_insp_1 corresponds to inspection interval of members under water
	% dt_insp_2 corresponds to inspection interval of members above water
    dt_insp   = [dt_insp_1,dt_insp_2];
    
    params.dt_insp_1 = dt_insp_1;
    params.dt_insp_2 = dt_insp_2;

    if (dt_insp_1 == -1) && (dt_insp_2 == -1) 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Case WITHOUT inspection %
            %%%%%%%%%%%%%%%%%%%%%%%%%%%

            [p_Esys_year_bcube,time_i,extraOut] = ...
            perform_bcube_full(d_area,[],params,params.seed);
            p_Esys_year_bcube
            
            % calculate total life cycle cost
            isInsp = false;
            [C_total,C_failure,C_insp,C_repair,C_const,cM] = ...
                calc_lifecycle_cost_full(params, isInsp, time_i, [], ...
                                         p_Esys_year_bcube, d_area);
    
            freq_sorted   = 1;
            N_orig        = 1;

            %%%% save outputs for post-processing
            Costs_ik = [C_failure;C_insp;C_repair;C_const;cM;freq_sorted];
            bcube_results  = {extraOut,p_Esys_year_bcube};
    else
            %%%%%%%%%%%%%%%%%%%%%%%%
            % Case WITH inspection % 
            %%%%%%%%%%%%%%%%%%%%%%%%

            % simulate nsamples of inspection outcome history
            [inspection_hist,freq_sorted,~] = ...
                sim_insp_hist(d_area,dt_insp, params);            

            % sort total number of original IO history
            N_orig   = sum(freq_sorted);
            m_unique = length(freq_sorted);

            % evaluate the total life cycle cost using the exact or
            % original system reliability analysis/B-cube
            C_total                = zeros(m_unique,1);
            Costs_ik               = zeros(6,m_unique);
            bcube_results          = cell(m_unique,1);
            params.useSurrogate    = false;
            params.surrogate_model = [];
            params.Xnew            = [];

            parfor ik = 1:m_unique

                % perform bcube for each IO history
                inspections = inspection_hist(ik).inspections;
                inspections_matrix = inspection_hist(ik).inspections_matrix;
                seed_st_model      = inspection_hist(ik).seed_simul;
                [p_Esys_year_bcube,time_i,extraOut] = ...
                perform_bcube_full(d_area,inspections,params,seed_st_model);
                
                % calculate life cycle cost
                isInsp = true;
                [CT,C_failure,C_insp,C_repair,C_const,cM] = ...
                   calc_lifecycle_cost_full(params,isInsp, time_i,...
                   inspections_matrix,p_Esys_year_bcube, d_area);
                
                Costs_imfd  = [C_failure;C_insp;C_repair;C_const;cM];
                C_total(ik) = CT;
            
                %%%% save outputs for post-processing
                Costs_ik(:,ik)     = [Costs_imfd; freq_sorted(ik)];
                bcube_results{ik}  = {extraOut,p_Esys_year_bcube};
            end     
    
    end   

    % calculate total life cycle cost
    % total = construction + failure + inspection + repair
    total_costs_i(insp_combo_i) = sum(freq_sorted .* C_total) / N_orig;

    % costs partition [failure, inspection, repair, construction]
    costs_partition = Costs_ik(1:4,:) * freq_sorted / sum(freq_sorted);

    %%%% save outputs for post-processing
    var_insp_data{insp_combo_i} = {Costs_ik,bcube_results,...
                                   costs_partition,time_i};
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% determine the inspection strategy with the least total life cycle cost
[obj, min_idx] = min(total_costs_i);

% save outputs for post processing
extraOutObj    = {var_insp_data, total_costs_i, permutations(min_idx,:),...
                  [permutations,total_costs_i(:)], min_idx};

end