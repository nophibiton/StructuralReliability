function [g, dgdx] = gfunfatigue_lsf1(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

% G1: when no prior member cracked, cracked member before other member
% Ti^0 < Tl^0   : i = failure_seq (failed), l = surviving_mem
% See Equation (7) of Ref. [1]

% unpack
if isfield(gfundata(lsf),'cg')
    cg            = gfundata(lsf).cg;
    lsfparams     = cg{1};
    failure_seq   = cg{2};
    surviving_mem = cg{3};
    ac            = lsfparams.ac;
    mean_m        = lsfparams.mean_m;
    Y_a           = lsfparams.Y_a;
    T_r           = lsfparams.T_r;
    stress        = lsfparams.stress;
    no_elements   = lsfparams.no_elements;
end

% random variables of the member i (other member)
C1 = x(surviving_mem);                     % Paris parameter, C
ai1= x(surviving_mem + 1*no_elements);     % initial crack length, ai
S1 = x(end) * stress(surviving_mem);       % stress range

% deterministic variables of the member i (other member)
ac1= ac(surviving_mem);      % Critical crack length, ac  
m1 = mean_m;                 % Paris parameter, m

% Evaluate integral, Equation (5) or first term of Equation (22a)   
Tl0 = fatigue_integral(ai1, ac1, C1, m1, S1, Y_a);

% random variables of the member j (target member)
C2 = x(failure_seq);
ai2= x(failure_seq + 1*no_elements);
S2 = x(end) * stress(failure_seq);

% deterministic variables of the member j (other member)
ac2 = ac(failure_seq);
m2  = mean_m;

% Evaluate integral, Equation (5) or second term of Equation (22a)
Ti0 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);

% consider repaired members
Ti0 = Ti0 + T_r(failure_seq);
Tl0 = Tl0 + T_r(surviving_mem);

% limit state function
g = Ti0 - Tl0; % Ti^0 < Tl^0 of Equation (7) of Ref. [1]

dgdx = nan;