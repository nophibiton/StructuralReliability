function [g, dgdx] = gfunfatigue_lsf2_red(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)
%
% G2: when no prior member cracked, event of cracked 
%     member i before inspection cycle
% Ti^0 < Ts : Equation (7) of Ref. [1]
%

% unpack
if isfield(gfundata(lsf),'cg')
    cg           = gfundata(lsf).cg;
    lsfparams    = cg{1};
    failure_seq  = cg{2};
    ac           = lsfparams.ac;
    mean_m       = lsfparams.mean_m;
    Y_a          = lsfparams.Y_a;
    N            = lsfparams.N;
    T_r          = lsfparams.T_r;
    stress       = lsfparams.stress;
end

% Single realization, column vector
x   = x(:);

% random variables of the member i (target failed member)
C2  = x(1);
ai2 = x(2);
I2  = x(end); % load scale factor

S2  = I2 * stress(failure_seq);

% deterministic variables of the member i (target failed member)
ac2 = ac(failure_seq);
m2  = mean_m;

% evaluate fatigue integral
T2 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);

% Limit-state function
g  = T2 + T_r(failure_seq) - N;

% Analytical gradient in physical X-space
if grad_flag == 'yes'

    denom     = C2 * (S2*Y_a*sqrt(pi))^m2;

    dgdx      = zeros(numel(x),1);
    
    dgdx(1)   = -T2/C2;             % dG/dC
    dgdx(2)   = -ai2^(-m2/2)/denom; % dG/dai
    dgdx(end) = -m2*T2/I2;          % dG/d(load factor)

else
    dgdx      = nan;
end
