function [Mixed_node, Red_node, demand] = ...
       find_red_node(SRBDO_A, Mixed_node, Red_node, E,FEAparams,FEAnalysis)

% This function determines the index vector for system failure event and 
% saves the probability and vector to red nodes else Red_node_index is set 
% to 0 when no system failure event is found. Identify index vector and 
% probability of system failure and save to Red nodes and calculate 
% redistributed stress/forces remove system sequence event from index 
% vector if system failure event is observed.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% unpack
A = Mixed_node.vector;
B = Mixed_node.probability;
C = Red_node.vector;

max_I = E;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Red_node_vector_temp = zeros(size(C,1), size(A,2));
for i=1:size(C,1)
    for j=1:size(C,2)
        Red_node_vector_temp(i,j) = C(i,j);
    end
end
Red_node.vector = Red_node_vector_temp;

% remove member
remove_member = cut_index_vector( A(max_I,:) );

% calculate stress when member of most likely to fail is removed
FEAparams.failed_members = remove_member;
demand = FEAnalysis(SRBDO_A, FEAparams);

index_vector     = [];
Node_probability = [];

if ~isempty(find(demand < 0, 1)) 
    % Collapse, system failure found:
    % removal of the most likely to fail member will constitute a system
    % collapse of the structure

    % set to 1 if system failure is found
    Red_node.isCollapse = true; 
    
    % add vector for which system failure is found
    Red_node.vector = [Red_node.vector; A(max_I,:)]; 
    
    % record probability of system failure event
    Red_node.probability = [Red_node.probability; B(max_I,:)];
    
    % remove the system failure events sequence from the index vector
    for i=1:size(A,1)
        if (i~=max_I)
            index_vector     = [index_vector; A(i,:)];
            Node_probability = [Node_probability; B(i,:)];
        end        
    end

else

    % Survive, no system failure found:
    % removal of the most likely member to fail will not constitute a
    % system collapse

    Red_node.isCollapse   = false; 
    index_vector          = A;
    Node_probability      = B;
end

Mixed_node.vector      = index_vector;
Mixed_node.probability = Node_probability;

