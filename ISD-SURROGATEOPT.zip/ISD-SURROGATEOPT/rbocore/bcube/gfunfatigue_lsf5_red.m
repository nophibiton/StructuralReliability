function [g,dgdx] = gfunfatigue_lsf5_red(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

% G5
% Inspection event outcome - Inequality case
% TI -Tjd < 0:   Equation (15) of Ref. [2]
%

% unpack
if isfield(gfundata(lsf),'cg')
    cg            = gfundata(lsf).cg;
    lsfparams     = cg{1};
    mean_m        = lsfparams.mean_m;
    Y_a           = lsfparams.Y_a;
    stress        = lsfparams.stress;
    inspected_mem = lsfparams.inspected_mem;
    N_insp        = lsfparams.N_insp;
end

% random variables
C  = x(1 );
ai = x(2 );

% use stress when no prior member has failed
I  = x(end);
S  = I*stress(inspected_mem, 1);
ad = x(3 );

% deterministic variables            
m  = mean_m;

% calculate number of load cycles starting from crack ai to
% detection crack ad.
Njd = fatigue_integral(ai, ad, C, m, S, Y_a);

% Inequality case, no detection
g = N_insp - Njd;

% Analytical gradient in physical X-space
if grad_flag == 'yes'

    denom     = C * (S*Y_a*sqrt(pi))^m;

    dgdx      = zeros(numel(x),1);
    
    dgdx(1)   = Njd/C;            % dG/dC
    dgdx(2)   = ai^(-m/2)/denom;  % dG/dai
    dgdx(3)   = -ad^(-m/2)/denom; % dG/dad
    dgdx(end) = m*Njd/I;          % dG/d(load factor)

else
    dgdx      = nan;
end