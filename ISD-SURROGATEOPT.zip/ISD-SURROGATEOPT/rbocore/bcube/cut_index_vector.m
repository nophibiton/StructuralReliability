function cut_result = cut_index_vector(A)
%
% This function cuts the index vector where it will branch out.
% The zeros at the end of the sequence or index a removed.
%
cut_result = [];

for i=1:length(A)
    if (A(i)~=0)
        cut_result = [cut_result A(i)];
    end
end