function [updated_P_Esys_upper_bound,updated_P_Esys_low_bound,updateextra] = ...
    update_reliability_bounds3(Red_node, Mixed_node, femodel, ...
                            inspect_event, probdata, myInput,failure_paths)

% Calculate PROBABILITY OF INSPECTION event P(IE)
[inspect_event.failure_seq]   = deal([]);
[inspect_event.surviving_mem] = deal([]);

femodel.limit_state_params    = inspect_event;
femodel.Alpha_vector          = [];
femodel.Failure_probability   = [];

[P_IE_sys,Insp_alpha_vector,Insp_failure_probability_results] = ...
run_uqlab_sys_i(myInput, femodel);

updateextra = Insp_failure_probability_results;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) UPDATE LOWER bound probability for each Ci in Eq. (29) of Ref.[2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    Ci                 = Red_node.vector;
    updated_P_Esys_low = zeros( size(Ci,1),1 );


    % retrieve failure sequences
    for fs_i = 1: length(updated_P_Esys_low)    

        % if ( Red_node.probability(fs_i) < 10^(-6) )
        %     % updated_P_Esys_low(fs_i)   = 0;
        %     continue;
        % else
            % load the component limit state parameters and stress results
            k = 1;
            while k <= size(Ci,2) && Ci(fs_i,k) ~= 0 
                if k==1, fname = num2str( Ci(fs_i,k) );
                else,fname = strcat( fname,'_',num2str(Ci(fs_i,k)) );
                end
                k = k+1;
            end

            % load intermediate results of b-cube of the identified system
            % failure sequences
            fs_ind = find(strcmp({failure_paths.fs_name}, fname));
            Component_failure_probability_results = ...
            failure_paths(fs_ind).Component_failure_probability_results;
            Component_alpha_vector = ...
            failure_paths(fs_ind).Component_alpha_vector;

            % combine results of Component and Inspection
            Alpha_vector = [Component_alpha_vector,Insp_alpha_vector];
            Failure_probability = ...
            [Component_failure_probability_results; Insp_failure_probability_results];

            Correlation_matrix  = Alpha_vector'*Alpha_vector;

            % calculate system failure probability using Hohenbichler (1982) 
            % first-order concepts in system rel. + Genz (1992) integration
            % if any( Failure_probability < 10^(-6) ) 
            %     P_Esys_low_uqlab = 0;
            % else
                [ p_qsimvnv, ~] = qsimvnv(20000, Correlation_matrix, ...
                    -inf*ones(1,length(Failure_probability)), ...
                    norminv(Failure_probability)' );
                P_Esys_low_uqlab = p_qsimvnv;
            % end

            updated_P_Esys_low(fs_i) = P_Esys_low_uqlab;

        % end

    end

    Red_node.probability(:)
    updated_P_Esys_low
    sum(updated_P_Esys_low)
    % Update the lower bound given probability of inspection events
    updated_P_Esys_low_bound = (sum(updated_P_Esys_low))/P_IE_sys;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) UPDATE UPPER bound probability for each Li in Eq. (29) of Ref.[2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    Li                   = Mixed_node.vector;
    updated_P_Esys_upper = zeros( size(Li,1),1 );
    
    for fs_i = 1: length(updated_P_Esys_upper) % i-th failure sequence

        % if ( Mixed_node.probability(fs_i) < 10^(-6) )
        %     % updated_P_Esys_upper(fs_i)   = 0;
        %     continue;
        % else
            k = 1;
            while k <= size(Li,2) && Li(fs_i,k) ~= 0 
                if k==1,fname = num2str( Li(fs_i,k) );
                else, fname = strcat( fname,'_',num2str(Li(fs_i,k)) );
                end
                k = k+1;
            end
            fs_ind = find(strcmp({failure_paths.fs_name}, fname));
            Component_failure_probability_results = ...
            failure_paths(fs_ind).Component_failure_probability_results;
            Component_alpha_vector = ...
            failure_paths(fs_ind).Component_alpha_vector;

            % combine results of Component and Inspection
            Alpha_vector = [Component_alpha_vector,Insp_alpha_vector];
            Failure_probability = ...
            [Component_failure_probability_results; Insp_failure_probability_results];

            Correlation_matrix  = Alpha_vector'*Alpha_vector;

            % calculate system failure probability using Hohenbichler (1982) 
            % first-order concepts in system rel. + Genz (1992) integration
            % if any( Failure_probability < 10^(-6) ) 
            %     P_Esys_upper_uqlab = 0;
            % else
                [ p_qsimvnv, ~] = qsimvnv(20000, Correlation_matrix, ...
                    -inf*ones(1,length(Failure_probability)), ...
                    norminv(Failure_probability)' );
                P_Esys_upper_uqlab = p_qsimvnv;
            % end

            updated_P_Esys_upper(fs_i) = P_Esys_upper_uqlab;
            
        % end
    end
    
    Mixed_node.probability
    updated_P_Esys_upper
    sum(updated_P_Esys_upper) + sum(updated_P_Esys_low)
    updated_P_Esys_upper_bound = ...
    ( sum(updated_P_Esys_upper) + sum(updated_P_Esys_low) )/P_IE_sys;

end