function [ G, grad_g ] = gfunfatiguesys(lsf,x,grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

% unpack
if isfield(gfundata(lsf),'cg')
    cg           = gfundata(lsf).cg;
    lsfparams    = cg{1};
    system_event = cg{2};
end

Y_a = lsfparams.Y_a;
T_r = lsfparams.T_r;
no_elements = lsfparams.no_elements;

G_SYS  = zeros(1,length(system_event));
for fs = 1:length(system_event)

    limit_state_params = system_event(fs).limit_state_params;
    n_limit_states     = length(limit_state_params);

    g_sys              = zeros(1,n_limit_states);
    for i_LS = 1:n_limit_states
    
        surviving_mem = limit_state_params(i_LS).surviving_mem;
        failure_seq   = limit_state_params(i_LS).failure_seq;
        lsf_type      = limit_state_params(i_LS).lsf_type;
        inspected_mem = limit_state_params(i_LS).inspected_mem;
        N_insp        = limit_state_params(i_LS).N_insp;
        stress        = limit_state_params(i_LS).stress;
    
        switch lsf_type
            case 1
                % G1: when no prior member cracked, cracked member before other member
                % Ti^0 < Tl^0   : i = failure_seq (failed), l = surviving_mem
                % See Equation (7) of Ref. [1]
                        
                % random variables of the member i (other member)
                C1 = x(surviving_mem);                          % Paris parameter, C
                ai1= x(surviving_mem + 1*no_elements);  % initial crack length, ai
                S1 = x(end) * stress(surviving_mem);       % stress range
                
                % deterministic variables of the member i (other member)
                ac1= lsfparams.ac(surviving_mem);      % Critical crack length, ac  
                m1 = lsfparams.mean_m;  % Paris parameter, m
        
                % Evaluate integral, Equation (5) or first term of Equation (22a)   
                Tl0 = fatigue_integral(ai1, ac1, C1, m1, S1, Y_a);
                
                % random variables of the member j (target member)
                C2 = x(failure_seq);
                ai2= x(failure_seq + 1*no_elements);
                S2 = x(end) * stress(failure_seq);
                
                % deterministic variables of the member j (other member)
                ac2 = lsfparams.ac(failure_seq);
                m2  = lsfparams.mean_m;
        
                % Evaluate integral, Equation (5) or second term of Equation (22a)
                Ti0 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);
    
                % consider repaired members
                Ti0 = Ti0 + T_r(failure_seq);
                Tl0 = Tl0 + T_r(surviving_mem);            
                
                % limit state function
                g = Ti0 - Tl0; % Ti^0 < Tl^0 of Equation (7) of Ref. [1]
        
            case 2
                % G2: when no prior member cracked, event of cracked 
                %     member i before inspection cycle
                % Ti^0 < Ts : Equation (7) of Ref. [1]
        
                % random variables of the member i (target failed member)
                C2 = x(failure_seq );
                ai2= x(failure_seq + 1*no_elements);
                S2 = x(end) * stress(failure_seq);
                
                % deterministic variables of the member i (target failed member)
                ac2 = lsfparams.ac(failure_seq);
                m2  = lsfparams.mean_m;
        
                % Evaluate integral
                T2 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);
    
                % consider repaired members
                T2 = T2 + T_r(failure_seq);            
        
                % limit state function
                g = T2  - lsfparams.N;  % Ti^0 < Ts of Equation (7)
            
            case 3
                % G3: when prior members have cracked (1,...,i-1), event of 
                %     cracked member l before other member i
                %
                % Ti^(1,...,i-1) < Tl^(1,...,i-1) of Equation (10) of Ref. [1]
                % 
                
                len_sequence = length(failure_seq); % length of failure sequence
        
                % INTEGRATION PART of Equation (16) of Ref. [1]
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                Tk1 = zeros(1,len_sequence); % term of left hand side of g(x)
                Tk2 = zeros(1,len_sequence); % term of right hand side of g(x)
        
                % calculate integration parts of left and right terms
                for ik = 1:len_sequence
        
                    % random variables
                    C  = x(failure_seq(ik) );
                    ai = x(failure_seq(ik) + 1*no_elements );
                    S  = x(end) * stress(failure_seq(ik), ik);
        
                    % deterministic variables
                    m  = lsfparams.mean_m;            
                    ac = lsfparams.ac(failure_seq(ik) );
        
                    % evaluate integral
                    Tk1(ik) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                    % account for repaired members
                    Tk1(ik) = Tk1(ik) + T_r(failure_seq(ik) );
    
                end
        
                Tk2 = Tk1; % except last term
                
                C  = x(surviving_mem );
                ai = x(surviving_mem + 1*no_elements);
                S  = stress(surviving_mem, end) *x(end);
        
                ac = lsfparams.ac(surviving_mem );
                m  = lsfparams.mean_m;        
                %width = femodel.width(surviving_mem );
        
                % evalulate integral
                Tk2(end) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                % account for repaired members
                Tk2(end) = Tk2(end) + T_r(surviving_mem);
        
                % STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                Ti1 = zeros(1,len_sequence); 
                Ti1(1) = Tk1(1);
                
                for ik = 2:len_sequence-1 % last term is not the same
        
                    m   = lsfparams.mean_m;
                    S_d = lsfparams.stress(failure_seq(ik), ik)*x(end);
                    
                    S_redistribute = 0;
                    for ij = 1:ik-1
        
                        S_n            = stress(failure_seq(ik), ij)*x(end);
                        ratio          = S_n/S_d;
                        S_redistribute = S_redistribute + Ti1(ij)*ratio^m;
                    end
        
                    Ti1(ik) = Tk1(ik) - S_redistribute;
                end
                Ti2 = Ti1;
        
                m1   = lsfparams.mean_m;
                S_d1 = stress(failure_seq(end), end)*x(end);
                
                m2   = lsfparams.mean_m;
                S_d2 = stress(surviving_mem, end)*x(end);
        
                S_redistribute1 = 0;
                S_redistribute2 = 0;
                for n = 1: len_sequence-1
        
                    S_n1            = stress(failure_seq(end), n)*x(end);
                    ratio1          = S_n1/S_d1;
                    S_redistribute1 = S_redistribute1 + Ti1(n)* ratio1^m1;
        
                    S_n2            = stress(surviving_mem, n)*x(end);
                    ratio2          = S_n2/S_d2;
                    S_redistribute2 = S_redistribute2 + Ti2(n)* ratio2^m2;          
                end
                
                Ti1(end) = Tk1(end) - S_redistribute1;
                Ti2(end) = Tk2(end) - S_redistribute2;
        
                g = Ti1(end) -  Ti2(end);
        
            case 4
                % G4
                % T1^0+T2^1+T3^(1,2)+...+Ti^(1,...,i-1) < Ts : Equation (10) of Ref. [1]
        
                len_sequence = length(failure_seq);
        
                % INTEGRATION PART of Equation (16) of Ref. [1]
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                Tk = zeros(1,len_sequence);
                
                for k = 1:len_sequence
        
                    % random variables
                    C  = x(failure_seq(k) );
                    ai = x(failure_seq(k) + 1*no_elements );
                    S  = x(end)*stress(failure_seq(k),k);            
                    
                    % deterministic variables            
                    ac = lsfparams.ac(failure_seq(k) );
                    m  = lsfparams.mean_m;
                    
                    % evaluate integral
                    Tk(k) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                    % account for repaired members
                    Tk(k) = Tk(k) + T_r(failure_seq(k) );
                end
        
                % STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                Ti = zeros(1,len_sequence);
                Ti(1) = Tk(1);
        
                for i = 2:len_sequence
                    m   = lsfparams.mean_m;
                    S_d = stress(failure_seq(i), i) *x(end); % denominator
        
                    S_redistribute = 0;
                    for n = 1: i-1
                        S_n            = stress(failure_seq(i), n)*x(end);
                        ratio          = S_n/S_d;
                        S_redistribute = S_redistribute + Ti(n)* ratio^m;
                    end
        
                    Ti(i) = Tk(i) - S_redistribute;
                end
         
                g = sum(Ti) -  lsfparams.N; 
        
        
            case 5
                %
                % Inspection event outcome - Inequality case
                % TI -Tjd < 0:   Equation (15) of Ref. [2]
                %
                
                % random variables
                C  = x(inspected_mem );
                ai = x(inspected_mem + 1*no_elements );
                S  = x(end)*stress(inspected_mem, 1);
                ad = x(2*no_elements+1 );
    
                % deterministic variables            
                m  = lsfparams.mean_m;
                
                % evaluate integral
                Tjd = fatigue_integral(ai, ad, C, m, S, Y_a);
    
                % Inequality case, no detection
                g = N_insp - Tjd;
    
        end
        
    g_sys(i_LS) = g;
    
    
    end

G_SYS(fs) = max(g_sys);

end

G = min(G_SYS);

if grad_flag == 'yes'
   disp('No gradient exppression was defined.')
else
    grad_g = nan;
end
