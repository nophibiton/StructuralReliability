function [Upper_bound,Lower_bound] = use_uqlab(Red_node, Mixed_node, ...
                                  femodel, myInput,failure_paths)

    P_Ci = zeros(size(Red_node.probability) );
    system_event = struct;
    % retrieve failure sequences
    fs_ik = 0;
    for fs_i = 1:length(P_Ci)   

        % if ( Red_node.probability(fs_i) < 10^(-6) )
        %     % updated_P_Esys_low(fs_i)   = 0;
        %     continue;
        % else
            % load the component limit state parameters and stress results
            k = 1;
            while k <= size(Red_node.vector,2) && Red_node.vector(fs_i,k) ~= 0 
                if k==1
                    fname = num2str(Red_node.vector(fs_i,k));
                else
                    fname = strcat(fname,'_',num2str(Red_node.vector(fs_i,k)) );
                end
                k = k+1;
            end

            % load intermediate results of b-cube of the identified system
            % failure sequences
            fs_ind = find(strcmp({failure_paths.fs_name}, fname));
            femodel.stress      = failure_paths(fs_ind).FEA_results;
            limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;
    
            % combine inspection events parameters to the limit state params
            [limit_state_params.N_insp]        = deal([]);
            [limit_state_params.inspected_mem] = deal([]);
            [limit_state_params.stress]        = deal(femodel.stress);

            fs_ik=fs_ik+1;
            system_event(fs_ik).limit_state_params = limit_state_params;
        % end

    end

    % Update the lower bound given probability of inspection events
    if ~isempty(fieldnames(system_event))
        Lower_bound = run_uqlab_sys_all(myInput, femodel, system_event);
    else
        Lower_bound = 0;
    end
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    Li = Mixed_node.vector;
    P_Li = zeros(size(Mixed_node.probability) );
    mixed_event = struct;
    fs_ik = 0;
    for fs_i = 1:length(P_Li)

        % if ( Mixed_node.probability(fs_i) < 10^(-6) )
        %     % updated_P_Esys_upper(fs_i)   = 0;
        %     continue;
        % else
            k = 1;
            while k <= size(Li,2) && Li(fs_i,k) ~= 0 
                if k==1
                    fname = num2str(Li(fs_i,k) );
                else
                    fname = strcat(fname,'_',num2str(Li(fs_i,k)) );
                end
                k = k+1;
            end
            fs_ind = find(strcmp({failure_paths.fs_name}, fname));
            femodel.stress      = failure_paths(fs_ind).FEA_results;
            limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;

            [limit_state_params.N_insp]        = deal([]);
            [limit_state_params.inspected_mem] = deal([]);
            [limit_state_params.stress]        = deal(femodel.stress);
            
            fs_ik=fs_ik+1;
            mixed_event(fs_ik).limit_state_params = limit_state_params;
        % end
    end

    if ~isempty(fieldnames(mixed_event))
        Upper_bound = Lower_bound+run_uqlab_sys_all(myInput, femodel, mixed_event);
    else
        Upper_bound = Lower_bound+0;
    end

end