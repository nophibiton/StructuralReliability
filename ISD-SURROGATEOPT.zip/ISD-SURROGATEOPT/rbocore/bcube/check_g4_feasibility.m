function [isImpossible, gLower, w, A] = ...
    check_g4_feasibility(failure_seq, lsfparams)

% Analytical feasibility check for G4
%
% Supports any number of sequentially failing members.
%
% Assumption:
% Unrepaired fatigue lives Fk >= 0 for all
% admissible random-variable realizations.
%
% Outputs:
% isImpossible : true if G4 > 0 is guaranteed
% gLower       : certified lower bound, or NaN
% w            : effective fatigue/repair weights
% A            : stress-redistribution matrix

%% Unpack deterministic parameters

m      = lsfparams.mean_m;
T_r    = lsfparams.T_r;
stress = lsfparams.stress;
N      = lsfparams.N;

failure_seq = failure_seq(:);
L = numel(failure_seq);

%% Construct stress redistribution matrix

A = eye(L);

for k = 2:L

    mem = failure_seq(k);

    % Stress at the current failure stage
    S_d = stress(mem,k);

    if ~isfinite(S_d) || S_d <= 0
        error('Invalid stress for sequence stage %d.',k);
    end

    for j = 1:k-1

        % Stress at the preceding failure stage
        S_j = stress(mem,j);

        if ~isfinite(S_j) || S_j <= 0
            error('Invalid previous-stage stress.');
        end

        % Redistribution coefficient
        A(k,j) = (S_j/S_d)^m;

    end
end

%% Calculate effective weights

% A'*w = ones(L,1)
w = A' \ ones(L,1);

%% Deterministic repair contribution

R = T_r(failure_seq);
R = R(:);

repairOffset = w'*R - N;

%% Analytical feasibility condition

% Certified only when every fatigue coefficient
% is nonnegative.
nonnegativeWeights = all(isfinite(w)) && all(w >= 0);

isImpossible = nonnegativeWeights && ...
               isfinite(repairOffset) && ...
               repairOffset > 0;

if nonnegativeWeights
    % g >= repairOffset
    gLower = repairOffset;
else
    % No lower bound certified by this test
    gLower = NaN;
end

% %% Display results
% 
% fprintf('\n======================================\n');
% fprintf(' G4 ANALYTICAL FEASIBILITY CHECK\n');
% fprintf('======================================\n');
% 
% fprintf('Number of failed members: %d\n',L);
% 
% fprintf('Effective weights:\n');
% disp(w');
% 
% fprintf('Repair offset: %.8e\n',repairOffset);
% 
% if isImpossible
% 
%     fprintf('G4 event is mathematically impossible.\n');
%     fprintf('Certified lower bound: %.8e\n',gLower);
%     fprintf('Pf = 0, beta = Inf\n');
% 
% else
% 
%     fprintf('G4 impossibility NOT established.\n');
%     fprintf('Reliability evaluation may be required.\n');
% 
% end

end
