function [updated_P_Esys_upper_bound,updated_P_Esys_low_bound,updateextra] = ...
                update_reliability_bounds4(Red_node, ...
                                           Mixed_node,...
                                           failure_paths,...
                                           inspect_event, ...
                                           lsfparams,...
                                           probdata )


[P_IE_sys,Insp_alpha_vector,Insp_failure_probability] = ...
    det_insp_pf(probdata, inspect_event, lsfparams);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) UPDATE LOWER bound probability for each Ci in Eq. (29) of Ref.[2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ci                 = Red_node.vector;
updated_P_Esys_low = zeros( size(Ci,1),1 );

% retrieve failure sequences
for fs_i = 1: length(updated_P_Esys_low)    

    % load the component limit state parameters and stress results
    k = 1;
    while k <= size(Ci,2) && Ci(fs_i,k) ~= 0 
        if k==1, fname = num2str( Ci(fs_i,k) );
        else,fname = strcat( fname,'_',num2str(Ci(fs_i,k)) );
        end
        k = k+1;
    end

    % load intermediate results of b-cube of the identified system
    % failure sequences
    fs_ind = find(strcmp({failure_paths.fs_name}, fname));
    Component_failure_probability_results = ...
        failure_paths(fs_ind).Component_failure_probability_results;
    Component_alpha_vector = ...
        failure_paths(fs_ind).Component_alpha_vector;

    % combine results of Component and Inspection
    Alpha_vector = [Component_alpha_vector,Insp_alpha_vector];
    Failure_probability = ...
    [Component_failure_probability_results; Insp_failure_probability];

    Correlation_matrix  = Alpha_vector'*Alpha_vector;

    % calculate system failure probability using Hohenbichler (1982) 
    % first-order concepts in system rel. + Genz (1992) integration
    [ p_qsimvnv, ~] = qsimvnv(20000, Correlation_matrix, ...
        -inf*ones(1,length(Failure_probability)), ...
        norminv(Failure_probability)' );

    updated_P_Esys_low(fs_i) = p_qsimvnv;

end

% Update the lower bound given probability of inspection events
updated_P_Esys_low_bound = ( sum(updated_P_Esys_low) )/P_IE_sys;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) UPDATE UPPER bound probability for each Li in Eq. (29) of Ref.[2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Li                   = Mixed_node.vector;
updated_P_Esys_upper = zeros( size(Li,1),1 );

for fs_i = 1: length(updated_P_Esys_upper) % i-th failure sequence

    k = 1;
    while k <= size(Li,2) && Li(fs_i,k) ~= 0 
        if k==1,fname = num2str( Li(fs_i,k) );
        else, fname = strcat( fname,'_',num2str(Li(fs_i,k)) );
        end
        k = k+1;
    end
    fs_ind = find(strcmp({failure_paths.fs_name}, fname));
    Component_failure_probability_results = ...
        failure_paths(fs_ind).Component_failure_probability_results;
    Component_alpha_vector = ...
        failure_paths(fs_ind).Component_alpha_vector;

    % combine results of Component and Inspection
    Alpha_vector = [Component_alpha_vector,Insp_alpha_vector];
    Failure_probability = ...
    [Component_failure_probability_results; Insp_failure_probability];

    Correlation_matrix  = Alpha_vector'*Alpha_vector;

    % calculate system failure probability using Hohenbichler (1982) 
    % first-order concepts in system rel. + Genz (1992) integration
    [ p_qsimvnv, ~] = qsimvnv(20000, Correlation_matrix, ...
        -inf*ones(1,length(Failure_probability)), ...
        norminv(Failure_probability)' );

    updated_P_Esys_upper(fs_i) = p_qsimvnv;
end
    
updated_P_Esys_upper_bound = ...
    ( sum(updated_P_Esys_upper) + sum(updated_P_Esys_low) )/P_IE_sys;

updateextra         = struct;
updateextra.IE_prob = Insp_failure_probability;
updateextra.P_Ci    = updated_P_Esys_low;