function [g, dgdx] = gfunfatigue_lsf2(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)
%
% G2: when no prior member cracked, event of cracked 
%     member i before inspection cycle
% Ti^0 < Ts : Equation (7) of Ref. [1]
%

% unpack
if isfield(gfundata(lsf),'cg')
    cg           = gfundata(lsf).cg;
    lsfparams    = cg{1};
    failure_seq  = cg{2};
    ac           = lsfparams.ac;
    mean_m       = lsfparams.mean_m;
    Y_a          = lsfparams.Y_a;
    N            = lsfparams.N;
    T_r          = lsfparams.T_r;
    stress       = lsfparams.stress;
    no_elements  = lsfparams.no_elements;
end

% random variables of the member i (target failed member)
C2 = x(failure_seq );
ai2= x(failure_seq + 1*no_elements);
I2 = x(end);

S2 = I2 * stress(failure_seq);

% deterministic variables of the member i (target failed member)
ac2 = ac(failure_seq);
m2  = mean_m;

% Evaluate integral
T2 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);

% consider repaired members
T2 = T2 + T_r(failure_seq);

% limit state function
g = T2 - N;  % Ti^0 < Ts of Equation (7)

dgdx = nan; % not defined
