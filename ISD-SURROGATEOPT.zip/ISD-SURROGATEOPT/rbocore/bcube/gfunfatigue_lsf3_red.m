function [g, dgdx] = gfunfatigue_lsf3_red(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

% G3: when prior members have cracked (1,...,i-1), event of 
%     cracked member l before other member i
%
% Ti^(1,...,i-1) < Tl^(1,...,i-1) of Equation (10) of Ref. [1]
% 

% unpack
if isfield(gfundata(lsf),'cg')
    cg            = gfundata(lsf).cg;
    lsfparams     = cg{1};
    failure_seq   = cg{2};
    surviving_mem = cg{3};
    ac_all        = lsfparams.ac;
    mean_m        = lsfparams.mean_m;
    Y_a           = lsfparams.Y_a;
    T_r           = lsfparams.T_r;
    stress        = lsfparams.stress;
end

len_sequence = length(failure_seq); % length of failure sequence

% INTEGRATION PART of Equation (16) of Ref. [1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Tk1 = zeros(1,len_sequence); % term of left hand side of g(x)
Tk2 = zeros(1,len_sequence); % term of right hand side of g(x)

% calculate integration parts of left and right terms
for ik = 1:len_sequence

    % random variables
    C  = x(2*ik-1 );
    ai = x(2*ik   );
    S  = x(end) * stress( failure_seq(ik), ik );

    % deterministic variables
    m  = mean_m;            
    ac = ac_all( failure_seq(ik) );

    % evaluate integral
    Tk1(ik) = fatigue_integral(ai, ac, C, m, S, Y_a);

    % account for repaired members
    Tk1(ik) = Tk1(ik) + T_r( failure_seq(ik) );
end

Tk2 = Tk1; % except last term

C  = x(end-2 );
ai = x(end-1 );
S  = x(end   )* stress(surviving_mem, end);

ac = ac_all( surviving_mem );
m  = mean_m;        
%width = femodel.width(femodel.surviving_mem );

% evalulate integral
Tk2(end) = fatigue_integral(ai, ac, C, m, S, Y_a);

% account for repaired members
Tk2(end) = Tk2(end) + T_r( surviving_mem );

% STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ti1 = zeros(1,len_sequence); 
Ti1(1) = Tk1(1);

for ik = 2:len_sequence-1 % last term is not the same

    m   = mean_m;
    S_d = stress(failure_seq(ik), ik)*x(end);
    
    S_redistribute = 0;
    for ij = 1:ik-1

        S_n            = stress(failure_seq(ik), ij)*x(end);
        ratio          = S_n/S_d;
        S_redistribute = S_redistribute + Ti1(ij)*ratio^m;
    end

    Ti1(ik) = Tk1(ik) - S_redistribute;
end
Ti2 = Ti1;

m1   = mean_m;
S_d1 = stress(failure_seq(end), end)*x(end);

m2   = mean_m;
S_d2 = stress(surviving_mem, end)*x(end);

S_redistribute1 = 0;
S_redistribute2 = 0;
for n = 1: len_sequence-1

    S_n1            = stress(failure_seq(end), n)*x(end);
    ratio1          = S_n1/S_d1;
    S_redistribute1 = S_redistribute1 + Ti1(n)* ratio1^m1;

    S_n2            = stress(surviving_mem, n)*x(end);
    ratio2          = S_n2/S_d2;
    S_redistribute2 = S_redistribute2 + Ti2(n)* ratio2^m2;          
end

Ti1(end) = Tk1(end) - S_redistribute1;
Ti2(end) = Tk2(end) - S_redistribute2;

g = Ti1(end) -  Ti2(end);

dgdx = nan;