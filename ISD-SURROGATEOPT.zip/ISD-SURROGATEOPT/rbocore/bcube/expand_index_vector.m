function [Mixed_node]=expand_index_vector(A,Mixed_node) 
%
% This function updates the index vector by branching out from the node
% with the max probability. The Node_probability is then updated with first
% assuming the new branches to be negative one then changes it to 
% corresponding nodes sequences.
%

% unpack
Node_probability = Mixed_node.probability;
index_vector     = Mixed_node.vector;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find maximum value & its index
[~, max_I] = max(Node_probability); 

max_size_index_vector = length(find(index_vector(max_I,:)));

if (max_size_index_vector == size(index_vector,2))
    index_vector = [index_vector zeros((size(index_vector,1)),1)];
end

index_vector_temp = zeros(1,size(index_vector,2));
for iii=1:size(index_vector,1)
    if (iii==max_I)
        for jjj=1:A
            if (length(find(index_vector(max_I,:)==jjj))==0)
                index_vector_temp = [index_vector_temp; index_vector(iii,:)];
                index_vector_temp(size(index_vector_temp,1),size(cut_index_vector(index_vector(max_I,:)),2)+1) = jjj;
            end
        end
    else
        index_vector_temp = [index_vector_temp; index_vector(iii,:)];
    end
end
index_vector = index_vector_temp(2:size(index_vector_temp,1),:);

diff_vectors = size(index_vector,1) - size(Node_probability,1);

% Assigns the node probability of the ones that did not branch out and was
% previously known
Node_probability = [Node_probability(1:(max_I-1),1); zeros(diff_vectors+1,1); Node_probability((max_I+1):size(Node_probability,1),1)];


Mixed_node.probability = Node_probability;
Mixed_node.vector      = index_vector;