function [inspect_event,T_r] = define_inspect_event(no_elements,v0,inspections)

% define the inspection event that will be used for updating of
% reliability, the inspect_event will save the parameters needed when
% evaluating the LSF of inspections
T_r           = zeros(1,no_elements);
inspect_event = struct;
insp_event_i  = 1;
for insp_i = 1:length(inspections)
    current_inspection  = inspections( insp_i );
    inspected_members_j = current_inspection.mem_inspected;
    inspection_results  = current_inspection.inspection_results;      

        for mem_j = 1:length(inspected_members_j)
            % define number of cycles at time of inspection
            inspect_event(insp_event_i).N_insp = ...
                                  current_inspection.time_i*v0;
            % define the member to be inspected
            inspect_event(insp_event_i).inspected_mem = ...
                                            inspected_members_j(mem_j);
            % define LSF type based on inspetion outcome
            if inspection_results(mem_j) == 0
                inspect_event(insp_event_i).lsf_type = 5;
            else
                inspect_event(insp_event_i).lsf_type = 6;
                T_r(inspected_members_j(mem_j)) = ...
                                  current_inspection.time_i*v0;
            end
            
            insp_event_i = insp_event_i+1;
        end        
end

inspect_event(find([inspect_event.lsf_type] == 6)) = [];

% remove the smallest value of time inspection time with no detection
% for Pr(t_insp1 < Tjd) ∧ Pr(t_insp2 < Tjd) is equivalent to 
% Pr( max(t_insp1,t_insp2) < Tjd )
col1 =  [inspect_event.inspected_mem]';
col2 = -[inspect_event.N_insp]';
temp_mat = [col1 col2];
if ~isempty(temp_mat) || (~isempty(col1) && ~isempty(col2))
    [~, order] = sortrows(temp_mat, [1 2]);
    S_sorted = inspect_event(order);
    [~, ia] = unique([S_sorted.inspected_mem]', 'stable');
    inspect_event = S_sorted(ia);
end
