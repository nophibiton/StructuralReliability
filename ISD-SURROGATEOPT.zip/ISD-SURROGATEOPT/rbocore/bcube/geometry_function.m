function Y_a = geometry_function(a,W)
%
% Calculates the geometry function using (Harter, 2006; Tada et al. 1985)
%
%

theta = pi*a./(2*W);

Y_a = ((0.752 + 2.02 .*(a./W) + 0.37 .*((1-sin(theta) ).^3) )./(cos(theta) )) .* sqrt((1./theta).*tan(theta) );

end