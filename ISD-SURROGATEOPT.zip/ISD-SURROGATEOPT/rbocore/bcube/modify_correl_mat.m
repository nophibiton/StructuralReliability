function probdata = modify_correl_mat(probdata,analysisopt)

marg        = probdata.marg;
R           = probdata.correlation;
transf_type = probdata.transf_type;
flag_sens   = probdata.flag_sens;

echo_flag = analysisopt.echo_flag;

% Modify correlation matrix and perform Cholesky decomposition
if ~isfield(probdata,'Lo')
    
   if transf_type == 3
    
      % Compute corrected correlation coefficients
      switch probdata.Ro_method
         case 1
            if echo_flag
               disp([' '])
               disp('Computation of modified correlation matrix R0')
               disp('Takes some time if sensitivities are to be computed with gamma (3), beta (7) or chi-square (8) distributions.')
               disp('Please wait... (Ctrl+C breaks)')
            end
            [ Ro, dRo_drho, dRo_dthetafi, dRo_dthetafj ] = mod_corr_solve( marg, R , flag_sens);
      end     
      probdata.Ro = Ro;
   
      % Cholesky decomposition
      [Lo,ierr] = my_chol(Ro); if  ierr>0, return, end
      probdata.Lo = Lo;
   
      iLo = inv(Lo);
      probdata.iLo = iLo;

   end
   
else
    
   Ro = probdata.Ro;
   if isfield(probdata,'dRo_drho')
      dRo_drho = probdata.dRo_drho;
      dRo_dthetafi = probdata.dRo_dthetafi;
      dRo_dthetafj = probdata.dRo_dthetafj;
   elseif flag_sens
      % Compute corrected correlation coefficients
      switch probdata.Ro_method
         case 1
            if echo_flag
               disp([' '])
               disp('Computation of modified correlation matrix R0')
               disp('Takes some time if sensitivities are to be computed with gamma (3), beta (7) or chi-square (8) distributions.')
               disp('Please wait... (Ctrl+C breaks)')
            end
            [ Ro, dRo_drho, dRo_dthetafi, dRo_dthetafj ] = mod_corr_solve( marg, R , flag_sens);
      end     
   end

   Lo = probdata.Lo;
   iLo = probdata.iLo;

end