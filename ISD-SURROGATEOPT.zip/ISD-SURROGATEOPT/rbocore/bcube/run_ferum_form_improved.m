function [Pf, alpha, formresults] = run_ferum_form_improved( ...
                                        lsf_type, ...
                                        failure_seq,...
                                        surviving_mem,...
                                        probdata_orig, ...
                                        lsfparams)

no_elements = lsfparams.no_elements;
nrv         = lsfparams.nrv;
stress      = lsfparams.stress;
T_r         = lsfparams.T_r;  

gfundata(1).type      = 'expression';
gfundata(1).flag_sens = 0;

switch lsf_type
    case 1
        % j-index included in the limit state function
        j_index = [failure_seq, surviving_mem,... 
                   failure_seq+no_elements, surviving_mem+no_elements,... 
                   nrv];
        % cj-index NOT included in the limit state function
        cj_index          = 1:nrv; 
        cj_index(j_index) = [];

        % define limit state in reduced space
        gfundata(1).evaluator = 'fatigue_lsf1_red';
        gfundata(1).type      = 'expression';
        gfundata(1).cg        = {lsfparams,failure_seq,surviving_mem};

        % define limit state in original space
        gfundata_orig = gfundata;
        gfundata_orig(1).evaluator = 'fatigue_lsf1';

    case 2      
        % j-index included in the limit state function
        j_index  = [failure_seq, no_elements+failure_seq, nrv];
        % cj-index NOT included in the limit state function
        cj_index          = 1:nrv;
        cj_index(j_index) = [];

        % define limit state in reduced space
        gfundata(1).evaluator = 'fatigue_lsf2_red';
        gfundata(1).type      = 'expression';
        gfundata(1).cg        = {lsfparams,failure_seq};

        % define limit state in original space
        gfundata_orig = gfundata;
        gfundata_orig(1).evaluator = 'fatigue_lsf2';

    case 3
        % j-index included in the limit state function
        j_index = [];
        for iik = 1:length(failure_seq)
            j_index = [j_index, ...
                       failure_seq(iik),failure_seq(iik)+1*no_elements];
        end
        j_index = [j_index,...
                   surviving_mem, surviving_mem+1*no_elements,... 
                   nrv];
        % cj-index NOT included in the limit state function
        cj_index          = 1:nrv;
        cj_index(j_index) = [];

        % define limit state in reduced space
        gfundata(1).evaluator = 'fatigue_lsf3_red';
        gfundata(1).type      = 'expression';
        gfundata(1).cg        = {lsfparams,failure_seq,surviving_mem};

        % define limit state in original space
        gfundata_orig = gfundata;
        gfundata_orig(1).evaluator = 'fatigue_lsf3';

    case 4
        % j-index included in the limit state function
        j_index = [];
        for iik = 1:length(failure_seq)
            j_index = [j_index,... 
                       failure_seq(iik), failure_seq(iik)+1*no_elements];
        end
        j_index  = [j_index, nrv];
        % cj-index NOT included in the limit state function
        cj_index          = 1:nrv;
        cj_index(j_index) = [];

        % define limit state in reduced space
        gfundata(1).evaluator = 'fatigue_lsf4_red';
        gfundata(1).type      = 'expression';
        gfundata(1).cg        = {lsfparams,failure_seq};

        % define limit state in original space
        gfundata_orig = gfundata;
        gfundata_orig(1).evaluator = 'fatigue_lsf4';

    case 5 % limit state for INSPECTION EVENT
        % j-index included in the limit state function
        j_index  = [lsfparams.inspected_mem,...
                    lsfparams.inspected_mem+no_elements,...
                    nrv-1, nrv];
        % cj-index NOT included in the limit state function
        cj_index          = 1:nrv;
        cj_index(j_index) = [];

        % define limit state in reduced space
        gfundata(1).evaluator = 'fatigue_lsf5_red';
        gfundata(1).type      = 'expression';
        gfundata(1).cg        = {lsfparams};

        % define limit state in original space
        gfundata_orig = gfundata;
        gfundata_orig(1).evaluator = 'fatigue_lsf5';

end


% slightly change starting point
if any(lsf_type == [1,3])
    small_dS = abs(stress(failure_seq(end),end) - stress(surviving_mem)) < 0.01;
    if  small_dS
        % change the starting point of the C,a0,S of the failing member
        idx = [failure_seq,failure_seq+1*no_elements];
        probdata_orig.marg([idx,end],4) = 0.95*probdata_orig.marg([idx,end],4);
    end
end    
if any(lsf_type == [2,4])
    small_S = stress(failure_seq(end),end) < 10;
    if  small_S 
        idx    = failure_seq;
        probdata_orig.marg([idx,end],4) = 0.95*probdata_orig.marg([idx,end],4);
        idx_a0 = failure_seq(end) + 1*no_elements;
        probdata_orig.marg(idx_a0,4)    = 0.95*lsfparams.ac(failure_seq(end));
    end

    large_S = stress(failure_seq(end),end) > 200;
    if large_S
        idx    = failure_seq;
        probdata_orig.marg(idx,4) = 0.01*probdata_orig.marg(idx,4);
        probdata_orig.marg(end,4) = 0.50*probdata_orig.marg(end,4);
    end
end

probdata.marg        = probdata_orig.marg(j_index,:);
probdata.correlation = probdata_orig.correlation(j_index,j_index);
probdata.transf_type = probdata_orig.transf_type;
probdata.Ro_method   = probdata_orig.Ro_method;
probdata.flag_sens   = probdata_orig.flag_sens;

analysisopt.i_max      = 200;
analysisopt.e1         = 1e-4;
analysisopt.e2         = 1e-4;
analysisopt.step_code  = 0.0;       % Armijo
analysisopt.grad_flag  = 'ffd';   % Finite difference
if any(lsf_type==[2,5])
    analysisopt.grad_flag  = 'ddm';   % Finite difference
end

analysisopt.Recorded_u = true;
analysisopt.Recorded_x = true;
analysisopt.Recorded_sens = true;
analysisopt.multi_proc = 0;
analysisopt.echo_flag  = false;       % Silent mode
analysisopt.analysistype = 10;    % Standard FORM

femodel     = [];
randomfield = [];

% check if limit state function has failure domain
isImpossible = false;
if lsf_type == 4
    % Analytical feasibility check
    [isImpossible, gLower, w, A] = ...
        check_g4_feasibility(failure_seq,lsfparams);
end

if isImpossible

    % Failure event cannot occur
    Pf    = 0;
    alpha = zeros(nrv,1);

else

    ferum;
    Pf    = formresults.pf1;
    % lsf_type
    % abs(lsfparams.stress(failure_seq) - lsfparams.stress(surviving_mem)) 
    
    % % Examine FORM convergence
    % e1 = formresults.e1(:);
    % e2 = formresults.e2(:);
    % g  = formresults.gfcn(:);
    % 
    % n = min([numel(e1), numel(e2), numel(g), 10]);
    % 
    % T = table((1:n)', e1(1:n), e2(1:n), g(1:n), ...
    %     'VariableNames', {'Iteration','e1','e2','G'});
    % 
    % disp(T);
    % 
    % fprintf('\nCheck e1 quantization:\n');
    % disp(14*e1(1:n));
    % 
    % fprintf('\nCheck e2 contraction:\n');
    % disp(e2(2:n)./e2(1:n-1));
    % 
    % fprintf('\nRecorded step sizes:\n');
    % disp(formresults.stpsz);
    
    % % FORM results
    % analysisopt.formresults = formresults;
    % 
    % % FORM sensitivity vector
    % alpha = formresults.alpha(:);
    % n = numel(alpha);
    % 
    % % Check alpha
    % assert(all(isfinite(alpha)) && norm(alpha) > 1e-12, ...
    %     'Invalid FORM sensitivity vector.');
    % 
    % alpha = alpha / norm(alpha);
    % 
    % % Construct an orthonormal basis
    % Q = null(alpha');
    % 
    % % Last column points toward failure
    % R1 = [Q, alpha];
    % 
    % % Verify orthogonality
    % assert(norm(R1'*R1 - eye(n), 'fro') < 1e-10, ...
    %     'Orthonormal matrix construction failed.');
    % 
    % % Supply the rotation matrix to FERUM
    % analysisopt.formresults.R1 = R1;
    % 
    % % Run SORM
    % analysisopt.analysistype = 12;      % SORM point-fitting
    % ferum;
    % Pf = sormcfhresults.pf2_breitung_m;
    
    % Step 1: Transform ustar from reduced to original space
    Rzz = mod_corr_solve(probdata_orig.marg, probdata_orig.correlation, 0);
    L   = chol(Rzz, 'lower');
    
    J   = j_index(:);
    C   = cj_index(:);
    n   = size(Rzz,1);
    
    assert(isequal(sort([J; C]), (1:n).'), ...
        'j_index and cj_index must partition the full input indices.');
    
    % Local FORM design point: always a column
    uj  = formresults.dsptu(:);
    assert(numel(uj) == numel(J), ...
        'Local Ustar must match j_index.');
    
    % Local-to-global mapping
    Rjj   = Rzz(J,J);
    Ljj   = chol(Rjj, 'lower');
    
    zj    = Ljj * uj;
    
    zd    = zeros(n,1);
    zd(J) = zj;
    zd(C) = Rzz(C,J) * (Rjj \ zj);
    
    ud    = L \ zd; % Global FORM design point
    
    % Step 2: Determine alpha in global space
    betaFORM = formresults.beta;
    betaGeom = norm(ud);
    
    assert(isfinite(betaFORM) && all(isfinite(ud)), ...
        'Invalid FORM results.');
    
    [probdata_orig,gfundata_orig,~] = update_data(1,probdata_orig, ...
                                          analysisopt,gfundata_orig,femodel);
    probdata_orig.marg  = distribution_parameter(probdata_orig.marg);
    
    probdata_orig = modify_correl_mat(probdata_orig,analysisopt);
    
    g = @(X) gfun(1, X, 'no ', probdata_orig, analysisopt, ...
                   gfundata_orig, femodel, randomfield);
    
    % Transform U-space origin to X-space using FERUM
    xOrigin = u_to_x(zeros(n,1), probdata_orig);
    
    % Evaluate limit-state at origin
    gOrigin = g(xOrigin);
    
    assert(isscalar(gOrigin) && isfinite(gOrigin), ...
        'FERUM must return one finite scalar limit-state value.');
    
    if betaGeom > 1e-8 && gOrigin > 0
        % Zhou convention: unit direction toward failure
        alpha = ud / betaGeom;
    else
        u0 = ud(:);
        h  = 1e-4;
        % Scalar limit-state function in standard normal space
        G = @(U) g(u_to_x(U(:), probdata_orig));
        % Central finite-difference gradient
        gradU = zeros(n,1);
    
        for i = 1:n
    
            up = u0;
            um = u0;
    
            up(i) = up(i) + h;
            um(i) = um(i) - h;
    
            gp = G(up);
            gm = G(um);
    
            assert(isscalar(gp) && isscalar(gm) && ...
                   isfinite(gp) && isfinite(gm), ...
                   'Expected finite scalar limit-state evaluations.');
    
            gradU(i) = (gp - gm)/(2*h);
    
        end
    
        assert(all(isfinite(gradU)) && norm(gradU) > 0, ...
            'Gradient must be finite and nonzero.');
        % Zhou convention: direction toward failure
        alpha = -gradU / norm(gradU);
    end
    
    alpha = alpha(:);

end