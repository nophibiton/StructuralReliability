function [P_IE_sys,Insp_alpha_vector,Insp_failure_probability] = ...
            det_insp_pf(probdata, inspect_event, lsfparams)


Failure_probability  = [];
Alpha_vector         = [];

% run FORM for every component event
for i = 1: numel(inspect_event) 

    lsf_type      = 5;
    failure_seq   = [];
    surviving_mem = [];

    lsfparams.inspected_mem = inspect_event(i).inspected_mem;
    lsfparams.N_insp        = inspect_event(i).N_insp;

    % perform component reliability analysis
    [Pf, alpha] = run_ferum_form_improved( ...
                    lsf_type, ...
                    failure_seq,...
                    surviving_mem,...
                    probdata, ...
                    lsfparams );       

    Failure_probability   = [Failure_probability; Pf];
    Alpha_vector          = [Alpha_vector alpha];

end

Correlation_matrix  = Alpha_vector'*Alpha_vector;

% Integration bounds
lb = -inf(1, numel(Failure_probability));
ub = norminv(Failure_probability(:))';

% Multivariate normal probability using Genz integration
[p_qsimvnv, ~] = qsimvnv( ...
                    20000, ...
                    Correlation_matrix, ...
                    lb, ...
                    ub);

P_IE_sys = p_qsimvnv;

Insp_failure_probability = Failure_probability;
Insp_alpha_vector        = Alpha_vector;