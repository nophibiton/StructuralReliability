function [updated_P_Esys_upp, updated_P_Esys_low, updateExtra] = ...
            update_reliability_bounds2(Red_node, Mixed_node, femodel, ...
                                       inspect_event, probdata, ...
                                       myInput,failure_paths)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define limit state parameters of in the inspection event IE
[inspect_event.failure_seq]   = deal([]);
[inspect_event.surviving_mem] = deal([]);
femodel.limit_state_params    = inspect_event;
femodel.Alpha_vector          = [];
femodel.Failure_probability   = [];
femodel.sus_batchsize         = 1*5*1e3;

% calculate PROBABILITY OF INSPECTION event P(IE)
% P_IE_sys  = run_uqlab_sys_i(myInput, femodel)
% P_IE_sys  = run_genz_sys(probdata, femodel)
P_IE    = run_uqlab_sys( myInput, femodel );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) UPDATE LOWER bound probability in Eq. (29) of Ref.[2] %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ci                 = Red_node.vector;
system_event       = struct;

for fs_i = 1:size(Ci,1)    

    % get index name of failure sequence Ci
    k = 1;
    while k <= size(Ci,2) && Ci(fs_i,k) ~= 0 
        if k==1, fname = num2str( Ci(fs_i,k) );
        else, fname = strcat( fname,'_', num2str(Ci(fs_i,k)) ); end
        k = k+1;
    end

    % load intermediate results of b-cube of the failure seq Ci's
    fs_ind = find(strcmp({failure_paths.fs_name}, fname));
    femodel.stress      = failure_paths(fs_ind).FEA_results;
    limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;

    % combine inspection events parameters to the limit state params
    [limit_state_params.N_insp]        = deal([]);
    [limit_state_params.inspected_mem] = deal([]);
    limit_state_params  = [limit_state_params, inspect_event];
    [limit_state_params.stress]        = deal(femodel.stress);

    % define a system event with corresponding limit state params
    system_event(fs_i).limit_state_params = limit_state_params;
end

% update the lower bound given probability of inspection events
P_Ci_l_IE = 0;
if ~isempty( fieldnames(system_event) )
    P_Ci_l_IE = run_uqlab_sys_all(myInput, femodel, system_event);
end

updated_P_Esys_low = P_Ci_l_IE / P_IE; % Eq.(29) of Ref.2
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) UPDATE UPPER bound probability Eq. (29) of Ref.[2] %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Ei          = Mixed_node.vector; % Mixed nodes. Note: Ei ~= Li
mixed_event = struct;

for fs_i = 1:size(Ei,1)

    % get index name of failure sequence Ei (mixed nodes)
    k = 1;
    while k <= size(Ei,2) && Ei(fs_i,k) ~= 0 
        if k==1, fname = num2str( Ei(fs_i,k) );
        else, fname = strcat( fname,'_',num2str(Ei(fs_i,k)) );end
        k = k+1;
    end

    % load intermediate results of b-cube of the failure seq Ei's
    fs_ind = find(strcmp({failure_paths.fs_name}, fname));
    femodel.stress      = failure_paths(fs_ind).FEA_results;
    limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;

    % combine inspection events parameters to the limit state params
    [limit_state_params.N_insp]        = deal([]);
    [limit_state_params.inspected_mem] = deal([]);
    limit_state_params  = [limit_state_params, inspect_event];
    [limit_state_params.stress]        = deal(femodel.stress);

    mixed_event(fs_i).limit_state_params = limit_state_params;

end

% update the upper bound given probability of inspection events
P_Ei_l_IE = 0; % P_Li_i_IE + P_Ci_i_IE + P_Ei_i_IE = 1.0
if ~isempty(fieldnames(mixed_event))
    P_Ei_l_IE = run_uqlab_sys_all(myInput, femodel, mixed_event);
end

updated_P_Esys_upp = ( P_Ei_l_IE + P_Ci_l_IE ) / P_IE;

%%%%
updateExtra      = [];
updateExtra.P_IE = P_IE;