function [updated_P_Esys_upp, updated_P_Esys_low, updateExtra] = ...
                update_reliability_bounds4(Red_node, ...
                                           Mixed_node,...
                                           failure_paths,...
                                           inspect_event, ...
                                           lsfparams,...
                                           probdata )

[P_IE_sys,Insp_alpha_vector,Insp_failure_probability] = ...
    det_insp_pf(probdata, inspect_event, lsfparams);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) UPDATE LOWER bound probability in Eq. (29) of Ref.[2] %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[inspect_event.failure_seq]   = deal([]);
[inspect_event.surviving_mem] = deal([]);

Ci                 = Red_node.vector;
system_event       = struct;

for fs_i = 1:size(Ci,1)    

    % get index name of failure sequence Ci
    k = 1;
    while k <= size(Ci,2) && Ci(fs_i,k) ~= 0 
        if k==1, fname = num2str( Ci(fs_i,k) );
        else, fname = strcat( fname,'_', num2str(Ci(fs_i,k)) ); end
        k = k+1;
    end

    % load intermediate results of b-cube of the failure seq Ci's
    fs_ind = find(strcmp({failure_paths.fs_name}, fname));
    femodel.stress      = failure_paths(fs_ind).FEA_results;
    limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;

    % combine inspection events parameters to the limit state params
    [limit_state_params.N_insp]        = deal([]);
    [limit_state_params.inspected_mem] = deal([]);
    limit_state_params  = [limit_state_params, inspect_event];
    [limit_state_params.stress]        = deal(femodel.stress);

    % define a system event with corresponding limit state params
    system_event(fs_i).limit_state_params = limit_state_params;
end

% update the lower bound given probability of inspection events
P_Ci_l_IE = 0;
if ~isempty( fieldnames(system_event) )
    P_Ci_l_IE = run_ferum_sys_all(probdata, lsfparams, system_event);
end

updated_P_Esys_low = P_Ci_l_IE / P_IE_sys; % Eq.(29) of Ref.2
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) UPDATE UPPER bound probability Eq. (29) of Ref.[2] %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Ei          = Mixed_node.vector; % Mixed nodes. Note: Ei ~= Li
% mixed_event = struct;
% 
% for fs_i = 1:size(Ei,1)
% 
%     % get index name of failure sequence Ei (mixed nodes)
%     k = 1;
%     while k <= size(Ei,2) && Ei(fs_i,k) ~= 0 
%         if k==1, fname = num2str( Ei(fs_i,k) );
%         else, fname = strcat( fname,'_',num2str(Ei(fs_i,k)) );end
%         k = k+1;
%     end
% 
%     % load intermediate results of b-cube of the failure seq Ei's
%     fs_ind = find(strcmp({failure_paths.fs_name}, fname));
%     femodel.stress      = failure_paths(fs_ind).FEA_results;
%     limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;
% 
%     % combine inspection events parameters to the limit state params
%     [limit_state_params.N_insp]        = deal([]);
%     [limit_state_params.inspected_mem] = deal([]);
%     limit_state_params  = [limit_state_params, inspect_event];
%     [limit_state_params.stress]        = deal(femodel.stress);
% 
%     mixed_event(fs_i).limit_state_params = limit_state_params;
% 
% end
% 
% % update the upper bound given probability of inspection events
% P_Ei_l_IE = 0; % P_Li_i_IE + P_Ci_i_IE + P_Ei_i_IE = 1.0
% if ~isempty(fieldnames(mixed_event))
%     P_Ei_l_IE = run_ferum_sys_all(probdata, lsfparams, mixed_event);
% end
% 
% updated_P_Esys_upp = ( P_Ei_l_IE + P_Ci_l_IE ) / P_IE_sys;
updated_P_Esys_upp = updated_P_Esys_low;
%%%%
updateExtra      = [];
updateExtra.P_IE = P_IE_sys;