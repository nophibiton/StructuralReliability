function [g,dgdx] = gfunfatigue_lsf5(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

% G5
% Inspection event outcome - Inequality case
% TI -Tjd < 0:   Equation (15) of Ref. [2]
%

% unpack
if isfield(gfundata(lsf),'cg')
    cg            = gfundata(lsf).cg;
    lsfparams     = cg{1};
    mean_m        = lsfparams.mean_m;
    Y_a           = lsfparams.Y_a;
    stress        = lsfparams.stress;
    inspected_mem = lsfparams.inspected_mem;
    N_insp        = lsfparams.N_insp;
    no_elements   = lsfparams.no_elements;
end

% random variables
C  = x(inspected_mem );
ai = x(inspected_mem + 1*no_elements );
S  = x(end)*stress(inspected_mem, 1);
ad = x(2*no_elements+1 );

% deterministic variables            
m  = mean_m;

% calculate number of load cycles starting from crack ai to
% detection crack ad.
Njd = fatigue_integral(ai, ad, C, m, S, Y_a);

% Inequality case, no detection
g = N_insp - Njd;

dgdx=nan;