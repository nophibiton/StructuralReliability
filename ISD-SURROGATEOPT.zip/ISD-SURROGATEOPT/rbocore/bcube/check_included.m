function find_result = check_included(A,B)
%
% This function checks whether the current member B is included 
% in the sequence A. It returns non-zero value when it is included. 
%

count=0;
for i=1:length(A)
    if (A(i)==B)
        count = count+1;
    end
end
find_result = count;