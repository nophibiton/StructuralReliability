function [updated_P_Esys_upper_bound,updated_P_Esys_low_bound] = ...
    update_reliability_bounds(Red_node,Mixed_node, femodel, inspect_event,probdata,myInput,failure_paths)

% archive_folder = strcat(pwd,'\archive_component\');

% calculate probability of inspection event P(IE)
[inspect_event.failure_seq]   = deal([]);
[inspect_event.surviving_mem] = deal([]);

femodel.limit_state_params = inspect_event;

femodel.Alpha_vector        = [];
femodel.Failure_probability = [];

femodel.sus_batchsize = 5*1e3;

% P_IE_sys  = run_uqlab_sys_i(myInput, femodel)

P_IE_sys  = run_uqlab_sys(myInput, femodel);

% P_IE_sys  = run_genz_sys(probdata, femodel)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) UPDATE LOWER bound probability for each Ci in Equation (29) of Ref.[2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    updated_P_Esys_low = zeros(size(Red_node.probability) );

    % retrieve failure sequences
    for fs_i = 1: length(updated_P_Esys_low)    

        if (Red_node.probability(fs_i) < 10^(-5) )
            updated_P_Esys_low(fs_i)   = 0;
        else
            % load the component limit state parameters and stress results
            k = 1;
            while k <= size(Red_node.vector,2) && Red_node.vector(fs_i,k) ~= 0 
                if k==1
                    fname = num2str(Red_node.vector(fs_i,k));
                else
                    fname = strcat(fname,'_',num2str(Red_node.vector(fs_i,k)) );
                end
                k = k+1;
            end
            %fname
            %fs_i_prob = Red_node.probability(fs_i)

            fs_ind = find(strcmp({failure_paths.fs_name}, fname));
            Component_failure_probability_results = failure_paths(fs_ind).Component_failure_probability_results;
            Component_alpha_vector        = failure_paths(fs_ind).Component_alpha_vector;
            femodel.stress      = failure_paths(fs_ind).FEA_results;
            limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;

            if sum(Red_node.probability)+sum(Mixed_node.probability)>0.5
                femodel.sus_batchsize = 1*1e4;
            else
                femodel.sus_batchsize = 1*1e3;
            end

            % fname = strcat(archive_folder,fname,'.mat');
            % load(fname,'FEA_results','Component_limit_state_params', ...
            %            'Component_failure_probability_results', ...
            %            'Component_alpha_vector');
            
            % load stress and limit state parameters
            % femodel.stress                     = FEA_results;
            % limit_state_params                 = Component_limit_state_params;
    
            % combine inspection events parameters to the limit state params
            [limit_state_params.N_insp]        = deal([]);
            [limit_state_params.inspected_mem] = deal([]);
            limit_state_params  = [limit_state_params, inspect_event];
            femodel.limit_state_params = limit_state_params;
            % P_Esys_low_uqlab   = run_uqlab_sys_i(myInput, femodel);
            P_Esys_low_uqlab   = run_uqlab_sys(myInput, femodel);

            % femodel.Alpha_vector = Component_alpha_vector;
            % femodel.Failure_probability = Component_failure_probability_results;
            % femodel.limit_state_params = inspect_event;
            % updated_P_Esys_low(fs_i) = run_genz_sys(probdata, femodel);
            % P_Esys_low_genz = updated_P_Esys_low(fs_i)

            updated_P_Esys_low(fs_i) = P_Esys_low_uqlab;

            % % calculate the updated failure probability of the sequence
            % femodel.limit_state_params = limit_state_params;
            % updated_P_Esys_low(fs_i)   = run_uqlab_sys(myInput, femodel);
            % P_Esys_low_uqlab =  updated_P_Esys_low(fs_i)    
        end

    end

    % Update the lower bound given probability of inspection events
    (sum(updated_P_Esys_low))
    updated_P_Esys_low_bound = (sum(updated_P_Esys_low))/P_IE_sys;
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) UPDATE UPPER bound probability for each Li in Equation (29) of Ref.[2]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    updated_P_Esys_upper = zeros(size(Mixed_node.probability) );
    
    Li = Mixed_node.vector;

    for fs_i = 1: length(updated_P_Esys_upper) % i-th failure sequence

        % if (Mixed_node.probability(fs_i) < 10^(-6) )
        %     updated_P_Esys_upper(fs_i)   = 0;
        % else
            k = 1;
            while k <= size(Li,2) && Li(fs_i,k) ~= 0 
                if k==1
                    fname = num2str(Li(fs_i,k) );
                else
                    fname = strcat(fname,'_',num2str(Li(fs_i,k)) );
                end
                k = k+1;
            end
            fs_ind = find(strcmp({failure_paths.fs_name}, fname));
            Component_failure_probability_results = failure_paths(fs_ind).Component_failure_probability_results;
            Component_alpha_vector        = failure_paths(fs_ind).Component_alpha_vector;
            femodel.stress      = failure_paths(fs_ind).FEA_results;
            limit_state_params  = failure_paths(fs_ind).Component_limit_state_params;

            if sum(Red_node.probability)+sum(Mixed_node.probability)>0.5
                femodel.sus_batchsize = 1*1e4;
            else
                femodel.sus_batchsize = 1*1e3;
            end

            [limit_state_params.N_insp]        = deal([]);
            [limit_state_params.inspected_mem] = deal([]);
            limit_state_params  = [limit_state_params, inspect_event];
            femodel.limit_state_params = limit_state_params;
            P_Esys_upper_uqlab   = run_uqlab_sys(myInput, femodel);

            % femodel.Alpha_vector = Component_alpha_vector;
            % femodel.Failure_probability = Component_failure_probability_results;
            % femodel.limit_state_params = inspect_event;
            % P_Esys_upper_genz  = run_genz_sys(probdata, femodel);

            updated_P_Esys_upper(fs_i) = P_Esys_upper_uqlab;

        % end

    end
sum(updated_P_Esys_upper)
    updated_P_Esys_upper_bound = (sum(updated_P_Esys_upper)+sum(updated_P_Esys_low) )/P_IE_sys;

end