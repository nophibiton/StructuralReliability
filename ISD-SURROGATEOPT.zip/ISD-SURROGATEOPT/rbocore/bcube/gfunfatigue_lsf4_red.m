function [g, dgdx] = gfunfatigue_lsf4_red(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)
%
% G4
% T1^0+T2^1+T3^(1,2)+...+Ti^(1,...,i-1) < Ts : Equation (10) of Ref. [1]
%

% unpack
if isfield(gfundata(lsf),'cg')
    cg           = gfundata(lsf).cg;
    lsfparams    = cg{1};
    failure_seq  = cg{2};
    ac_all       = lsfparams.ac;
    mean_m       = lsfparams.mean_m;
    Y_a          = lsfparams.Y_a;
    N            = lsfparams.N;
    T_r          = lsfparams.T_r;
    stress       = lsfparams.stress;
end

len_sequence = length(failure_seq);

% INTEGRATION PART of Equation (16) of Ref. [1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Tk = zeros(1,len_sequence);

for k = 1:len_sequence

    % random variables
    C  = x(2*k-1 );
    ai = x(2*k   );
    S  = x(end   ) *stress(failure_seq(k),k);            
    
    % deterministic variables            
    ac = ac_all(failure_seq(k) );
    m  = mean_m;
    
    % evaluate integral
    Tk(k) = fatigue_integral(ai, ac, C, m, S, Y_a);

    % account for repaired members
    Tk(k) = Tk(k) + T_r( failure_seq(k) );            
end

% STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ti    = zeros(1,len_sequence);
Ti(1) = Tk(1);

for i = 2:len_sequence
    m   = mean_m;
    S_d = stress(failure_seq(i), i) *x(end); % denominator

    S_redistribute = 0;
    for n = 1: i-1
        S_n            = stress(failure_seq(i), n)*x(end);
        ratio          = S_n/S_d;
        S_redistribute = S_redistribute + Ti(n)* ratio^m;
    end

    Ti(i) = Tk(i) - S_redistribute;
end

% g = sum(Ti) -  N; 

Tref = max([sum(abs(T_r(failure_seq))), abs(N), 1]);
g    = (sum(Ti) - N)/Tref;

dgdx = nan;