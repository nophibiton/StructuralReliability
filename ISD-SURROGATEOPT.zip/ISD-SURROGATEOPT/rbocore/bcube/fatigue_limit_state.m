function [g,dg] = fatigue_limit_state(lsf,x,grad_flag,gfundata,femodel,randomfield)
%
% This function defines the limit state function described in Ref [1] and
% [2] in performing B^3 analysis.
%
%
% Reference: 
%
% [1] Lee, Y.-J., & Song, J. (2011). Risk Analysis of Fatigue-Induced Sequential 
%     Failures by Branch-and-Bound Method Employing System Reliability Bounds. 
%     Journal of Engineering Mechanics, 137(12), 807–821. 
%     https://doi.org/10.1061/(ASCE)EM.1943-7889.0000286
%
% [2] Lee, Y.-J., & Song, J. (2013). System Reliability Updating of 
%     Fatigue-Induced Sequential Failures. Journal of Structural Engineering, 
%     140(3). https://doi.org/10.1061/(ASCE)ST.1943-541X.0000836
%

% geometry function
Y_a = femodel.Y_a;

% consider repaired members
T_r = femodel.T_r;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for lsf = 1, limit state function of B^3 is reformulated using  to reduce
% the number of random variables
% 
% [1] Zhou, W., C. Gong, and H. P. Hong. “New Perspective on Application of 
% First-Order Reliability Method for Estimating System Reliability.” 
% Journal of Engineering Mechanics 143, no. 9 (2017). 
% https://doi.org/10.1061/(ASCE)EM.1943-7889.0001280.
%

if lsf == 1

    switch femodel.lsf_type
        case 1
            % G1: when no prior member cracked, cracked member before other member
            % Ti^0 < Tl^0   : i = failure_seq (failed), l = surviving_mem
            % See Equation (7) of Ref. [1]
                    
            % random variables of the member i (other member)
            C1 = x(2);                                % Paris parameter, C
            ai1= x(4);                                % initial crack length, ai
            S1 = x(end) * femodel.stress(femodel.surviving_mem); % stress range
            
            % deterministic variables of the member i (other member)
            ac1= femodel.ac(femodel.surviving_mem);   % Critical crack length, ac  
            m1 = femodel.mean_m;                      % Paris parameter, m
    
            % Evaluate integral, Equation (5) or first term of Equation (22a)   
            Tl0 = fatigue_integral(ai1, ac1, C1, m1, S1, Y_a);
            
            % random variables of the member j (target member)
            C2 = x(1);
            ai2= x(3);
            S2 = x(end) * femodel.stress(femodel.failure_seq);
            
            % deterministic variables of the member j (other member)
            ac2 = femodel.ac(femodel.failure_seq);
            m2  = femodel.mean_m;
    
            % Evaluate integral, Equation (5) or second term of Equation (22a)
            Ti0 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);
    
            % consider repaired members
            Ti0 = Ti0 + T_r(femodel.failure_seq);
            Tl0 = Tl0 + T_r(femodel.surviving_mem);
            
            % limit state function
            g = Ti0 - Tl0; % Ti^0 < Tl^0 of Equation (7) of Ref. [1]
    
        case 2
            % G2: when no prior member cracked, event of cracked 
            %     member i before inspection cycle
            % Ti^0 < Ts : Equation (7) of Ref. [1]
    
            % random variables of the member i (target failed member)
            C2 = x(1);
            ai2= x(2);
            S2 = x(end) * femodel.stress(femodel.failure_seq);
            
            % deterministic variables of the member i (target failed member)
            ac2 = femodel.ac(femodel.failure_seq);
            m2  = femodel.mean_m;
    
            % Evaluate integral
            T2 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);
    
            % consider repaired members
            T2 = T2 + T_r(femodel.failure_seq);
    
            % limit state function
            g = T2 - femodel.N;  % Ti^0 < Ts of Equation (7)
        
        case 3
            % G3: when prior members have cracked (1,...,i-1), event of 
            %     cracked member l before other member i
            %
            % Ti^(1,...,i-1) < Tl^(1,...,i-1) of Equation (10) of Ref. [1]
            % 
            
            len_sequence = length(femodel.failure_seq); % length of failure sequence
    
            % INTEGRATION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Tk1 = zeros(1,len_sequence); % term of left hand side of g(x)
            Tk2 = zeros(1,len_sequence); % term of right hand side of g(x)
    
            % calculate integration parts of left and right terms
            for ik = 1:len_sequence
    
                % random variables
                C  = x(2*ik-1 );
                ai = x(2*ik   );
                S  = x(end) * femodel.stress(femodel.failure_seq(ik), ik);
    
                % deterministic variables
                m  = femodel.mean_m;            
                ac = femodel.ac(femodel.failure_seq(ik) );
    
                % evaluate integral
                Tk1(ik) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                % account for repaired members
                Tk1(ik) = Tk1(ik) + T_r(femodel.failure_seq(ik));
            end
    
            Tk2 = Tk1; % except last term
            
            C  = x(end-2 );
            ai = x(end-1 );
            S  = x(end   )* femodel.stress(femodel.surviving_mem, end);
    
            ac = femodel.ac(femodel.surviving_mem );
            m  = femodel.mean_m;        
            %width = femodel.width(femodel.surviving_mem );
    
            % evalulate integral
            Tk2(end) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
            % account for repaired members
            Tk2(end) = Tk2(end) + T_r(femodel.surviving_mem);
    
            % STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Ti1 = zeros(1,len_sequence); 
            Ti1(1) = Tk1(1);
            
            for ik = 2:len_sequence-1 % last term is not the same
    
                m   = femodel.mean_m;
                S_d = femodel.stress(femodel.failure_seq(ik), ik)*x(end);
                
                S_redistribute = 0;
                for ij = 1:ik-1
    
                    S_n = femodel.stress(femodel.failure_seq(ik), ij)*x(end);
                    ratio = S_n/S_d;
                    S_redistribute = S_redistribute + Ti1(ij)*ratio^m;
                end
    
                Ti1(ik) = Tk1(ik) - S_redistribute;
            end
            Ti2 = Ti1;
    
            m1   = femodel.mean_m;
            S_d1 = femodel.stress(femodel.failure_seq(end), end)*x(end);
            
            m2   = femodel.mean_m;
            S_d2 = femodel.stress(femodel.surviving_mem, end)*x(end);
    
            S_redistribute1 = 0;
            S_redistribute2 = 0;
            for n = 1: len_sequence-1
    
                S_n1 = femodel.stress(femodel.failure_seq(end), n)*x(end);
                ratio1 = S_n1/S_d1;
                S_redistribute1 = S_redistribute1 + Ti1(n)* ratio1^m1;
    
                S_n2 = femodel.stress(femodel.surviving_mem, n)*x(end);
                ratio2 = S_n2/S_d2;
                S_redistribute2 = S_redistribute2 + Ti2(n)* ratio2^m2;          
            end
            
            Ti1(end) = Tk1(end) - S_redistribute1;
            Ti2(end) = Tk2(end) - S_redistribute2;
    
            g = Ti1(end) -  Ti2(end);
    
        case 4
            % G4
            % T1^0+T2^1+T3^(1,2)+...+Ti^(1,...,i-1) < Ts : Equation (10) of Ref. [1]
    
            len_sequence = length(femodel.failure_seq);
    
            % INTEGRATION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Tk = zeros(1,len_sequence);
            
            for k = 1:len_sequence
    
                % random variables
                C  = x(2*k-1 );
                ai = x(2*k   );
                S  = x(end   ) *femodel.stress(femodel.failure_seq(k),k);            
                
                % deterministic variables            
                ac = femodel.ac(femodel.failure_seq(k) );
                m  = femodel.mean_m;
                
                % evaluate integral
                Tk(k) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                % account for repaired members
                Tk(k) = Tk(k) + T_r(femodel.failure_seq(k) );            
            end
    
            % STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Ti = zeros(1,len_sequence);
            Ti(1) = Tk(1);
    
            for i = 2:len_sequence
                m   = femodel.mean_m;
                S_d = femodel.stress(femodel.failure_seq(i), i) *x(end); % denominator
    
                S_redistribute = 0;
                for n = 1: i-1
                    S_n = femodel.stress(femodel.failure_seq(i), n)*x(end);
                    ratio = S_n/S_d;
                    S_redistribute = S_redistribute + Ti(n)* ratio^m;
                end
    
                Ti(i) = Tk(i) - S_redistribute;
            end
     
            g = sum(Ti) -  femodel.N; 
    
            case 5
                % G5
                % Inspection event outcome - Inequality case
                % TI -Tjd < 0:   Equation (15) of Ref. [2]
                %
                
                % random variables
                C  = x(1 );
                ai = x(2 );
                % use stress when no prior member has failed
                S  = x(end)*femodel.stress(femodel.inspected_mem, 1);
                ad = x(3 );
    
                % deterministic variables            
                m  = femodel.mean_m;
                
                % calculate number of load cycles starting from crack ai to
                % detection crack ad.
                Njd = fatigue_integral(ai, ad, C, m, S, Y_a);
    
                % Inequality case, no detection
                g = femodel.N_insp - Njd;
    
            case 6
                % G6
                % Inspection event outcome - Inequality case
                % TI - Tjm = 0:   Equation (18) of Ref. [2]
                %
                
                % random variables
                C  = x(1  );
                ai = x(2  );
                S  = x(end) * femodel.stress(femodel.inspected_mem, 1);
                
                % deterministic variables            
                m  = femodel.mean_m;
                ad = femodel.mean_ad;
                
                % evaluate integral
                % Tjd = fatigue_integral(ai, ad, C, m, S, Y_a);
    
                % Inequality case, no detection
                aN = ( (1-m/2)*C*((S*Y_a*sqrt(pi))^m)*femodel.N_insp + ai^(1-m/2))^((1-m/2)^(-1) );
                u  = x(3 );
    
                c  = 1;
                g  = u - norminv(c*normpdf(ad - aN) );
    
    end

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for lsf = 2, original formulation of fatigue limit states in B^3 analysis
% 

if lsf == 2

    switch femodel.lsf_type
    
        case 1
            % G1: when no prior member cracked, cracked member before other member
            % Ti^0 < Tl^0   : i = failure_seq (failed), l = surviving_mem
            % See Equation (7) of Ref. [1]
                    
            % random variables of the member i (other member)
            C1 = x(femodel.surviving_mem);                          % Paris parameter, C
            ai1= x(femodel.surviving_mem + 1*femodel.no_elements);  % initial crack length, ai
            S1 = x(end) * femodel.stress(femodel.surviving_mem);       % stress range
            
            % deterministic variables of the member i (other member)
            ac1= femodel.ac(femodel.surviving_mem);      % Critical crack length, ac  
            m1 = femodel.mean_m;  % Paris parameter, m
    
            % Evaluate integral, Equation (5) or first term of Equation (22a)   
            Tl0 = fatigue_integral(ai1, ac1, C1, m1, S1, Y_a);
            
            % random variables of the member j (target member)
            C2 = x(femodel.failure_seq);
            ai2= x(femodel.failure_seq + 1*femodel.no_elements);
            S2 = x(end) * femodel.stress(femodel.failure_seq);
            
            % deterministic variables of the member j (other member)
            ac2 = femodel.ac(femodel.failure_seq);
            m2  = femodel.mean_m;
    
            % Evaluate integral, Equation (5) or second term of Equation (22a)
            Ti0 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);
    
            % consider repaired members
            Ti0 = Ti0 + T_r(femodel.failure_seq);
            Tl0 = Tl0 + T_r(femodel.surviving_mem);
            
            % limit state function
            g = Ti0 - Tl0; % Ti^0 < Tl^0 of Equation (7) of Ref. [1]
    
        case 2
            % G2: when no prior member cracked, event of cracked 
            %     member i before inspection cycle
            % Ti^0 < Ts : Equation (7) of Ref. [1]
    
            % random variables of the member i (target failed member)
            C2 = x(femodel.failure_seq );
            ai2= x(femodel.failure_seq + 1*femodel.no_elements);
            S2 = x(end) * femodel.stress(femodel.failure_seq);
            
            % deterministic variables of the member i (target failed member)
            ac2 = femodel.ac(femodel.failure_seq);
            m2  = femodel.mean_m;
    
            % Evaluate integral
            T2 = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);
    
            % consider repaired members
            T2 = T2 + T_r(femodel.failure_seq);
    
            % limit state function
            g = T2 - femodel.N;  % Ti^0 < Ts of Equation (7)
        
        case 3
            % G3: when prior members have cracked (1,...,i-1), event of 
            %     cracked member l before other member i
            %
            % Ti^(1,...,i-1) < Tl^(1,...,i-1) of Equation (10) of Ref. [1]
            % 
            
            len_sequence = length(femodel.failure_seq); % length of failure sequence
    
            % INTEGRATION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Tk1 = zeros(1,len_sequence); % term of left hand side of g(x)
            Tk2 = zeros(1,len_sequence); % term of right hand side of g(x)
    
            % calculate integration parts of left and right terms
            for ik = 1:len_sequence
    
                % random variables
                C  = x(femodel.failure_seq(ik) );
                ai = x(femodel.failure_seq(ik) + 1*femodel.no_elements );
                S  = x(end) * femodel.stress(femodel.failure_seq(ik), ik);
    
                % deterministic variables
                m  = femodel.mean_m;            
                ac = femodel.ac(femodel.failure_seq(ik) );
    
                % evaluate integral
                Tk1(ik) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                % account for repaired members
                Tk1(ik) = Tk1(ik) + T_r(femodel.failure_seq(ik));
            end
    
            Tk2 = Tk1; % except last term
            
            C  = x(femodel.surviving_mem );
            ai = x(femodel.surviving_mem + 1*femodel.no_elements);
            S  = femodel.stress(femodel.surviving_mem, end) *x(end);
    
            ac = femodel.ac(femodel.surviving_mem );
            m  = femodel.mean_m;        
            %width = femodel.width(femodel.surviving_mem );
    
            % evalulate integral
            Tk2(end) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
            % account for repaired members
            Tk2(end) = Tk2(end) + T_r(femodel.surviving_mem);
    
            % STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Ti1 = zeros(1,len_sequence); 
            Ti1(1) = Tk1(1);
            
            for ik = 2:len_sequence-1 % last term is not the same
    
                m   = femodel.mean_m;
                S_d = femodel.stress(femodel.failure_seq(ik), ik)*x(end);
                
                S_redistribute = 0;
                for ij = 1:ik-1
    
                    S_n = femodel.stress(femodel.failure_seq(ik), ij)*x(end);
                    ratio = S_n/S_d;
                    S_redistribute = S_redistribute + Ti1(ij)*ratio^m;
                end
    
                Ti1(ik) = Tk1(ik) - S_redistribute;
            end
            Ti2 = Ti1;
    
            m1   = femodel.mean_m;
            S_d1 = femodel.stress(femodel.failure_seq(end), end)*x(end);
            
            m2   = femodel.mean_m;
            S_d2 = femodel.stress(femodel.surviving_mem, end)*x(end);
    
            S_redistribute1 = 0;
            S_redistribute2 = 0;
            for n = 1: len_sequence-1
    
                S_n1 = femodel.stress(femodel.failure_seq(end), n)*x(end);
                ratio1 = S_n1/S_d1;
                S_redistribute1 = S_redistribute1 + Ti1(n)* ratio1^m1;
    
                S_n2 = femodel.stress(femodel.surviving_mem, n)*x(end);
                ratio2 = S_n2/S_d2;
                S_redistribute2 = S_redistribute2 + Ti2(n)* ratio2^m2;          
            end
            
            Ti1(end) = Tk1(end) - S_redistribute1;
            Ti2(end) = Tk2(end) - S_redistribute2;
    
            g = Ti1(end) -  Ti2(end);
    
        case 4
            % G4
            % T1^0+T2^1+T3^(1,2)+...+Ti^(1,...,i-1) < Ts : Equation (10) of Ref. [1]
    
            len_sequence = length(femodel.failure_seq);
    
            % INTEGRATION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Tk = zeros(1,len_sequence);
            
            for k = 1:len_sequence
    
                % random variables
                C  = x(femodel.failure_seq(k) );
                ai = x(femodel.failure_seq(k) + 1*femodel.no_elements );
                S  = x(end)*femodel.stress(femodel.failure_seq(k),k);            
                
                % deterministic variables            
                ac = femodel.ac(femodel.failure_seq(k) );
                m  = femodel.mean_m;
                
                % evaluate integral
                Tk(k) = fatigue_integral(ai, ac, C, m, S, Y_a);
    
                % account for repaired members
                Tk(k) = Tk(k) + T_r(femodel.failure_seq(k) );            
            end
    
            % STRESS REDISTRIBUTION PART of Equation (16) of Ref. [1]
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Ti = zeros(1,len_sequence);
            Ti(1) = Tk(1);
    
            for i = 2:len_sequence
                m   = femodel.mean_m;
                S_d = femodel.stress(femodel.failure_seq(i), i) *x(end); % denominator
    
                S_redistribute = 0;
                for n = 1: i-1
                    S_n = femodel.stress(femodel.failure_seq(i), n)*x(end);
                    ratio = S_n/S_d;
                    S_redistribute = S_redistribute + Ti(n)* ratio^m;
                end
    
                Ti(i) = Tk(i) - S_redistribute;
            end
     
            g = sum(Ti) -  femodel.N; 
    
            case 5
                % G5
                % Inspection event outcome - Inequality case
                % TI -Tjd < 0:   Equation (15) of Ref. [2]
                %
                
                % random variables
                C  = x(femodel.inspected_mem );
                ai = x(femodel.inspected_mem + 1*femodel.no_elements );
                S  = x(end)*femodel.stress(femodel.inspected_mem, 1);
                ad = x(2*femodel.no_elements+1 );
    
                % deterministic variables            
                m  = femodel.mean_m;
                
                % calculate number of load cycles starting from crack ai to
                % detection crack ad.
                Njd = fatigue_integral(ai, ad, C, m, S, Y_a);

                % Inequality case, no detection
                g = femodel.N_insp - Njd;
    
            case 6
                % G6
                % Inspection event outcome - Inequality case
                % TI - Tjm = 0:   Equation (18) of Ref. [2]
                %
                
                % random variables
                C  = x(femodel.inspected_mem );
                ai = x(femodel.inspected_mem + 1*femodel.no_elements );
                S  = x(end)*femodel.stress(femodel.inspected_mem, 1);
                
                % deterministic variables            
                m  = femodel.mean_m;
                ad = femodel.mean_ad;
                
                % evaluate integral
                % Tjd = fatigue_integral(ai, ad, C, m, S, Y_a);
    
                % Inequality case, no detection
                aN = ( (1-m/2)*C*((S*Y_a*sqrt(pi))^m)*femodel.N_insp + ai^(1-m/2))^((1-m/2)^(-1) );
                u  = x(2*femodel.no_elements+3);
    
                c  = 1;
                g  = u - norminv(c*normpdf(ad - aN) );        
    
    end

end



% SENSITIVITY COMPUTATIONS
if grad_flag == 'yes' % If the user wants gradients to be computed by DDM
   dg = [];   
else % Assign dummy value if grad_flag==0 (gradients not computed by DDM) 
   dg = 0; 
end
