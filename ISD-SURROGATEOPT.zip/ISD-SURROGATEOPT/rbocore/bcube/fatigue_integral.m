function [N] = fatigue_integral(a0, ac, C, m, S, Y_a)
%
% Calculates the number of cycles N from crack a0 to ac.
% Integration part of fatigue model evaluated analytically.
% See equation (4) and (5).
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% N = ((ac.^(1-m./2)-ai.^(1-m./2))./(1-m./2)) ./ (C.*(S.*Y_a.*sqrt(pi)).^m);

% Analytical fatigue life
q   = 1 - m/2;

% Numerically stable integral factor
if q == 0
    numer = log(ac./a0);
else
    numer = a0.^q .* expm1(q.*log(ac./a0))./q;
end

denom = C .* (S.*Y_a.*sqrt(pi)).^m;

N     = numer./denom;

