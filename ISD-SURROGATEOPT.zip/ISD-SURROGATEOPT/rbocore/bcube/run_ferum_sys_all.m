function [Pf_sys] =run_ferum_sys_all(probdata, lsfparams, system_event)


gfundata(1).evaluator = 'fatiguesys';
gfundata(1).type      = 'expression';
gfundata(1).cg        = {lsfparams,system_event};
gfundata(1).flag_sens = 0;

analysisopt.num_sim              = 1*1e3;      
analysisopt.rand_generator       = 0;        
analysisopt.width                = 1;        
analysisopt.pf_target            = 0.1;      
analysisopt.flag_cov_pf_bounds   = 1;         
analysisopt.ss_restart_from_step = -inf;     
analysisopt.flag_plot            = 0; 
analysisopt.multi_proc           = 0;
analysisopt.echo_flag            = 0;     % Silent mode
analysisopt.analysistype         = 23;    % SubSet Simulation
analysisopt.block_size           = 1;
analysisopt.stdv_sim             = 1;     
% NEW: Stopping criteria
analysisopt.ss_pf_floor          = normcdf(-7);
analysisopt.ss_max_levels        = 12;
analysisopt.ss_max_evals         = 1.2e5;

femodel     = [];
randomfield = [];

ferum;

Pf_sys = subsetsimulationresults.pf;