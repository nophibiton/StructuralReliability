function [g, dgdx] = gfunfatigue_lsf1_red(lsf,x, ...
    grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)
%
% G1: when no prior member cracked, cracked member before other member
% Ti^0 < Tl^0   : i = failure_seq (failed), l = surviving_mem
% See Equation (7) of Ref. [1]
%

% unpack
if isfield(gfundata(lsf),'cg')
    cg            = gfundata(lsf).cg;
    lsfparams     = cg{1};
    failure_seq   = cg{2};
    surviving_mem = cg{3};
    ac            = lsfparams.ac;
    mean_m        = lsfparams.mean_m;
    Y_a           = lsfparams.Y_a;
    T_r           = lsfparams.T_r;
    stress        = lsfparams.stress;
end

% Column vector for a single realization
x  = x(:);

I  = x(end); % load scale factor

% random variables of the member i (other member)
C1 = x(2);                           % Paris parameter, C
ai1= x(4);                           % initial crack length, ai
S1 = I * stress(surviving_mem);      % stress range

% deterministic variables of the member i (other member)
ac1= ac(surviving_mem);              % Critical crack length, ac  
m1 = mean_m;                         % Paris parameter, m

% Evaluate integral, Equation (5) or first term of Equation (22a)   
Tl = fatigue_integral(ai1, ac1, C1, m1, S1, Y_a);

% random variables of the member j (target member)
C2 = x(1);
ai2= x(3);
S2 = I * stress(failure_seq);

% deterministic variables of the member j (other member)
ac2 = ac(failure_seq);
m2  = mean_m;

% Evaluate integral, Equation (5) or second term of Equation (22a)
Ti = fatigue_integral(ai2, ac2, C2, m2, S2, Y_a);

% consider repaired members
Ti0 = Ti + T_r(failure_seq);
Tl0 = Tl + T_r(surviving_mem);

% limit state function
g = Ti0 - Tl0; % Ti^0 < Tl^0 of Equation (7) of Ref. [1]

% Analytical gradient in physical X-space
if grad_flag == 'yes'

    dgdx    = zeros(numel(x),1);
    
    dgdx(1) = -Ti/C2; % Derivative w.r.t. C2 = x(1)    
    dgdx(2) =  Tl/C1; % Derivative w.r.t. C1 = x(2)
    dgdx(3) = -ai2^(-m2/2) / ...
              (C2*(S2*Y_a*sqrt(pi))^m2);   % Derivative w.r.t. ai2 = x(3)
    dgdx(4) =  ai1^(-m1/2) / ...
              (C1*(S1*Y_a*sqrt(pi))^m1);   % Derivative w.r.t. ai1 = x(4)
    dgdx(end) = -(m2*Ti - m1*Tl)/I;        % Derivative w.r.t. load scale

else
    dgdx      = nan;
end