function x = bcube_rv_generator(probdata,no_elements, Nsamples)
%
% This is a vectorize version of u_to_x function to facilitate faster
% sampling of random variables in x-space.
%

probdata.marg         = distribution_parameter(probdata.marg);
analysisopt.echo_flag = 0;      
probdata              = modify_correl_mat(probdata,analysisopt);

% exctract model data
marg      = probdata.marg;
R         = probdata.correlation;
nrv       = size(probdata.correlation,1);

% get parameter of each random variable
lambda    = marg(:,5);
xi        = marg(:,6);

% generate z variables
u         = mvnrnd(zeros(size(marg,1),1),eye(nrv),Nsamples )';
Lo        = probdata.Lo;
z         = Lo*u;

% convert u to z to x space
x         = zeros(size(z));

% C <- Lognormal
ii      = 1:no_elements;
x(ii,:) = exp( xi(ii(:)).*z(ii,:) + lambda(ii(:)) );

% ai <- Lognormal
ii      = (no_elements+1):(2*no_elements);
x(ii,:) = exp( xi(ii(:)).*z(ii,:) + lambda(ii(:)) );

% % ai <- exponential
% ii      = (no_elements+1):(2*no_elements);
% x(ii,:) = -log(normcdf(z(ii,:),0,1,'upper')) ./ lambda(ii(:));

% % ai <- Lognormal
% ii      = (1*no_elements+1):(2*no_elements);
% x(ii,:) = exp( xi(ii(:)).*z(ii,:) + lambda(ii(:)) );

% % ad <- Exponential
% for i=(2*no_elements+1):(2*no_elements+1)
%     x(i,:) = 1/lambda(i)*log(1./(1-normcdf(z(i,:))));
% end

% ad <- Exponential
ii      = 2*no_elements + 1;
x(ii,:) = -log(normcdf(z(ii,:),0,1,'upper')) / lambda(ii);

% S <- Lognomral
ii      = 2*no_elements + 2;
x(ii,:) = exp( z(ii,:)*xi(ii) + lambda(ii) );

x = x';