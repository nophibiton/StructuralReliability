function [stop,reason] = ss_stop_check(SubsetData,nfun,analysisopt)

    stop   = false;
    reason = '';

    % Current intermediate threshold
    y = SubsetData.y(end);

    % Number of completed levels (including Step 0)
    nLevels = SubsetData.Nb_step + 1;

    % Estimated probability of current intermediate event
    pf_intermediate = prod(SubsetData.p);

    % Check numerical validity
    if ~isfinite(y) || ...
       ~isfinite(pf_intermediate) || ...
       pf_intermediate < 0 || pf_intermediate > 1

        stop = true;
        reason = 'Invalid threshold or intermediate probability';
        return;
    end

    % Normal convergence: final failure event reached
    if y == 0
        return;
    end

    % Criterion 1: Probability floor
    if pf_intermediate <= analysisopt.ss_pf_floor

        stop = true;
        reason = sprintf( ...
            'Probability floor reached: %.3e', ...
            pf_intermediate);
        return;
    end

    % Criterion 2: Maximum subset levels
    if nLevels >= analysisopt.ss_max_levels

        stop = true;
        reason = sprintf( ...
            'Maximum subset levels reached: %d', ...
            nLevels);
        return;
    end

    % Criterion 3: Maximum function evaluations
    if nfun >= analysisopt.ss_max_evals

        stop = true;
        reason = sprintf( ...
            'Maximum function evaluations reached: %d', ...
            nfun);
        return;
    end

end