function data = subset_subset_step(data,num_sim,lsf,probdata,analysisopt,gfundata,femodel,randomfield)

% Perform a single subset step

global nfun

nrv = size(probdata.marg,1);

rand_generator = analysisopt.rand_generator;
if isfield(analysisopt,'echo_flag')
   echo_flag = analysisopt.echo_flag;
else
   echo_flag = 1;
end
flag_plot      = analysisopt.flag_plot;
flag_plot_gen  = analysisopt.flag_plot_gen;
 

width = data.width;

% Extract valid MCMC seed indices
Indgerm = data.Indgerm(end,:);
Indgerm = Indgerm(Indgerm > 0);

% Prevent an infinite loop caused by missing seeds
if isempty(Indgerm)
    error('FERUM:NoSeeds', ...
        ['Subset %d has no MCMC seed samples. ' ...
         'Cannot generate the next subset.'], ...
        data.Nb_step);
end

if any(~isfinite(Indgerm)) || ...
   any(Indgerm > size(data.U,2)) || ...
   any(Indgerm ~= floor(Indgerm))

    error('FERUM:InvalidSeeds', ...
        'MCMC seed indices are invalid.');
end

subgermU = data.U(:,Indgerm);
subgermG = data.G(Indgerm);

if any(~isfinite(subgermG(:))) || ...
   any(~isfinite(subgermU(:)))

    error('FERUM:InvalidSeeds', ...
        'MCMC seeds contain NaN or Inf.');
end

% Maximum expected number of MCMC generations
nSeeds = numel(Indgerm);
maxGenerations = ceil(num_sim/nSeeds) + 1;

% Validate block size
if ~isscalar(analysisopt.block_size) || ...
   ~isfinite(analysisopt.block_size) || ...
   analysisopt.block_size < 1 || ...
   analysisopt.block_size ~= floor(analysisopt.block_size)

    error('FERUM:InvalidBlockSize', ...
        'analysisopt.block_size must be a positive integer.');
end


subsetU   = [];
subsetG  = [];

Nb_generation = 0;
MHrate = [];
mMHrate = [];

while size(subsetU,2) < num_sim
  
   Nb_generation = Nb_generation + 1;

    if Nb_generation > maxGenerations
    
        error('FERUM:SubsetStalled', ...
            ['Subset %d exceeded %d MCMC generations. ' ...
             'Generated %d of %d required samples.'], ...
             data.Nb_step,maxGenerations, ...
             size(subsetU,2),num_sim);
    end

   [ subtempu, I_eval, newG, ratio ] = subset_MCMC(subgermU,width,rand_generator);
   MHrate = [ MHrate ; 100*mean(ratio,2) 100*sum(newG,2)/length(newG) ];

    if isempty(subtempu) || size(subtempu,2) == 0
    
        error('FERUM:EmptyMCMC', ...
            ['Subset %d, generation %d: ' ...
             'subset_MCMC returned no samples.'], ...
             data.Nb_step,Nb_generation);
    end

   % Initializations
   
   block_size = analysisopt.block_size;
   
   k = 0;
   percent_done = 0;

   num_subtemp_eval = length(I_eval);
   subtempu_eval = subtempu(:,I_eval);
   subtempg = subgermG;
   subtempg_eval = subtempg(1,I_eval);
      
   while k < num_subtemp_eval
   
      block_size = min( block_size, num_subtemp_eval-k );
      k = k + block_size;
      
      allu = subtempu_eval(:,(k-block_size+1):k);

      % Transform into original space
      allx = u_to_x(allu,probdata);

      % Evaluate limit-state function
      [ allG, dummy ] = gfun(lsf,allx,'no ',probdata,analysisopt,gfundata,femodel,randomfield);
      
      subtempg_eval((k-block_size+1):k) = allG;

      if floor( k/num_subtemp_eval * 20 ) > percent_done
         percent_done = floor( k/num_subtemp_eval * 20 );
        if echo_flag
            fprintf(1,'Subset step #%d - Generation #%d - %d%% complete\n',data.Nb_step,Nb_generation,percent_done*5)
        end
      end
      
   end
   
   subtempg(1,I_eval) = subtempg_eval;
   
   data.Neval = data.Neval + num_subtemp_eval;
   data.N     = data.N     + size(subtempu,2);
   
   % Selection des points dont la valeur de l'�tat-limite est sup�rieure au seuil en cours
   ind = find( subtempg > data.y(end) );

   if nrv == 2 & flag_plot == 1 & flag_plot_gen == 1
      data.Usubtemp = subtempu;
      data.ind = ind;
      data.Nb_generation = Nb_generation;
      data = subset_subset_graph(data,2);
   end
  
   mMHrate = [ mMHrate ; 100*(length(subtempg)-length(ind))/length(subtempg) ];

   % On remplace les points selectionn�s par les anciens points
   subtempu(:,ind) = subgermU(:,ind);
   subtempg(ind) = subgermG(ind);

    % Append generated samples
    nBefore = size(subsetU,2);
    
    subsetU = [subsetU subtempu];
    subsetG = [subsetG subtempg];
    
    % Verify progress
    nAfter = size(subsetU,2);
    
    if nAfter <= nBefore
    
        error('FERUM:NoProgress', ...
            'MCMC sampling made no progress.');
    end

    if echo_flag
        fprintf(['Subset %d | Generation %d | ' ...
                 'Samples %d/%d | Threshold %.6e\n'], ...
                data.Nb_step,Nb_generation, ...
                nAfter,num_sim,data.y(end));
    end

   subgermG = subtempg;
   subgermU = subtempu;
  
end

data.U       = [ data.U subsetU ];
data.G       = [ data.G subsetG ];
data.Indices = [ data.Indices; data.Indices(end,2)+1 data.Indices(end,2)+size(subsetU,2) ];
data.AccRate = [ data.AccRate [ Nb_generation ; mean(MHrate(:,1)) ; mean(MHrate(:,2)) ; mean(mMHrate) ] ];
