function data = subset_y_threshold(data,analysisopt)

% Evaluate the threshold value y of the intermediate limit-state-function
% Make preliminary calculations for estimating the coefficient of variation of the failure probability pf

% PATCH: Consistent selection for the event {G <= y}, including tied values.
% Note: a very small target failure probability is NOT, by itself, a reason
% to have no seeds. Plateaus / identical values can cause this in old FERUM.
p_target = data.pf_target;
data.ss_stalled = false;

IndInf = data.Indices(end,1);
IndSup = data.Indices(end,2);

G = data.G(IndInf:IndSup);
N = numel(G);

if N == 0 || ~isreal(G) || any(~isfinite(G(:)))
   error('FERUM:InvalidG', ...
       'Subset %d: empty, non-finite, or complex limit-state values.', ...
       data.Nb_step);
end

y = ferum_quantile(G,p_target);
if ~isscalar(y) || ~isreal(y) || ~isfinite(y)
   error('FERUM:InvalidThreshold', ...
       'Subset %d: ferum_quantile returned an invalid threshold.', ...
       data.Nb_step);
end

% The final failure event is {G <= 0}.
y = max(0,y);


% Check whether the intermediate threshold has stagnated
if ~isempty(data.y) && y > 0 && y >= data.y(end)

    data.ss_stalled = true;
    data.ss_stop_reason = sprintf( ...
        'Threshold stagnation at subset %d', ...
        data.Nb_step);

    data.ss_candidate_threshold = y;

    return;  % Do not append a repeated threshold
end


% Use the SAME inclusive event for seeds, probability, and CoV.
Indgerm = find(G <= y);
p = numel(Indgerm)/N;

if y > 0 && p == 1
   error('FERUM:DegenerateSubset', ...
       ['Subset %d: all %d G samples are <= the positive threshold %.16g. ' ...
        'Quantile ties/constant outputs prevent useful subset progression. ' ...
        'The simulation is INCOMPLETE.'], ...
       data.Nb_step,N,y);
end

if p == 0
   error('FERUM:NoSeeds', ...
       'Subset %d: no samples belong to {G <= %.16g}.', ...
       data.Nb_step,y);
end

% % A large discrepancy from the requested p0 signals quantile ties.
% if y > 0 && p > p_target + 0.02
%    warning('FERUM:QuantileTies', ...
%        ['Subset %d: target p0=%.4g, actual P(G<=y)=%.4g; ' ...
%         'there may be many identical G values.'], ...
%        data.Nb_step,p_target,p);
% end

data.y = [ data.y y ];
data.p = [ data.p p ];

Indgerm = reshape(Indgerm + IndInf - 1,1,[]);

if data.Nb_step == 0

   data.Indgerm = Indgerm;

else

   if size(Indgerm,2) == size(data.Indgerm,2)
      data.Indgerm = [ data.Indgerm; Indgerm ];
   elseif size(Indgerm,2) > size(data.Indgerm,2)
      data.Indgerm = [ data.Indgerm zeros(size(data.Indgerm,1),size(Indgerm,2)-size(data.Indgerm,2)) ];
      data.Indgerm = [ data.Indgerm; Indgerm ];
   elseif size(Indgerm,2) < size(data.Indgerm,2),
      data.Indgerm = [ data.Indgerm; [Indgerm zeros(1,size(data.Indgerm,2)-size(Indgerm,2))] ];
   end

end


if isfield(analysisopt,'flag_cov_pf_bounds') & analysisopt.flag_cov_pf_bounds == 1
   
   if p == 1

      % All samples satisfy the terminal event; avoid 0/0 in Rzero.
      cov_pf_step = 0;

   elseif data.Nb_step == 0

      cov_pf_step = sqrt( (1-p) / (p*N) );

   else

      Nc = length(find(data.Indgerm(end-1,:)));
      N = IndSup - IndInf + 1;
      
% tic
% 
%       Itemp = zeros(size(G'));
%       Itemp( find( G <= y ) ) = 1;
%       I = [];
%       for i = 1:N/Nc
%          I = [ I Itemp((i-1)*Nc+1:i*Nc) ];
%       end
% 
%       Rzero = p*(1-p);
%       R = [];
%       for k = 1:(N/Nc-1)
%          R(k) = 0;
%          for j = 1:Nc
%             ind = find( I(j,:) );
%             indou = find( ind <= (N/Nc-k) );
%             R(k) = R(k) + sum( I(j,ind(indou)) .* I(j,ind(indou)+k) );
%          end
%          R(k) = 1/(N-k*Nc) * R(k) - p^2;
%       end
% 
%       rho = []; % rho(k) = R(k)/Rzero
%       gamma = 0;
%       for k = 1:(N/Nc-1)
%          rho(k) = R(k) / Rzero;
%          gamma = gamma + 2 * (1-k*Nc/N) * rho(k);
%       end
% 
%       cov_pf_step = sqrt( (1-p) / (p*N) * (1+gamma) );
% 
% toc

      if Nc < 1 || mod(N,Nc) ~= 0
         error('FERUM:InvalidMCMCChains', ...
             'Subset %d: N=%d not divisible by previous number of seeds Nc=%d.', ...
             data.Nb_step,N,Nc);
      end

      Rzero = p*(1-p);

      I = [ G <= y ];
      Indices = reshape((1:N),[],N/Nc)';
      gamma = 0;
      for k = 1:(N/Nc-1)
         Z = 0;
         for j = 1:Nc
            for l = 1:(N/Nc-k)
               Z = Z + I(Indices(l,j)) * I(Indices(l+k,j));
            end
         end
         rho(k) = ( 1/(N-k*Nc) * Z - p^2 ) / Rzero;
         gamma = gamma + 2 * (1-k*Nc/N) * rho(k);
      end

      cov_pf_step = sqrt( (1-p) / (p*N) * (1+gamma) );

   end
   
   data.cov_pf_step = [ data.cov_pf_step cov_pf_step ];
   
end