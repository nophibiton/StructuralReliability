function [ G, grad_g ] = gfun_gsobol(lsf,x,grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

global nfun

nrv = size(x,1);
nx  = size(x,2);

a = gfundata(lsf).cg;

G = ( abs(4*x-2) + a*ones(1,nx) ) ./ ( 1 + a*ones(1,nx) );
G = prod(G,1);

grad_g = 0;

nfun = nfun + nx;