function [ G, grad_g ] = gfun_series_system_4dspts(lsf,x,grad_flag,probdata,analysisopt,gfundata,femodel,randomfield)

global nfun

nrv = size(x,1);
nx  = size(x,2);

u = x;

G4 = -gfundata(lsf).cg.ALPHA4'*u + gfundata(lsf).cg.beta4'*ones(1,nx);
G = min(G4,[],1);

grad_g = 0;

nfun = nfun + nx;