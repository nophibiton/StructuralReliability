function g = gfun_Engelund_example5(x1,x2,x3,x4,x5)

y1 = 2.677 - x1 - x2;
y2 = 2.500 - x2 - x3;
y3 = 2.323 - x3 - x4;
y4 = 2.250 - x4 - x5;

g = max([y1; y2; y3; y4],[],1);