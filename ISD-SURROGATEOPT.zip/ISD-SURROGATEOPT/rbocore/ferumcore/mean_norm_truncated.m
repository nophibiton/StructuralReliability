function mean_t = mean_norm_truncated(mean,stdv,xmin,xmax)

if ~isinf(xmin) & ~isinf(xmax)

mean_t = 1/(ferum_cdf(1,(xmax-mean)/stdv,0,1)-ferum_cdf(1,(xmin-mean)/stdv,0,1)) * ...
            ( mean * (ferum_cdf(1,(xmax-mean)/stdv,0,1)-ferum_cdf(1,(xmin-mean)/stdv,0,1)) - ...
              stdv * (ferum_pdf(1,(xmax-mean)/stdv,0,1)-ferum_pdf(1,(xmin-mean)/stdv,0,1)) );
           
elseif xmin==-inf & xmax==inf

mean_t = 1/(1-0) * ...
            ( mean * (1-0) - ...
              stdv * (0-0) );

else
   
   if xmin==-inf
      
mean_t = 1/(ferum_cdf(1,(xmax-mean)/stdv,0,1)-0) * ...
            ( mean * (ferum_cdf(1,(xmax-mean)/stdv,0,1)-0) - ...
              stdv * (ferum_pdf(1,(xmax-mean)/stdv,0,1)-0) );

   end
   
   if xmax==inf
      
mean_t = 1/(1-ferum_cdf(1,(xmin-mean)/stdv,0,1)) * ...
            ( mean * (1-ferum_cdf(1,(xmin-mean)/stdv,0,1)) - ...
              stdv * (0-ferum_pdf(1,(xmin-mean)/stdv,0,1)) );

   end

end   
