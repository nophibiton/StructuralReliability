clc, clear; format compact; format shortG;
rboptim=tic;

archive_folder = strcat(pwd,'\archive_data\');
summary_folder = strcat(pwd,'\summary_results\');

addpath( genpath(strcat(pwd,'\rbocore')) );

case_struct = {'case_a','case_b','case_c','ground'};

for i_case = 4
    
    % define objective parameters and problem parameters
    [objparams] = define_params_mld( case_struct{i_case} );
    objparams.calc_psys = @perform_bcube_full_latent;
    save( strcat(archive_folder,objparams.save_fname,'_objparams.mat') );
    
    % % parallel computing
    % delete( gcp('nocreate') );
    % parpool('Processes',objparams.npools);
    
    % main EGO
    nrun        = objparams.nrun;
    description = objparams.description;
    save_fname  = objparams.save_fname;
    
    % define decision variables for areas/struct design
    d_size      = objparams.d_size;
    d_min       = objparams.d_min;
    d_max       = objparams.d_max;

    % define decision variables for inspection
    d_insp_size = objparams.d_insp_size;
    allowed_insp_interval = objparams.allowed_insp_interval;
    d_insp_min  = ones(1,d_insp_size);
    d_insp_max  = ones(1,d_insp_size)*length(allowed_insp_interval);

    % define optimization parameters
    lb          = [d_insp_min,d_min];
    ub          = [d_insp_max,d_max];
    intcon      = [1 2];             % define discrete decision vars
    opts        = optimoptions('surrogateopt', ...
                               'MaxFunctionEvaluations', 500, ...
                               'Display', 'off', ...
                               'OutputFcn', ...
        @(x,optimValues,state) stopAfterNoImprovement( ...
            x,optimValues,state,50,numel(lb),allowed_insp_interval ) );

    % define objective function
    objfun      = @(x) calc_obj_full_mixed( x, objparams );

    % run optimization
    [xopt,fopt] = surrogateopt( objfun, lb, ub, intcon, opts );

    elapsed_time = toc( rboptim );

    file_name = strcat(summary_folder,'final_',save_fname);
    save( file_name );

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function stop = stopAfterNoImprovement(~,optimValues,state,N,nvars,insp_interval)

    persistent bestF count

    stop = false;

    switch state

        case 'init'

            bestF = Inf;
            count = 0;

            % Table header
            fprintf('\n');
            fprintf('%8s %10s %14s %14s %12s', ...
                'F-count', 'Time(s)', 'Best Fval', ...
                'Current Fval', 'Trial Type');

            for i = 1:nvars
                fprintf(' %11s', sprintf('x%d',i));
            end

            fprintf(' %10s\n', 'NoImprove');
            fprintf('%s\n', repmat('-',1,72+12*nvars));

        case 'iter'

            currentBest = optimValues.fval;

            % Check improvement
            if isfinite(currentBest) && currentBest < bestF
                bestF = currentBest;
                count = 0;
            else
                count = count + 1;
            end

            % Current evaluated design variables
            xcurr = optimValues.currentX;

            % Display iteration information
            fprintf('%8d %10.2f %14.6f %14.6f %12s', ...
                optimValues.funccount, ...
                optimValues.elapsedtime, ...
                optimValues.fval, ...
                optimValues.currentFval, ...
                char(optimValues.currentFlag));

            % Display design variables
            fprintf(' %11d', insp_interval(round(xcurr(1:2)) ) );   % Integer variables
            fprintf(' %11.5f', xcurr(3:end));     % Continuous variables

            % Display stagnation counter
            fprintf(' %10d\n', count);

            % Stopping criterion
            if count >= N
                stop = true;
                fprintf('\nStopping optimization: ');
                fprintf('No improvement for %d consecutive evaluations.\n',N);
                fprintf('Best objective: %.6f\n',bestF);
            end

        case 'done'

            fprintf('\nOptimization finished.\n');

    end
end

rmpath(genpath(strcat(pwd,'\rbocore')) );

